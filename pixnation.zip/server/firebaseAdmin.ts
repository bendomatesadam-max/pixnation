import { cert, getApp, getApps, initializeApp } from 'firebase-admin/app';
import type { ServiceAccount } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import type { DecodedIdToken } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';

export const FIREBASE_PROJECT_ID = 'pixnation-b77f1';

export type AdminCredentialMode =
  | 'service_account_json'
  | 'service_account_fields'
  | 'google_application_credentials'
  | 'adc_metadata';

let resolvedCredentialMode: AdminCredentialMode = 'adc_metadata';

function resolveAdminCredential(): { credential?: ReturnType<typeof cert>; mode: AdminCredentialMode } {
  const rawJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON?.trim();
  if (rawJson) {
    let parsed: Record<string, unknown>;
    try {
      parsed = JSON.parse(rawJson) as Record<string, unknown>;
    } catch {
      throw new Error(
        'FIREBASE_SERVICE_ACCOUNT_JSON geçerli bir JSON formatında değil.'
      );
    }

    const projectId = typeof parsed.project_id === 'string' ? parsed.project_id.trim() : '';
    const clientEmail =
      typeof parsed.client_email === 'string' ? parsed.client_email.trim() : '';
    const privateKey =
      typeof parsed.private_key === 'string'
        ? parsed.private_key.replace(/\\n/g, '\n')
        : '';

    if (projectId && projectId !== FIREBASE_PROJECT_ID) {
      throw new Error(
        `FIREBASE_SERVICE_ACCOUNT_JSON başka bir projeye (${projectId}) ait; beklenen proje: ${FIREBASE_PROJECT_ID}.`
      );
    }
    if (!clientEmail || !privateKey) {
      throw new Error(
        'FIREBASE_SERVICE_ACCOUNT_JSON içinde client_email veya private_key eksik.'
      );
    }

    const serviceAccount: ServiceAccount = {
      projectId: projectId || FIREBASE_PROJECT_ID,
      clientEmail,
      privateKey,
    };
    return { credential: cert(serviceAccount), mode: 'service_account_json' };
  }

  const envClientEmail = process.env.FIREBASE_CLIENT_EMAIL?.trim();
  const envPrivateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n').trim();
  if (envClientEmail && envPrivateKey) {
    const envProjectId = process.env.FIREBASE_PROJECT_ID?.trim();
    if (envProjectId && envProjectId !== FIREBASE_PROJECT_ID) {
      throw new Error(
        `FIREBASE_PROJECT_ID (${envProjectId}) beklenen projeyle (${FIREBASE_PROJECT_ID}) uyuşmuyor.`
      );
    }
    return {
      credential: cert({
        projectId: FIREBASE_PROJECT_ID,
        clientEmail: envClientEmail,
        privateKey: envPrivateKey,
      }),
      mode: 'service_account_fields',
    };
  }

  if (process.env.GOOGLE_APPLICATION_CREDENTIALS?.trim()) {
    return { mode: 'google_application_credentials' };
  }

  return { mode: 'adc_metadata' };
}

function initAdminApp() {
  if (getApps().length) {
    return getApp();
  }
  const { credential, mode } = resolveAdminCredential();
  resolvedCredentialMode = mode;
  return credential
    ? initializeApp({
        credential,
        projectId: FIREBASE_PROJECT_ID,
      })
    : initializeApp({
        projectId: FIREBASE_PROJECT_ID,
      });
}

const adminApp = initAdminApp();

export function getAdminCredentialMode(): AdminCredentialMode {
  return resolvedCredentialMode;
}

export const adminAuth = getAuth(adminApp);
export const adminDb = getFirestore(adminApp);

export type ServerRole = 'player' | 'moderator' | 'admin' | 'owner';

export function extractBearerToken(authHeader: string | undefined): string | null {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.slice('Bearer '.length).trim();
  return token.length > 0 ? token : null;
}

export async function verifyCallerToken(
  authHeader: string | undefined,
  checkRevoked = false
): Promise<DecodedIdToken> {
  const token = extractBearerToken(authHeader);
  if (!token) {
    throw new HttpError(401, 'Oturum doğrulama anahtarı eksik.');
  }
  try {
    return await adminAuth.verifyIdToken(token, checkRevoked);
  } catch (error) {
    if (isIamPermissionError(error)) {
      throw new HttpError(
        503,
        'Sunucu tarafı Firebase Admin SDK IAM izinleri henüz tanımlanmamış.'
      );
    }
    throw new HttpError(401, 'Geçersiz veya süresi dolmuş oturum.');
  }
}

export function getTokenRole(decoded: DecodedIdToken): ServerRole {
  const raw = decoded.role;
  if (raw === 'owner' || raw === 'admin' || raw === 'moderator') {
    return raw;
  }
  return 'player';
}

export function isIamPermissionError(error: unknown): boolean {
  if (!error || typeof error !== 'object') return false;
  const record = error as { code?: unknown; message?: unknown };
  const code = String(record.code ?? '').toLowerCase();
  const message = String(record.message ?? '').toLowerCase();
  return (
    code === '7' ||
    code === 'permission-denied' ||
    code === 'auth/insufficient-permission' ||
    message.includes('permission_denied') ||
    message.includes('insufficient permission') ||
    message.includes('missing or insufficient permissions') ||
    message.includes('caller does not have permission') ||
    message.includes('could not load the default credentials') ||
    message.includes('identitytoolkit.googleapis.com') ||
    message.includes('service_disabled') ||
    message.includes('accessnotconfigured')
  );
}

export class HttpError extends Error {
  public readonly status: number;

  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}
