import fs from 'node:fs';
import path from 'node:path';
import {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
  RulesTestEnvironment,
} from '@firebase/rules-unit-testing';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';

const PROJECT_ID = 'pixnation-emulator-test';

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

interface TestResult {
  name: string;
  passed: boolean;
  detail?: string;
}

async function runTests() {
  const rules = fs.readFileSync(path.resolve(process.cwd(), 'firestore.rules'), 'utf8');
  const testEnv: RulesTestEnvironment = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: '127.0.0.1',
      port: 8080,
    },
  });

  const results: TestResult[] = [];
  const record = async (name: string, fn: () => Promise<void>) => {
    try {
      await fn();
      results.push({ name, passed: true });
      console.log(`PASS: ${name}`);
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      results.push({ name, passed: false, detail });
      console.error(`FAIL: ${name} -> ${detail}`);
    }
  };

  try {
    await testEnv.clearFirestore();

    const utcMinute = new Date().getUTCMinutes();
    const expectedCooldownMs = utcMinute < 30 ? 1000 : 500;
    console.log(
      `Emulator test UTC minute=${utcMinute}, active expected phase cooldown=${expectedCooldownMs}ms`
    );

    const aliceUid = 'aliceUser001';
    const bobUid = 'bobUser002';
    const disabledUid = 'disabledUser003';

    const unauthDb = testEnv.unauthenticatedContext().firestore();
    const aliceDb = testEnv.authenticatedContext(aliceUid).firestore();
    const bobDb = testEnv.authenticatedContext(bobUid).firestore();
    const disabledDb = testEnv.authenticatedContext(disabledUid).firestore();

    // 1. Permission Denied: unauthenticated pixel write
    await record('İzin Reddi: Giriş yapmamış kullanıcı piksel yazamaz', async () => {
      await assertFails(
        setDoc(doc(unauthDb, 'pixels', '10_10'), {
          x: 10,
          y: 10,
          color: '#EF4444',
          authorId: aliceUid,
          authorUsername: 'Alice',
          placedAt: Date.now(),
          updatedAt: serverTimestamp(),
        })
      );
    });

    // 2. Permission Denied: user without users/{uid} profile cannot write pixel
    await record('İzin Reddi: users/{uid} profili olmadan piksel yazılamaz', async () => {
      const batch = writeBatch(aliceDb);
      batch.set(doc(aliceDb, 'pixels', '10_10'), {
        x: 10,
        y: 10,
        color: '#EF4444',
        authorId: aliceUid,
        authorUsername: 'Alice',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(aliceDb, 'cooldowns', aliceUid), {
        userId: aliceUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertFails(batch.commit());
    });

    // 3. Atomic user + publicProfile enforcement: users/{uid} alone must fail
    await record('İzin Reddi: users/{uid} tek başına publicProfiles olmadan oluşturulamaz', async () => {
      await assertFails(
        setDoc(doc(aliceDb, 'users', aliceUid), {
          id: aliceUid,
          username: 'Alice',
          bio: 'Test',
          countryCode: 'TR',
          accentColor: '#F59E0B',
          emblem: 'compass',
          totalPixelsPlaced: 0,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        })
      );
    });

    // 4. Permission Denied: user cannot self-assign owner role or fake totalPixelsPlaced
    await record('İzin Reddi: Kullanıcı kendi rolünü owner veya totalPixelsPlaced > 0 yapamaz', async () => {
      const batch = writeBatch(aliceDb);
      const now = Date.now();
      batch.set(doc(aliceDb, 'users', aliceUid), {
        id: aliceUid,
        username: 'Alice',
        bio: 'Test',
        countryCode: 'TR',
        accentColor: '#F59E0B',
        emblem: 'compass',
        totalPixelsPlaced: 5,
        role: 'owner',
        createdAt: now,
        updatedAt: now,
      });
      batch.set(doc(aliceDb, 'publicProfiles', aliceUid), {
        id: aliceUid,
        username: 'Alice',
        bio: 'Test',
        countryCode: 'TR',
        accentColor: '#F59E0B',
        emblem: 'compass',
        totalPixelsPlaced: 5,
        role: 'owner',
        updatedAt: now,
      });
      await assertFails(batch.commit());
    });

    // 5. Atomic user + publicProfiles creation succeeds
    await record('Atomik Profil: users/{uid} + publicProfiles/{uid} birlikte oluşturulur', async () => {
      const now = Date.now();
      const batch = writeBatch(aliceDb);
      batch.set(doc(aliceDb, 'users', aliceUid), {
        id: aliceUid,
        username: 'Alice',
        bio: 'PixNation kaşifi.',
        countryCode: 'TR',
        accentColor: '#F59E0B',
        emblem: 'compass',
        totalPixelsPlaced: 0,
        createdAt: now,
        updatedAt: now,
      });
      batch.set(doc(aliceDb, 'publicProfiles', aliceUid), {
        id: aliceUid,
        username: 'Alice',
        bio: 'PixNation kaşifi.',
        countryCode: 'TR',
        accentColor: '#F59E0B',
        emblem: 'compass',
        totalPixelsPlaced: 0,
        updatedAt: now,
      });
      await assertSucceeds(batch.commit());

      // Also create Bob's profile atomically
      const bobBatch = writeBatch(bobDb);
      bobBatch.set(doc(bobDb, 'users', bobUid), {
        id: bobUid,
        username: 'Bob',
        bio: 'PixNation kaşifi.',
        countryCode: 'TR',
        accentColor: '#EF4444',
        emblem: 'star',
        totalPixelsPlaced: 0,
        createdAt: now,
        updatedAt: now,
      });
      bobBatch.set(doc(bobDb, 'publicProfiles', bobUid), {
        id: bobUid,
        username: 'Bob',
        bio: 'PixNation kaşifi.',
        countryCode: 'TR',
        accentColor: '#EF4444',
        emblem: 'star',
        totalPixelsPlaced: 0,
        updatedAt: now,
      });
      await assertSucceeds(bobBatch.commit());
    });

    // 6. Permission Denied: placing pixel without atomic cooldown batch
    await record('İzin Reddi: Cooldown belgesi olmadan tek başına piksel yazılamaz', async () => {
      await assertFails(
        setDoc(doc(aliceDb, 'pixels', '10_10'), {
          x: 10,
          y: 10,
          color: '#EF4444',
          authorId: aliceUid,
          authorUsername: 'Alice',
          placedAt: Date.now(),
          updatedAt: serverTimestamp(),
        })
      );
    });

    // 7. Permission Denied: authorUsername spoofing
    await record('İzin Reddi: Farklı authorUsername ile piksel yazılamaz', async () => {
      const batch = writeBatch(aliceDb);
      batch.set(doc(aliceDb, 'pixels', '10_10'), {
        x: 10,
        y: 10,
        color: '#EF4444',
        authorId: aliceUid,
        authorUsername: 'SahteIsim',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(aliceDb, 'cooldowns', aliceUid), {
        userId: aliceUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertFails(batch.commit());
    });

    // 8. First Pixel: Atomic WriteBatch (pixels + cooldowns) succeeds
    await record('İlk Piksel: Atomik WriteBatch (pixels + cooldowns) başarılı', async () => {
      const batch = writeBatch(aliceDb);
      batch.set(doc(aliceDb, 'pixels', '10_10'), {
        x: 10,
        y: 10,
        color: '#EF4444',
        authorId: aliceUid,
        authorUsername: 'Alice',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(aliceDb, 'cooldowns', aliceUid), {
        userId: aliceUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertSucceeds(batch.commit());
    });

    // 9. Cooldown Boundary (Immediate / Before Cooldown): Next pixel must fail
    await record('Cooldown Sınırı (Bekleme Dolmadan): Hemen atılan ikinci piksel reddedilir', async () => {
      const batch = writeBatch(aliceDb);
      batch.set(doc(aliceDb, 'pixels', '11_11'), {
        x: 11,
        y: 11,
        color: '#10B981',
        authorId: aliceUid,
        authorUsername: 'Alice',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(aliceDb, 'cooldowns', aliceUid), {
        userId: aliceUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertFails(batch.commit());
    });

    // 10. Cooldown Boundary (Just below active threshold): e.g. 250ms in 500ms phase or 750ms in 1000ms phase -> fail
    await record(
      `Cooldown Sınırı (${expectedCooldownMs - 200}ms geçti < ${expectedCooldownMs}ms): Reddedilir`,
      async () => {
        await testEnv.withSecurityRulesDisabled(async (ctx) => {
          const adminFs = ctx.firestore();
          await setDoc(doc(adminFs, 'cooldowns', aliceUid), {
            userId: aliceUid,
            lastPlacedAt: Timestamp.fromMillis(Date.now() - (expectedCooldownMs - 250)),
          });
        });

        const batch = writeBatch(aliceDb);
        batch.set(doc(aliceDb, 'pixels', '12_12'), {
          x: 12,
          y: 12,
          color: '#3B82F6',
          authorId: aliceUid,
          authorUsername: 'Alice',
          placedAt: Date.now(),
          updatedAt: serverTimestamp(),
        });
        batch.set(doc(aliceDb, 'cooldowns', aliceUid), {
          userId: aliceUid,
          lastPlacedAt: serverTimestamp(),
        });
        await assertFails(batch.commit());
      }
    );

    // 11. Cooldown Boundary (Wait >= active cooldown): Next pixel succeeds
    await record(
      `Sonraki Piksel (${expectedCooldownMs}ms dolduktan sonra): İkinci piksel başarılı`,
      async () => {
        await sleep(350); // total elapsed since seeded - (expectedCooldownMs - 250) is now >= expectedCooldownMs + 100ms
        const batch = writeBatch(aliceDb);
        batch.set(doc(aliceDb, 'pixels', '13_13'), {
          x: 13,
          y: 13,
          color: '#3B82F6',
          authorId: aliceUid,
          authorUsername: 'Alice',
          placedAt: Date.now(),
          updatedAt: serverTimestamp(),
        });
        batch.set(doc(aliceDb, 'cooldowns', aliceUid), {
          userId: aliceUid,
          lastPlacedAt: serverTimestamp(),
        });
        await assertSucceeds(batch.commit());
      }
    );

    // 12. Overwrite Protection: Bob cannot overwrite Alice's pixel at 10_10
    await record('İzin Reddi: Başka kullanıcı (Bob) Alice pikselinin üzerine yazamaz', async () => {
      const batch = writeBatch(bobDb);
      batch.set(doc(bobDb, 'pixels', '10_10'), {
        x: 10,
        y: 10,
        color: '#111827',
        authorId: bobUid,
        authorUsername: 'Bob',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(bobDb, 'cooldowns', bobUid), {
        userId: bobUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertFails(batch.commit());
    });

    // 13. Author updating own pixel after cooldown succeeds
    await record('Sonraki Piksel (Kendi Pikseli): Süre dolunca kendi pikselini güncelleyebilir', async () => {
      await sleep(expectedCooldownMs + 100);
      const batch = writeBatch(aliceDb);
      batch.set(doc(aliceDb, 'pixels', '10_10'), {
        x: 10,
        y: 10,
        color: '#F59E0B',
        authorId: aliceUid,
        authorUsername: 'Alice',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(aliceDb, 'cooldowns', aliceUid), {
        userId: aliceUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertSucceeds(batch.commit());
    });

    // 14. Disabled user cannot place pixel
    await record('İzin Reddi: Askıya alınmış (disabled: true) kullanıcı piksel yazamaz', async () => {
      await testEnv.withSecurityRulesDisabled(async (ctx) => {
        const adminFs = ctx.firestore();
        const now = Date.now();
        await setDoc(doc(adminFs, 'users', disabledUid), {
          id: disabledUid,
          username: 'BannedUser',
          bio: '',
          countryCode: 'TR',
          accentColor: '#EF4444',
          emblem: 'compass',
          totalPixelsPlaced: 0,
          disabled: true,
          createdAt: now,
          updatedAt: now,
        });
      });

      const batch = writeBatch(disabledDb);
      batch.set(doc(disabledDb, 'pixels', '20_20'), {
        x: 20,
        y: 20,
        color: '#EF4444',
        authorId: disabledUid,
        authorUsername: 'BannedUser',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(disabledDb, 'cooldowns', disabledUid), {
        userId: disabledUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertFails(batch.commit());
    });

    // 15. Atomic username update across users + publicProfiles and pixel authorUsername consistency
    await record('Atomik Kullanıcı Adı Güncelleme + Yeni Kullanıcı Adıyla Piksel', async () => {
      const now = Date.now();
      // Updating users alone without publicProfiles must fail
      await assertFails(
        updateDoc(doc(aliceDb, 'users', aliceUid), {
          username: 'AliceNew',
          updatedAt: now,
        })
      );

      // Atomic batch updating both must succeed
      const uBatch = writeBatch(aliceDb);
      uBatch.update(doc(aliceDb, 'users', aliceUid), {
        username: 'AliceNew',
        updatedAt: now,
      });
      uBatch.update(doc(aliceDb, 'publicProfiles', aliceUid), {
        username: 'AliceNew',
        updatedAt: now,
      });
      await assertSucceeds(uBatch.commit());

      await sleep(expectedCooldownMs + 100);
      // Placing pixel with old username must fail
      const staleBatch = writeBatch(aliceDb);
      staleBatch.set(doc(aliceDb, 'pixels', '30_30'), {
        x: 30,
        y: 30,
        color: '#10B981',
        authorId: aliceUid,
        authorUsername: 'Alice',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      staleBatch.set(doc(aliceDb, 'cooldowns', aliceUid), {
        userId: aliceUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertFails(staleBatch.commit());

      // Placing pixel with new username succeeds
      const freshBatch = writeBatch(aliceDb);
      freshBatch.set(doc(aliceDb, 'pixels', '30_30'), {
        x: 30,
        y: 30,
        color: '#10B981',
        authorId: aliceUid,
        authorUsername: 'AliceNew',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      freshBatch.set(doc(aliceDb, 'cooldowns', aliceUid), {
        userId: aliceUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertSucceeds(freshBatch.commit());

      const snap = await getDoc(doc(aliceDb, 'pixels', '30_30'));
      if (!snap.exists() || snap.data()?.authorUsername !== 'AliceNew') {
        throw new Error('Piksel yeni kullanıcı adıyla okunamadı');
      }
    });

    // 16. Connection health probe (/test/connection) & pixels list
    await record('Sağlık Probu (/test/connection get izinli, write reddedilir)', async () => {
      await assertSucceeds(getDoc(doc(unauthDb, 'test', 'connection')));
      await assertFails(
        setDoc(doc(aliceDb, 'test', 'connection'), { ok: true })
      );
    });

    // 17. Moderator Custom Claim can update and delete another player's pixel (when not disabled)
    await record('Yetki: Moderator Custom Claim başka oyuncunun pikselini güncelleyip silebilir', async () => {
      const modUid = 'modUser004';
      const modDb = testEnv.authenticatedContext(modUid, { role: 'moderator' }).firestore();
      await testEnv.withSecurityRulesDisabled(async (ctx) => {
        const now = Date.now();
        await setDoc(doc(ctx.firestore(), 'users', modUid), {
          id: modUid,
          username: 'ModMaster',
          bio: 'Mod',
          countryCode: 'TR',
          accentColor: '#3B82F6',
          emblem: 'crown',
          totalPixelsPlaced: 0,
          role: 'moderator',
          disabled: false,
          createdAt: now,
          updatedAt: now,
        });
      });

      const modBatch = writeBatch(modDb);
      modBatch.set(doc(modDb, 'pixels', '10_10'), {
        x: 10,
        y: 10,
        color: '#111827',
        authorId: modUid,
        authorUsername: 'ModMaster',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      modBatch.set(doc(modDb, 'cooldowns', modUid), {
        userId: modUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertSucceeds(modBatch.commit());
      await assertSucceeds(testEnv.authenticatedContext(modUid, { role: 'moderator' }).firestore() && (await import('firebase/firestore')).deleteDoc(doc(modDb, 'pixels', '10_10')));
    });

    // 18. Owner profile created by server keeps role='owner' and totalPixelsPlaced while allowing bio/username update
    await record('Owner Profili: Sunucu tarafından verilen role ve sayaç korunarak profil güncellenir', async () => {
      const ownerUid = 'ownerUser005';
      const ownerDb = testEnv.authenticatedContext(ownerUid, { role: 'owner' }).firestore();
      const now = Date.now();
      await testEnv.withSecurityRulesDisabled(async (ctx) => {
        const adminFs = ctx.firestore();
        await setDoc(doc(adminFs, 'users', ownerUid), {
          id: ownerUid,
          username: 'Kurucu',
          bio: 'İlk sahip',
          countryCode: 'TR',
          accentColor: '#F59E0B',
          emblem: 'crown',
          totalPixelsPlaced: 42,
          role: 'owner',
          disabled: false,
          createdAt: now,
          updatedAt: now,
        });
        await setDoc(doc(adminFs, 'publicProfiles', ownerUid), {
          id: ownerUid,
          username: 'Kurucu',
          bio: 'İlk sahip',
          countryCode: 'TR',
          accentColor: '#F59E0B',
          emblem: 'crown',
          totalPixelsPlaced: 42,
          role: 'owner',
          updatedAt: now,
        });
      });

      // Counter tamper attempt must fail
      const badBatch = writeBatch(ownerDb);
      badBatch.update(doc(ownerDb, 'users', ownerUid), {
        totalPixelsPlaced: 999,
        updatedAt: Date.now(),
      });
      badBatch.update(doc(ownerDb, 'publicProfiles', ownerUid), {
        totalPixelsPlaced: 999,
        updatedAt: Date.now(),
      });
      await assertFails(badBatch.commit());

      // Valid username/bio update preserves role and totalPixelsPlaced
      const goodBatch = writeBatch(ownerDb);
      const t = Date.now();
      goodBatch.update(doc(ownerDb, 'users', ownerUid), {
        username: 'KurucuTR',
        bio: 'Güncel biyografi',
        updatedAt: t,
      });
      goodBatch.update(doc(ownerDb, 'publicProfiles', ownerUid), {
        username: 'KurucuTR',
        bio: 'Güncel biyografi',
        updatedAt: t,
      });
      await assertSucceeds(goodBatch.commit());
    });

    // 19. Global Chat anti-spoofing
    await record('Sohbet Kuralları: Doğru kullanıcı adı/rolü geçer, sahte isim veya sahte rol reddedilir', async () => {
      await assertFails(
        setDoc(doc(aliceDb, 'chat', 'msg_bad_user'), {
          authorId: aliceUid,
          authorUsername: 'Sahte',
          text: 'Merhaba',
          createdAt: serverTimestamp(),
        })
      );
      await assertFails(
        setDoc(doc(aliceDb, 'chat', 'msg_bad_role'), {
          authorId: aliceUid,
          authorUsername: 'AliceNew',
          authorRole: 'owner',
          text: 'Merhaba',
          createdAt: serverTimestamp(),
        })
      );
      await assertSucceeds(
        setDoc(doc(aliceDb, 'chat', 'msg_ok_1'), {
          authorId: aliceUid,
          authorUsername: 'AliceNew',
          authorColor: '#10B981',
          authorRole: 'player',
          text: 'Merhaba PixNation!',
          createdAt: serverTimestamp(),
        })
      );
    });

    // 20. Global Chat length limits (empty & >240 fail; 240 via addDoc succeeds) + unauth read fails
    await record('Sohbet Sınırları: Boş ve 241 karakter reddedilir, 240 karakter addDoc geçer, giriş yapmamış okuyamaz', async () => {
      await assertFails(getDocs(query(collection(unauthDb, 'chat'), limit(10))));

      await assertFails(
        addDoc(collection(aliceDb, 'chat'), {
          authorId: aliceUid,
          authorUsername: 'AliceNew',
          authorColor: '#10B981',
          authorRole: 'player',
          text: '',
          createdAt: serverTimestamp(),
        })
      );

      await assertFails(
        addDoc(collection(aliceDb, 'chat'), {
          authorId: aliceUid,
          authorUsername: 'AliceNew',
          authorColor: '#10B981',
          authorRole: 'player',
          text: 'a'.repeat(241),
          createdAt: serverTimestamp(),
        })
      );

      await assertSucceeds(
        addDoc(collection(aliceDb, 'chat'), {
          authorId: aliceUid,
          authorUsername: 'AliceNew',
          authorColor: '#10B981',
          authorRole: 'player',
          text: 'a'.repeat(240),
          createdAt: serverTimestamp(),
        })
      );
    });

    // 21. Global Chat Owner/Moderator query read & delete rules
    await record('Sohbet Okuma/Rol/Silme: Owner mesajı addDoc + Bob okuma + yetkisiz silme reddi + moderatör silme geçer', async () => {
      const ownerUid = 'ownerUser005';
      const ownerDb = testEnv.authenticatedContext(ownerUid, { role: 'owner' }).firestore();
      const modDb = testEnv.authenticatedContext('modUser004', { role: 'moderator' }).firestore();

      const ownerMsgRef = await assertSucceeds(
        addDoc(collection(ownerDb, 'chat'), {
          authorId: ownerUid,
          authorUsername: 'KurucuTR',
          authorColor: '#F59E0B',
          authorRole: 'owner',
          text: 'Owner duyurusu!',
          createdAt: serverTimestamp(),
        })
      );

      const chatListSnap = await assertSucceeds(
        getDocs(query(collection(bobDb, 'chat'), orderBy('createdAt', 'desc'), limit(80)))
      );
      if (chatListSnap.empty) {
        throw new Error('Bob genel sohbet mesajlarını okuyamadı');
      }

      // Bob cannot delete Owner's message
      await assertFails(deleteDoc(doc(bobDb, 'chat', ownerMsgRef.id)));
      // Moderator can delete message
      await assertSucceeds(deleteDoc(doc(modDb, 'chat', ownerMsgRef.id)));
    });

    // -------------------------------------------------------
    // MODERATION SYSTEM SECURITY TESTS
    // -------------------------------------------------------
    const adminUid = 'adminUser006';
    const admin2Uid = 'adminUser007';
    const ownerUid = 'ownerUser005';
    const modUid = 'modUser004';
    const adminDb = testEnv.authenticatedContext(adminUid, { role: 'admin' }).firestore();
    const ownerDb = testEnv.authenticatedContext(ownerUid, { role: 'owner' }).firestore();
    const modDb = testEnv.authenticatedContext(modUid, { role: 'moderator' }).firestore();

    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const adminFs = ctx.firestore();
      const now = Date.now();
      await setDoc(doc(adminFs, 'users', adminUid), {
        id: adminUid,
        username: 'AdminOne',
        bio: '',
        countryCode: 'TR',
        accentColor: '#EF4444',
        emblem: 'star',
        totalPixelsPlaced: 0,
        role: 'admin',
        disabled: false,
        createdAt: now,
        updatedAt: now,
      });
      await setDoc(doc(adminFs, 'users', admin2Uid), {
        id: admin2Uid,
        username: 'AdminTwo',
        bio: '',
        countryCode: 'TR',
        accentColor: '#EF4444',
        emblem: 'star',
        totalPixelsPlaced: 0,
        role: 'admin',
        disabled: false,
        createdAt: now,
        updatedAt: now,
      });
    });

    const buildModDoc = (opts: {
      targetUid: string;
      targetUsername: string;
      targetRole: 'player' | 'moderator' | 'admin' | 'owner';
      lastLogId: string;
      mute?: {
        active: boolean;
        reason: string;
        durationKey: '5m' | '1h' | '24h' | 'permanent' | '';
        permanent: boolean;
        actorUid: string;
        actorUsername: string;
        actorRole: 'owner' | 'admin' | '';
        expiresAt: Timestamp | null;
      };
      ban?: {
        active: boolean;
        reason: string;
        durationKey: '1h' | '24h' | '7d' | 'permanent' | '';
        permanent: boolean;
        actorUid: string;
        actorUsername: string;
        actorRole: 'owner' | 'admin' | '';
        expiresAt: Timestamp | null;
      };
    }) => {
      const m = opts.mute;
      const b = opts.ban;
      return {
        userId: opts.targetUid,
        targetUsername: opts.targetUsername,
        targetRole: opts.targetRole,
        muteActive: m ? m.active : false,
        muteReason: m && m.active ? m.reason : '',
        muteDurationKey: m && m.active ? m.durationKey : '',
        mutePermanent: m && m.active ? m.permanent : false,
        muteActorUid: m && m.active ? m.actorUid : '',
        muteActorUsername: m && m.active ? m.actorUsername : '',
        muteActorRole: m && m.active ? m.actorRole : '',
        muteStartedAt: m && m.active ? serverTimestamp() : null,
        muteExpiresAt: m && m.active ? m.expiresAt : null,
        banActive: b ? b.active : false,
        banReason: b && b.active ? b.reason : '',
        banDurationKey: b && b.active ? b.durationKey : '',
        banPermanent: b && b.active ? b.permanent : false,
        banActorUid: b && b.active ? b.actorUid : '',
        banActorUsername: b && b.active ? b.actorUsername : '',
        banActorRole: b && b.active ? b.actorRole : '',
        banStartedAt: b && b.active ? serverTimestamp() : null,
        banExpiresAt: b && b.active ? b.expiresAt : null,
        lastLogId: opts.lastLogId,
        updatedAt: serverTimestamp(),
      };
    };

    // 22. Normal player & Moderator cannot issue mute or ban
    await record('Moderasyon Yetki: Normal oyuncu ve Moderator susturma/ban uygulayamaz', async () => {
      for (const [actorDb, actorId, actorName, actorRole] of [
        [bobDb, bobUid, 'Bob', 'admin'],
        [modDb, modUid, 'ModMaster', 'moderator'],
      ] as const) {
        const b = writeBatch(actorDb);
        const logId = `log_unauth_${actorId}`;
        b.set(
          doc(actorDb, 'moderation', aliceUid),
          buildModDoc({
            targetUid: aliceUid,
            targetUsername: 'AliceNew',
            targetRole: 'player',
            lastLogId: logId,
            mute: {
              active: true,
              reason: 'Yetkisiz deneme',
              durationKey: '5m',
              permanent: false,
              actorUid: actorId,
              actorUsername: actorName,
              actorRole: actorRole === 'admin' ? 'admin' : 'owner',
              expiresAt: Timestamp.fromMillis(Date.now() + 5 * 60 * 1000),
            },
          })
        );
        b.set(doc(actorDb, 'moderationLogs', logId), {
          action: 'mute',
          actorUid: actorId,
          actorUsername: actorName,
          actorRole: actorRole === 'admin' ? 'admin' : 'owner',
          targetUid: aliceUid,
          targetUsername: 'AliceNew',
          targetRole: 'player',
          reason: 'Yetkisiz deneme',
          durationKey: '5m',
          durationMs: 300000,
          permanent: false,
          expiresAt: Timestamp.fromMillis(Date.now() + 5 * 60 * 1000),
          createdAt: serverTimestamp(),
        });
        await assertFails(b.commit());
      }
    });

    // 23. Role hierarchy: Admin cannot penalize Moderator/Admin/Owner; Owner cannot ban/mute Admin/Owner; nobody can self-penalize
    await record('Moderasyon Hiyerarşisi: Owner Admini banlayamaz, Admin yalnızca normal oyuncuyu cezalandırabilir', async () => {
      // Owner trying to ban Admin -> MUST FAIL
      const ownerBanAdmin = writeBatch(ownerDb);
      ownerBanAdmin.set(
        doc(ownerDb, 'moderation', adminUid),
        buildModDoc({
          targetUid: adminUid,
          targetUsername: 'AdminOne',
          targetRole: 'admin',
          lastLogId: 'log_owner_ban_admin',
          ban: {
            active: true,
            reason: 'Admin yasaklanamaz',
            durationKey: '1h',
            permanent: false,
            actorUid: ownerUid,
            actorUsername: 'KurucuTR',
            actorRole: 'owner',
            expiresAt: Timestamp.fromMillis(Date.now() + 3600 * 1000),
          },
        })
      );
      ownerBanAdmin.set(doc(ownerDb, 'moderationLogs', 'log_owner_ban_admin'), {
        action: 'ban',
        actorUid: ownerUid,
        actorUsername: 'KurucuTR',
        actorRole: 'owner',
        targetUid: adminUid,
        targetUsername: 'AdminOne',
        targetRole: 'admin',
        reason: 'Admin yasaklanamaz',
        durationKey: '1h',
        durationMs: 3600000,
        permanent: false,
        expiresAt: Timestamp.fromMillis(Date.now() + 3600 * 1000),
        createdAt: serverTimestamp(),
      });
      await assertFails(ownerBanAdmin.commit());

      // Admin trying to mute Moderator -> MUST FAIL
      const adminMuteMod = writeBatch(adminDb);
      adminMuteMod.set(
        doc(adminDb, 'moderation', modUid),
        buildModDoc({
          targetUid: modUid,
          targetUsername: 'ModMaster',
          targetRole: 'moderator',
          lastLogId: 'log_admin_mute_mod',
          mute: {
            active: true,
            reason: 'Yetki dışı hedef',
            durationKey: '5m',
            permanent: false,
            actorUid: adminUid,
            actorUsername: 'AdminOne',
            actorRole: 'admin',
            expiresAt: Timestamp.fromMillis(Date.now() + 5 * 60 * 1000),
          },
        })
      );
      adminMuteMod.set(doc(adminDb, 'moderationLogs', 'log_admin_mute_mod'), {
        action: 'mute',
        actorUid: adminUid,
        actorUsername: 'AdminOne',
        actorRole: 'admin',
        targetUid: modUid,
        targetUsername: 'ModMaster',
        targetRole: 'moderator',
        reason: 'Yetki dışı hedef',
        durationKey: '5m',
        durationMs: 300000,
        permanent: false,
        expiresAt: Timestamp.fromMillis(Date.now() + 5 * 60 * 1000),
        createdAt: serverTimestamp(),
      });
      await assertFails(adminMuteMod.commit());

      // Admin trying to ban another Admin -> MUST FAIL
      const adminBanAdmin = writeBatch(adminDb);
      adminBanAdmin.set(
        doc(adminDb, 'moderation', admin2Uid),
        buildModDoc({
          targetUid: admin2Uid,
          targetUsername: 'AdminTwo',
          targetRole: 'admin',
          lastLogId: 'log_admin_ban_admin',
          ban: {
            active: true,
            reason: 'Admin yasaklanamaz',
            durationKey: '1h',
            permanent: false,
            actorUid: adminUid,
            actorUsername: 'AdminOne',
            actorRole: 'admin',
            expiresAt: Timestamp.fromMillis(Date.now() + 3600 * 1000),
          },
        })
      );
      adminBanAdmin.set(doc(adminDb, 'moderationLogs', 'log_admin_ban_admin'), {
        action: 'ban',
        actorUid: adminUid,
        actorUsername: 'AdminOne',
        actorRole: 'admin',
        targetUid: admin2Uid,
        targetUsername: 'AdminTwo',
        targetRole: 'admin',
        reason: 'Admin yasaklanamaz',
        durationKey: '1h',
        durationMs: 3600000,
        permanent: false,
        expiresAt: Timestamp.fromMillis(Date.now() + 3600 * 1000),
        createdAt: serverTimestamp(),
      });
      await assertFails(adminBanAdmin.commit());
    });

    // 24. Empty reason is rejected; Admin muting Alice (player) succeeds atomically with log
    await record('Susturma (Mute): Boş neden reddedilir, Admin geçerli nedenle Alice susturur', async () => {
      const emptyReasonBatch = writeBatch(adminDb);
      emptyReasonBatch.set(
        doc(adminDb, 'moderation', aliceUid),
        buildModDoc({
          targetUid: aliceUid,
          targetUsername: 'AliceNew',
          targetRole: 'player',
          lastLogId: 'log_empty_reason',
          mute: {
            active: true,
            reason: '',
            durationKey: '5m',
            permanent: false,
            actorUid: adminUid,
            actorUsername: 'AdminOne',
            actorRole: 'admin',
            expiresAt: Timestamp.fromMillis(Date.now() + 5 * 60 * 1000),
          },
        })
      );
      emptyReasonBatch.set(doc(adminDb, 'moderationLogs', 'log_empty_reason'), {
        action: 'mute',
        actorUid: adminUid,
        actorUsername: 'AdminOne',
        actorRole: 'admin',
        targetUid: aliceUid,
        targetUsername: 'AliceNew',
        targetRole: 'player',
        reason: '',
        durationKey: '5m',
        durationMs: 300000,
        permanent: false,
        expiresAt: Timestamp.fromMillis(Date.now() + 5 * 60 * 1000),
        createdAt: serverTimestamp(),
      });
      await assertFails(emptyReasonBatch.commit());

      const validMuteBatch = writeBatch(adminDb);
      const exp = Timestamp.fromMillis(Date.now() + 5 * 60 * 1000);
      validMuteBatch.set(
        doc(adminDb, 'moderation', aliceUid),
        buildModDoc({
          targetUid: aliceUid,
          targetUsername: 'AliceNew',
          targetRole: 'player',
          lastLogId: 'log_alice_mute_1',
          mute: {
            active: true,
            reason: 'Sohbette spam yaptığı için susturuldu',
            durationKey: '5m',
            permanent: false,
            actorUid: adminUid,
            actorUsername: 'AdminOne',
            actorRole: 'admin',
            expiresAt: exp,
          },
        })
      );
      validMuteBatch.set(doc(adminDb, 'moderationLogs', 'log_alice_mute_1'), {
        action: 'mute',
        actorUid: adminUid,
        actorUsername: 'AdminOne',
        actorRole: 'admin',
        targetUid: aliceUid,
        targetUsername: 'AliceNew',
        targetRole: 'player',
        reason: 'Sohbette spam yaptığı için susturuldu',
        durationKey: '5m',
        durationMs: 300000,
        permanent: false,
        expiresAt: exp,
        createdAt: serverTimestamp(),
      });
      await assertSucceeds(validMuteBatch.commit());
    });

    // 25. Muted user cannot send chat, CAN still place pixels, and CANNOT clear/alter own moderation
    await record('Susturma Etkisi: Susturulan Alice sohbete yazamaz, kendi cezasını silemez, ama piksel koyabilir', async () => {
      await assertFails(
        addDoc(collection(aliceDb, 'chat'), {
          authorId: aliceUid,
          authorUsername: 'AliceNew',
          authorColor: '#10B981',
          authorRole: 'player',
          text: 'Susturulmuşken mesaj denemesi',
          createdAt: serverTimestamp(),
        })
      );

      // Cannot alter own moderation doc
      await assertFails(
        updateDoc(doc(aliceDb, 'moderation', aliceUid), {
          muteActive: false,
        })
      );

      // Can read own moderation reason
      const ownMod = await assertSucceeds(getDoc(doc(aliceDb, 'moderation', aliceUid)));
      if (!ownMod.exists() || ownMod.data()?.muteActive !== true) {
        throw new Error('Alice kendi susturma kaydını okuyamadı');
      }

      // Bob cannot read Alice's moderation doc
      await assertFails(getDoc(doc(bobDb, 'moderation', aliceUid)));

      // Alice CAN still place a pixel while muted
      await sleep(expectedCooldownMs + 100);
      const pxBatch = writeBatch(aliceDb);
      pxBatch.set(doc(aliceDb, 'pixels', '50_50'), {
        x: 50,
        y: 50,
        color: '#2563EB',
        authorId: aliceUid,
        authorUsername: 'AliceNew',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      pxBatch.set(doc(aliceDb, 'cooldowns', aliceUid), {
        userId: aliceUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertSucceeds(pxBatch.commit());
    });

    // 26. Auto-expiration of Mute
    await record('Otomatik Susturma Kalkışı: Süre dolduğunda Alice tekrar sohbete yazabilir', async () => {
      await testEnv.withSecurityRulesDisabled(async (ctx) => {
        await updateDoc(doc(ctx.firestore(), 'moderation', aliceUid), {
          muteExpiresAt: Timestamp.fromMillis(Date.now() - 5000),
        });
      });

      await assertSucceeds(
        addDoc(collection(aliceDb, 'chat'), {
          authorId: aliceUid,
          authorUsername: 'AliceNew',
          authorColor: '#10B981',
          authorRole: 'player',
          text: 'Sürem doldu, merhaba!',
          createdAt: serverTimestamp(),
        })
      );
    });

    // 27. Ban enforcement: Banned player cannot place pixel OR send chat; Owner can moderate Moderator
    await record('Ban Etkisi: Banlı oyuncu piksel yerleştiremez ve sohbete yazamaz; Owner Moderatörü susturabilir', async () => {
      // Admin bans Alice for 1 hour
      const banExp = Timestamp.fromMillis(Date.now() + 60 * 60 * 1000);
      const banBatch = writeBatch(adminDb);
      banBatch.set(
        doc(adminDb, 'moderation', aliceUid),
        buildModDoc({
          targetUid: aliceUid,
          targetUsername: 'AliceNew',
          targetRole: 'player',
          lastLogId: 'log_alice_ban_1',
          ban: {
            active: true,
            reason: 'Haritada kural ihlali',
            durationKey: '1h',
            permanent: false,
            actorUid: adminUid,
            actorUsername: 'AdminOne',
            actorRole: 'admin',
            expiresAt: banExp,
          },
        })
      );
      banBatch.set(doc(adminDb, 'moderationLogs', 'log_alice_ban_1'), {
        action: 'ban',
        actorUid: adminUid,
        actorUsername: 'AdminOne',
        actorRole: 'admin',
        targetUid: aliceUid,
        targetUsername: 'AliceNew',
        targetRole: 'player',
        reason: 'Haritada kural ihlali',
        durationKey: '1h',
        durationMs: 3600000,
        permanent: false,
        expiresAt: banExp,
        createdAt: serverTimestamp(),
      });
      await assertSucceeds(banBatch.commit());

      // Banned Alice cannot place pixel
      await sleep(expectedCooldownMs + 100);
      const blockedPx = writeBatch(aliceDb);
      blockedPx.set(doc(aliceDb, 'pixels', '51_51'), {
        x: 51,
        y: 51,
        color: '#EF4444',
        authorId: aliceUid,
        authorUsername: 'AliceNew',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      blockedPx.set(doc(aliceDb, 'cooldowns', aliceUid), {
        userId: aliceUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertFails(blockedPx.commit());

      // Banned Alice cannot send chat
      await assertFails(
        addDoc(collection(aliceDb, 'chat'), {
          authorId: aliceUid,
          authorUsername: 'AliceNew',
          authorColor: '#10B981',
          authorRole: 'player',
          text: 'Banlıyken mesaj denemesi',
          createdAt: serverTimestamp(),
        })
      );

      // Owner CAN mute Moderator
      const modMuteExp = Timestamp.fromMillis(Date.now() + 5 * 60 * 1000);
      const ownerModBatch = writeBatch(ownerDb);
      ownerModBatch.set(
        doc(ownerDb, 'moderation', modUid),
        buildModDoc({
          targetUid: modUid,
          targetUsername: 'ModMaster',
          targetRole: 'moderator',
          lastLogId: 'log_owner_mute_mod',
          mute: {
            active: true,
            reason: 'Uyarı amaçlı susturma',
            durationKey: '5m',
            permanent: false,
            actorUid: ownerUid,
            actorUsername: 'KurucuTR',
            actorRole: 'owner',
            expiresAt: modMuteExp,
          },
        })
      );
      ownerModBatch.set(doc(ownerDb, 'moderationLogs', 'log_owner_mute_mod'), {
        action: 'mute',
        actorUid: ownerUid,
        actorUsername: 'KurucuTR',
        actorRole: 'owner',
        targetUid: modUid,
        targetUsername: 'ModMaster',
        targetRole: 'moderator',
        reason: 'Uyarı amaçlı susturma',
        durationKey: '5m',
        durationMs: 300000,
        permanent: false,
        expiresAt: modMuteExp,
        createdAt: serverTimestamp(),
      });
      await assertSucceeds(ownerModBatch.commit());
    });

    // 28. Auto-expiration of Ban + Audit log immutability + Admin Revoke
    await record('Otomatik Ban Kalkışı, Ceza Kaldırma (Unban) & Değiştirilemez Denetim Günlüğü', async () => {
      // Simulate ban expiry elapsed -> Alice immediately regains pixel & chat rights
      await testEnv.withSecurityRulesDisabled(async (ctx) => {
        await updateDoc(doc(ctx.firestore(), 'moderation', aliceUid), {
          banExpiresAt: Timestamp.fromMillis(Date.now() - 5000),
        });
      });

      const okPxAfterExpiry = writeBatch(aliceDb);
      okPxAfterExpiry.set(doc(aliceDb, 'pixels', '52_52'), {
        x: 52,
        y: 52,
        color: '#10B981',
        authorId: aliceUid,
        authorUsername: 'AliceNew',
        placedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      okPxAfterExpiry.set(doc(aliceDb, 'cooldowns', aliceUid), {
        userId: aliceUid,
        lastPlacedAt: serverTimestamp(),
      });
      await assertSucceeds(okPxAfterExpiry.commit());

      // Admin revokes ban record cleanly with unban audit log
      const unbanBatch = writeBatch(adminDb);
      unbanBatch.set(
        doc(adminDb, 'moderation', aliceUid),
        buildModDoc({
          targetUid: aliceUid,
          targetUsername: 'AliceNew',
          targetRole: 'player',
          lastLogId: 'log_alice_unban_1',
        })
      );
      unbanBatch.set(doc(adminDb, 'moderationLogs', 'log_alice_unban_1'), {
        action: 'unban',
        actorUid: adminUid,
        actorUsername: 'AdminOne',
        actorRole: 'admin',
        targetUid: aliceUid,
        targetUsername: 'AliceNew',
        targetRole: 'player',
        reason: 'İtiraz onaylandı',
        durationKey: 'none',
        durationMs: 0,
        permanent: false,
        expiresAt: null,
        createdAt: serverTimestamp(),
      });
      await assertSucceeds(unbanBatch.commit());

      // Audit logs cannot be updated or deleted even by Owner
      await assertFails(
        updateDoc(doc(ownerDb, 'moderationLogs', 'log_alice_unban_1'), {
          reason: 'Değiştirildi',
        })
      );
      await assertFails(deleteDoc(doc(ownerDb, 'moderationLogs', 'log_alice_unban_1')));
    });

    // 29. Simultaneous Mute + Ban & partial revocation (unmute keeps ban intact)
    await record('Eşzamanlı Ceza & Kısmi Kaldırma: Mute varken Ban eklenebilir, Unmute Banı bozmaz', async () => {
      const mExp = Timestamp.fromMillis(Date.now() + 60 * 60 * 1000);
      const bExp = Timestamp.fromMillis(Date.now() + 24 * 60 * 60 * 1000);

      // Step 1: Mute Alice for 1h
      const b1 = writeBatch(adminDb);
      b1.set(
        doc(adminDb, 'moderation', aliceUid),
        buildModDoc({
          targetUid: aliceUid,
          targetUsername: 'AliceNew',
          targetRole: 'player',
          lastLogId: 'log_sim_1',
          mute: {
            active: true,
            reason: 'Spam',
            durationKey: '1h',
            permanent: false,
            actorUid: adminUid,
            actorUsername: 'AdminOne',
            actorRole: 'admin',
            expiresAt: mExp,
          },
        })
      );
      b1.set(doc(adminDb, 'moderationLogs', 'log_sim_1'), {
        action: 'mute',
        actorUid: adminUid,
        actorUsername: 'AdminOne',
        actorRole: 'admin',
        targetUid: aliceUid,
        targetUsername: 'AliceNew',
        targetRole: 'player',
        reason: 'Spam',
        durationKey: '1h',
        durationMs: 3600000,
        permanent: false,
        expiresAt: mExp,
        createdAt: serverTimestamp(),
      });
      await assertSucceeds(b1.commit());

      // Step 2: Add 24h Ban while keeping existing Mute intact
      const b2 = writeBatch(adminDb);
      const aliceModSnap = await getDoc(doc(adminDb, 'moderation', aliceUid));
      const existingData = aliceModSnap.data()!;
      b2.set(doc(adminDb, 'moderation', aliceUid), {
        ...existingData,
        banActive: true,
        banReason: 'Griefing',
        banDurationKey: '24h',
        banPermanent: false,
        banActorUid: adminUid,
        banActorUsername: 'AdminOne',
        banActorRole: 'admin',
        banStartedAt: serverTimestamp(),
        banExpiresAt: bExp,
        lastLogId: 'log_sim_2',
        updatedAt: serverTimestamp(),
      });
      b2.set(doc(adminDb, 'moderationLogs', 'log_sim_2'), {
        action: 'ban',
        actorUid: adminUid,
        actorUsername: 'AdminOne',
        actorRole: 'admin',
        targetUid: aliceUid,
        targetUsername: 'AliceNew',
        targetRole: 'player',
        reason: 'Griefing',
        durationKey: '24h',
        durationMs: 86400000,
        permanent: false,
        expiresAt: bExp,
        createdAt: serverTimestamp(),
      });
      await assertSucceeds(b2.commit());
    });

    const failed = results.filter((r) => !r.passed);
    console.log(`\nMAIN RULES SUMMARY: ${results.length - failed.length}/${results.length} tests passed.`);

    // 16 & 17: Explicitly verify duration.value(500, 'ms') inside Firestore Rules engine
    // (simulating UTC minute 30..59 even when real clock is UTC 00..29, and vice-versa for 1s)
    const phase2Rules = rules.replace(
      "return serverTime.minutes() < 30\n        ? duration.value(1, 's')\n        : duration.value(500, 'ms');",
      "return false ? duration.value(1, 's') : duration.value(500, 'ms');"
    );
    if (phase2Rules === rules) {
      throw new Error('getGlobalCooldownDuration deseni bulunamadı.');
    }

    const phase2Env = await initializeTestEnvironment({
      projectId: `${PROJECT_ID}-phase2`,
      firestore: {
        rules: phase2Rules,
        host: '127.0.0.1',
        port: 8080,
      },
    });

    try {
      await phase2Env.clearFirestore();
      const p2AliceDb = phase2Env.authenticatedContext(aliceUid).firestore();
      const now = Date.now();
      const initBatch = writeBatch(p2AliceDb);
      initBatch.set(doc(p2AliceDb, 'users', aliceUid), {
        id: aliceUid,
        username: 'Alice500',
        bio: 'Test',
        countryCode: 'TR',
        accentColor: '#F59E0B',
        emblem: 'compass',
        totalPixelsPlaced: 0,
        createdAt: now,
        updatedAt: now,
      });
      initBatch.set(doc(p2AliceDb, 'publicProfiles', aliceUid), {
        id: aliceUid,
        username: 'Alice500',
        bio: 'Test',
        countryCode: 'TR',
        accentColor: '#F59E0B',
        emblem: 'compass',
        totalPixelsPlaced: 0,
        updatedAt: now,
      });
      await assertSucceeds(initBatch.commit());

      await record('500ms Fazı (300ms geçti < 500ms): Reddedilir', async () => {
        await phase2Env.withSecurityRulesDisabled(async (ctx) => {
          await setDoc(doc(ctx.firestore(), 'cooldowns', aliceUid), {
            userId: aliceUid,
            lastPlacedAt: Timestamp.fromMillis(Date.now() - 250),
          });
        });
        const b = writeBatch(p2AliceDb);
        b.set(doc(p2AliceDb, 'pixels', '40_40'), {
          x: 40,
          y: 40,
          color: '#EF4444',
          authorId: aliceUid,
          authorUsername: 'Alice500',
          placedAt: Date.now(),
          updatedAt: serverTimestamp(),
        });
        b.set(doc(p2AliceDb, 'cooldowns', aliceUid), {
          userId: aliceUid,
          lastPlacedAt: serverTimestamp(),
        });
        await assertFails(b.commit());
      });

      await record('500ms Fazı (550ms geçti >= 500ms): Başarılı (duration.value(500, "ms") destekli)', async () => {
        await sleep(320); // 250 + 320 = ~570ms >= 500ms (still < 1000ms!)
        const b = writeBatch(p2AliceDb);
        b.set(doc(p2AliceDb, 'pixels', '40_40'), {
          x: 40,
          y: 40,
          color: '#10B981',
          authorId: aliceUid,
          authorUsername: 'Alice500',
          placedAt: Date.now(),
          updatedAt: serverTimestamp(),
        });
        b.set(doc(p2AliceDb, 'cooldowns', aliceUid), {
          userId: aliceUid,
          lastPlacedAt: serverTimestamp(),
        });
        await assertSucceeds(b.commit());
      });
    } finally {
      await phase2Env.cleanup();
    }

    const totalFailed = results.filter((r) => !r.passed);
    console.log(`\nSUMMARY: ${results.length - totalFailed.length}/${results.length} tests passed.`);
    if (totalFailed.length > 0) {
      process.exitCode = 1;
    }
  } finally {
    await testEnv.cleanup();
  }
}

runTests().catch((err) => {
  console.error(err);
  process.exit(1);
});
