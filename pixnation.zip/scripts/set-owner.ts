import 'dotenv/config';
import { FieldValue } from 'firebase-admin/firestore';
import {
  adminAuth,
  adminDb,
  FIREBASE_PROJECT_ID,
  getAdminCredentialMode,
  isIamPermissionError,
} from '../server/firebaseAdmin';

const VALID_UID_REGEX = /^[a-zA-Z0-9_\-]{1,128}$/;

async function main() {
  const argUid = process.argv[2]?.trim();
  const envOwnerUid = process.env.INITIAL_OWNER_UID?.trim();
  const uid = argUid || envOwnerUid;

  if (!uid || !VALID_UID_REGEX.test(uid)) {
    console.error('Kullanım: npm run set-owner -- <FIREBASE_AUTH_UID>');
    process.exit(1);
  }

  if (envOwnerUid && uid !== envOwnerUid) {
    console.error(
      `Güvenlik kilidi: Verilen UID (${uid}), INITIAL_OWNER_UID (${envOwnerUid}) ile eşleşmiyor.`
    );
    process.exit(1);
  }

  try {
    const userRecord = await adminAuth.getUser(uid);
    if (userRecord.disabled) {
      console.error(`Bu Firebase Auth hesabı (${uid}) devre dışı bırakılmış.`);
      process.exit(1);
    }

    const configRef = adminDb.collection('system').doc('ownerConfig');
    const existingConfig = await configRef.get();

    if (
      existingConfig.exists &&
      existingConfig.data()?.initialOwnerUid &&
      existingConfig.data()?.initialOwnerUid !== uid
    ) {
      console.error(
        'İlk Owner zaten atanmış. Güvenlik nedeniyle ikinci bir ilk Owner ataması engellendi.'
      );
      process.exit(1);
    }

    await adminAuth.setCustomUserClaims(uid, { role: 'owner' });

    const userRef = adminDb.collection('users').doc(uid);
    const publicRef = adminDb.collection('publicProfiles').doc(uid);
    const now = Date.now();
    const fallbackName =
      (typeof userRecord.displayName === 'string' && userRecord.displayName.trim()
        ? userRecord.displayName.trim()
        : userRecord.email?.split('@')[0] || 'Owner'
      ).slice(0, 20);

    await adminDb.runTransaction(async (tx) => {
      const [uSnap, pSnap] = await Promise.all([tx.get(userRef), tx.get(publicRef)]);
      tx.set(
        configRef,
        {
          initialOwnerUid: uid,
          claimedAt:
            existingConfig.exists && typeof existingConfig.data()?.claimedAt === 'number'
              ? existingConfig.data()!.claimedAt
              : now,
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
      if (uSnap.exists) {
        tx.set(userRef, { id: uid, role: 'owner', updatedAt: now }, { merge: true });
      } else {
        tx.set(userRef, {
          id: uid,
          username: fallbackName,
          bio: 'PixNation kurucusu.',
          countryCode: 'TR',
          accentColor: '#F59E0B',
          emblem: 'crown',
          totalPixelsPlaced: 0,
          role: 'owner',
          disabled: false,
          createdAt: now,
          updatedAt: now,
        });
      }
      if (pSnap.exists) {
        tx.set(publicRef, { id: uid, role: 'owner', updatedAt: now }, { merge: true });
      } else {
        const uData = uSnap.exists ? uSnap.data() : null;
        tx.set(publicRef, {
          id: uid,
          username: typeof uData?.username === 'string' ? uData.username : fallbackName,
          bio: typeof uData?.bio === 'string' ? uData.bio : 'PixNation kurucusu.',
          countryCode: typeof uData?.countryCode === 'string' ? uData.countryCode : 'TR',
          accentColor: typeof uData?.accentColor === 'string' ? uData.accentColor : '#F59E0B',
          emblem: typeof uData?.emblem === 'string' ? uData.emblem : 'crown',
          totalPixelsPlaced:
            typeof uData?.totalPixelsPlaced === 'number' ? uData.totalPixelsPlaced : 0,
          role: 'owner',
          updatedAt: now,
        });
      }
    });

    console.log(`Owner yetkisi başarıyla verildi: ${userRecord.email ?? uid} (${uid})`);
    console.log('Kullanıcının yeni yetkiyi alması için "Yetkiyi Yenile" butonuna basması veya yeniden giriş yapması gerekir.');
  } catch (error) {
    if (isIamPermissionError(error)) {
      console.error(
        `Yetki/Kimlik Hatası (${getAdminCredentialMode()}): "${FIREBASE_PROJECT_ID}" projesi için Firebase Admin SDK yetkisi doğrulanamadı.`
      );
      console.error(
        'Çözüm: FIREBASE_SERVICE_ACCOUNT_JSON (veya GOOGLE_APPLICATION_CREDENTIALS) ayarlayın ya da çalışma ortamı servis hesabına "pixnation-b77f1" projesinde roles/firebaseauth.admin ve roles/datastore.user verin.'
      );
    } else {
      console.error('Owner atama işlemi başarısız:', error);
    }
    process.exit(1);
  }
}

void main();
