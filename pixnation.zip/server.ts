import 'dotenv/config';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import type { DecodedIdToken } from 'firebase-admin/auth';
import { FieldValue, Timestamp } from 'firebase-admin/firestore';
import { writeFile } from 'fs/promises';
import path from 'path';
import {
  adminAuth,
  adminDb,
  getAdminCredentialMode,
  getTokenRole,
  HttpError,
  isIamPermissionError,
  verifyCallerToken,
} from './server/firebaseAdmin.ts';
import type { ServerRole } from './server/firebaseAdmin.ts';

const PORT = Number(process.env.PORT) || 3000;
const WORLD_WIDTH = 2048;
const WORLD_HEIGHT = 2048;
const COOLDOWN_FIRST_PHASE_MS = 1_000;
const COOLDOWN_SECOND_PHASE_MS = 500;
const VALID_HEX_REGEX = /^#[0-9A-Fa-f]{6}$/;
const VALID_UID_REGEX = /^[a-zA-Z0-9_\-]{1,128}$/;

function getGlobalCooldownDurationMs(currentServerTimeMs: number): number {
  const minute = new Date(currentServerTimeMs).getUTCMinutes();
  return minute < 30 ? COOLDOWN_FIRST_PHASE_MS : COOLDOWN_SECOND_PHASE_MS;
}

interface AuthedRequest extends Request {
  caller?: DecodedIdToken;
}

async function requireAuthenticated(
  req: AuthedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    req.caller = await verifyCallerToken(req.headers.authorization, true);
    next();
  } catch (error) {
    if (error instanceof HttpError) {
      res.status(error.status).json({ error: error.message });
      return;
    }
    res.status(401).json({ error: 'Kimlik doğrulama başarısız.' });
  }
}

async function requireOwner(
  req: AuthedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const decoded = await verifyCallerToken(req.headers.authorization, true);
    if (getTokenRole(decoded) !== 'owner') {
      res.status(403).json({ error: 'Bu işlem yalnızca Owner yetkisine açıktır.' });
      return;
    }
    req.caller = decoded;
    next();
  } catch (error) {
    if (error instanceof HttpError) {
      res.status(error.status).json({ error: error.message });
      return;
    }
    res.status(403).json({ error: 'Owner yetkisi doğrulanamadı.' });
  }
}

async function requireOwnerOrAdmin(
  req: AuthedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const decoded = await verifyCallerToken(req.headers.authorization, true);
    const role = getTokenRole(decoded);
    if (role !== 'owner' && role !== 'admin') {
      res.status(403).json({ error: 'Bu işlem yalnızca Owner ve Admin yetkisine açıktır.' });
      return;
    }
    req.caller = decoded;
    next();
  } catch (error) {
    if (error instanceof HttpError) {
      res.status(error.status).json({ error: error.message });
      return;
    }
    res.status(403).json({ error: 'Yetki doğrulanamadı.' });
  }
}

const MUTE_DURATIONS_MS: Record<string, number | null> = {
  '5m': 5 * 60 * 1000,
  '1h': 60 * 60 * 1000,
  '24h': 24 * 60 * 60 * 1000,
  permanent: null,
};

const BAN_DURATIONS_MS: Record<string, number | null> = {
  '1h': 60 * 60 * 1000,
  '24h': 24 * 60 * 60 * 1000,
  '7d': 7 * 24 * 60 * 60 * 1000,
  permanent: null,
};

function formatRemainingTr(remainingMs: number): string {
  const totalSec = Math.max(1, Math.ceil(remainingMs / 1000));
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const minutes = Math.floor((totalSec % 3600) / 60);
  const seconds = totalSec % 60;
  if (days > 0) return `${days} gün ${hours} sa`;
  if (hours > 0) return `${hours} sa ${minutes} dk`;
  if (minutes > 0) return `${minutes} dk ${seconds} sn`;
  return `${seconds} sn`;
}

function getEffectiveRole(claimRole: unknown, firestoreRole: unknown): ServerRole {
  const fromClaim =
    claimRole === 'owner' || claimRole === 'admin' || claimRole === 'moderator'
      ? claimRole
      : null;
  if (fromClaim) return fromClaim;
  if (
    firestoreRole === 'owner' ||
    firestoreRole === 'admin' ||
    firestoreRole === 'moderator'
  ) {
    return firestoreRole;
  }
  return 'player';
}

function assertCanModerateTarget(callerRole: ServerRole, targetRole: ServerRole): void {
  if (targetRole === 'owner') {
    throw new HttpError(403, 'Owner hesabına ceza uygulanamaz.');
  }
  if (targetRole === 'admin') {
    throw new HttpError(403, 'Admin rolündeki oyuncular susturulamaz veya yasaklanamaz.');
  }
  if (callerRole === 'admin' && targetRole !== 'player') {
    throw new HttpError(403, 'Adminler yalnızca normal oyunculara ceza uygulayabilir.');
  }
  if (callerRole !== 'owner' && callerRole !== 'admin') {
    throw new HttpError(403, 'Bu işlem yalnızca Owner ve Admin yetkisine açıktır.');
  }
}

function handleServerError(res: Response, error: unknown, fallbackMsg: string): void {
  if (error instanceof HttpError) {
    res.status(error.status).json({ error: error.message });
    return;
  }
  if (isIamPermissionError(error)) {
    res.status(503).json({
      error:
        'Sunucu Firebase Admin SDK IAM izinleri (roles/firebaseauth.admin ve roles/datastore.user) henüz tanımlanmamış.',
      code: 'iam_not_configured',
    });
    return;
  }
  console.error(fallbackMsg, error);
  res.status(500).json({ error: fallbackMsg });
}

interface OwnerBootstrapVerification {
  checkedAt: string;
  targetUid: string | null;
  authUserExists: boolean;
  authUserDisabled: boolean;
  existingAuthOwnersCount: number;
  hasOtherOwner: boolean;
  existingConfigOwner: string | null;
  actionTaken:
    | 'assigned_owner'
    | 'already_owner'
    | 'skipped_no_initial_owner_uid'
    | 'stopped_admin_not_ready'
    | 'stopped_user_not_found'
    | 'stopped_user_disabled'
    | 'stopped_existing_other_owner'
    | 'stopped_error';
  verifiedClaimRole: string | null;
  verifiedConfigOwner: string | null;
  errorMessage?: string;
}

async function listExistingAuthOwnerUids(): Promise<string[]> {
  const owners: string[] = [];
  let pageToken: string | undefined;
  do {
    const page = await adminAuth.listUsers(1000, pageToken);
    for (const user of page.users) {
      if (user.customClaims?.role === 'owner') {
        owners.push(user.uid);
      }
    }
    pageToken = page.pageToken;
  } while (pageToken);
  return owners;
}

async function ensureInitialOwnerSetup(
  targetUid: string
): Promise<OwnerBootstrapVerification> {
  const checkedAt = new Date().toISOString();
  if (!targetUid || !VALID_UID_REGEX.test(targetUid)) {
    return {
      checkedAt,
      targetUid: targetUid || null,
      authUserExists: false,
      authUserDisabled: false,
      existingAuthOwnersCount: 0,
      hasOtherOwner: false,
      existingConfigOwner: null,
      actionTaken: 'skipped_no_initial_owner_uid',
      verifiedClaimRole: null,
      verifiedConfigOwner: null,
      errorMessage: 'Geçerli bir INITIAL_OWNER_UID tanımlı değil.',
    };
  }

  let targetUser;
  try {
    targetUser = await adminAuth.getUser(targetUid);
  } catch (err) {
    const code = (err as { code?: string })?.code;
    return {
      checkedAt,
      targetUid,
      authUserExists: false,
      authUserDisabled: false,
      existingAuthOwnersCount: 0,
      hasOtherOwner: false,
      existingConfigOwner: null,
      actionTaken:
        code === 'auth/user-not-found' ? 'stopped_user_not_found' : 'stopped_admin_not_ready',
      verifiedClaimRole: null,
      verifiedConfigOwner: null,
      errorMessage:
        code === 'auth/user-not-found'
          ? 'Hedef UID Firebase Authentication içinde bulunamadı.'
          : 'Firebase Auth Admin bağlantısı doğrulanamadı.',
    };
  }

  if (targetUser.disabled) {
    return {
      checkedAt,
      targetUid,
      authUserExists: true,
      authUserDisabled: true,
      existingAuthOwnersCount: 0,
      hasOtherOwner: false,
      existingConfigOwner: null,
      actionTaken: 'stopped_user_disabled',
      verifiedClaimRole:
        typeof targetUser.customClaims?.role === 'string'
          ? targetUser.customClaims.role
          : null,
      verifiedConfigOwner: null,
      errorMessage: 'Hedef Firebase Auth hesabı devre dışı bırakılmış.',
    };
  }

  const existingAuthOwners = await listExistingAuthOwnerUids();
  const otherAuthOwners = existingAuthOwners.filter((id) => id !== targetUid);

  const configRef = adminDb.collection('system').doc('ownerConfig');
  const existingConfigSnap = await configRef.get();
  const existingConfigOwnerRaw = existingConfigSnap.data()?.initialOwnerUid;
  const existingConfigOwner =
    typeof existingConfigOwnerRaw === 'string' && existingConfigOwnerRaw.trim()
      ? existingConfigOwnerRaw.trim()
      : null;

  if (otherAuthOwners.length > 0 || (existingConfigOwner && existingConfigOwner !== targetUid)) {
    return {
      checkedAt,
      targetUid,
      authUserExists: true,
      authUserDisabled: false,
      existingAuthOwnersCount: existingAuthOwners.length,
      hasOtherOwner: true,
      existingConfigOwner,
      actionTaken: 'stopped_existing_other_owner',
      verifiedClaimRole:
        typeof targetUser.customClaims?.role === 'string'
          ? targetUser.customClaims.role
          : null,
      verifiedConfigOwner: existingConfigOwner,
      errorMessage: 'Projede zaten başka bir Owner atanmış; mevcut Owner değiştirilmedi.',
    };
  }

  const alreadyOwnerInAuth = targetUser.customClaims?.role === 'owner';
  const userRef = adminDb.collection('users').doc(targetUid);
  const publicRef = adminDb.collection('publicProfiles').doc(targetUid);
  const now = Date.now();
  const fallbackUsername = (
    typeof targetUser.displayName === 'string' && targetUser.displayName.trim()
      ? targetUser.displayName.trim()
      : targetUser.email?.split('@')[0] || 'Owner'
  ).slice(0, 20);

  if (!alreadyOwnerInAuth) {
    await adminAuth.setCustomUserClaims(targetUid, {
      ...(targetUser.customClaims ?? {}),
      role: 'owner',
    });
  }

  await adminDb.runTransaction(async (tx) => {
    const [txConfig, txUser, txPublic] = await Promise.all([
      tx.get(configRef),
      tx.get(userRef),
      tx.get(publicRef),
    ]);
    const txConfigOwner = txConfig.data()?.initialOwnerUid;
    if (txConfig.exists && typeof txConfigOwner === 'string' && txConfigOwner !== targetUid) {
      throw new HttpError(409, 'İlk Owner zaten atanmış.');
    }

    tx.set(
      configRef,
      {
        initialOwnerUid: targetUid,
        claimedAt:
          txConfig.exists && typeof txConfig.data()?.claimedAt === 'number'
            ? txConfig.data()!.claimedAt
            : now,
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    if (txUser.exists) {
      tx.set(userRef, { id: targetUid, role: 'owner', updatedAt: now }, { merge: true });
    } else {
      tx.set(userRef, {
        id: targetUid,
        username: fallbackUsername,
        bio: 'PixNation kurucusu.',
        countryCode: 'TR',
        accentColor: '#F59E0B',
        emblem: 'crown',
        totalPixelsPlaced: 0,
        role: 'owner',
        disabled: false,
        createdAt: now,
        updatedAt: now,
      });
    }

    if (txPublic.exists) {
      tx.set(publicRef, { id: targetUid, role: 'owner', updatedAt: now }, { merge: true });
    } else {
      const uData = txUser.exists ? txUser.data() : null;
      tx.set(publicRef, {
        id: targetUid,
        username: typeof uData?.username === 'string' ? uData.username : fallbackUsername,
        bio: typeof uData?.bio === 'string' ? uData.bio : 'PixNation kurucusu.',
        countryCode: typeof uData?.countryCode === 'string' ? uData.countryCode : 'TR',
        accentColor: typeof uData?.accentColor === 'string' ? uData.accentColor : '#F59E0B',
        emblem: typeof uData?.emblem === 'string' ? uData.emblem : 'crown',
        totalPixelsPlaced:
          typeof uData?.totalPixelsPlaced === 'number' ? uData.totalPixelsPlaced : 0,
        role: 'owner',
        updatedAt: now,
      });
    }
  });

  const [verifiedUser, verifiedConfig] = await Promise.all([
    adminAuth.getUser(targetUid),
    configRef.get(),
  ]);

  return {
    checkedAt,
    targetUid,
    authUserExists: true,
    authUserDisabled: Boolean(verifiedUser.disabled),
    existingAuthOwnersCount: existingAuthOwners.length,
    hasOtherOwner: false,
    existingConfigOwner,
    actionTaken: alreadyOwnerInAuth ? 'already_owner' : 'assigned_owner',
    verifiedClaimRole:
      typeof verifiedUser.customClaims?.role === 'string'
        ? verifiedUser.customClaims.role
        : null,
    verifiedConfigOwner:
      typeof verifiedConfig.data()?.initialOwnerUid === 'string'
        ? verifiedConfig.data()!.initialOwnerUid
        : null,
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '64kb' }));

  let cachedAdminReady: { value: boolean; checkedAt: number } | null = null;

  async function isAdminSdkReady(): Promise<boolean> {
    const now = Date.now();
    if (cachedAdminReady && now - cachedAdminReady.checkedAt < 15000) {
      return cachedAdminReady.value;
    }
    try {
      await Promise.all([
        adminDb.collection('system').doc('ownerConfig').get(),
        adminAuth.listUsers(1),
      ]);
      cachedAdminReady = { value: true, checkedAt: now };
      return true;
    } catch {
      cachedAdminReady = { value: false, checkedAt: now };
      return false;
    }
  }

  // -------------------------------------------------------
  // Health Check & Server Time Sync
  // -------------------------------------------------------
  app.get('/api/health', async (_req, res) => {
    const adminReady = await isAdminSdkReady();
    res.json({
      ok: true,
      adminReady,
      credentialMode: getAdminCredentialMode(),
    });
  });

  app.get('/api/server-time', (_req, res) => {
    const serverTimeMs = Date.now();
    res.json({
      serverTimeMs,
      utcMinute: new Date(serverTimeMs).getUTCMinutes(),
      activePhaseCooldownMs: getGlobalCooldownDurationMs(serverTimeMs),
    });
  });

  // -------------------------------------------------------
  // One-Time Secure Initial Owner Bootstrap
  // Protected by server env INITIAL_OWNER_UID + single-use atomic lock
  // -------------------------------------------------------
  app.get(
    '/api/owner/bootstrap-status',
    requireAuthenticated,
    async (req: AuthedRequest, res: Response) => {
      try {
        const caller = req.caller!;
        const configuredOwnerUid = process.env.INITIAL_OWNER_UID?.trim();
        if (
          !configuredOwnerUid ||
          !VALID_UID_REGEX.test(configuredOwnerUid) ||
          caller.uid !== configuredOwnerUid
        ) {
          res.json({ eligible: false });
          return;
        }

        if (getTokenRole(caller) === 'owner') {
          res.json({ eligible: false });
          return;
        }

        const adminReady = await isAdminSdkReady();
        if (!adminReady) {
          res.json({ eligible: false });
          return;
        }

        const existingConfig = await adminDb.collection('system').doc('ownerConfig').get();
        const existingOwner = existingConfig.data()?.initialOwnerUid;
        if (existingConfig.exists && existingOwner && existingOwner !== caller.uid) {
          res.json({ eligible: false });
          return;
        }

        res.json({ eligible: true });
      } catch {
        res.json({ eligible: false });
      }
    }
  );

  app.post('/api/owner/bootstrap', async (req: Request, res: Response) => {
    try {
      const configuredOwnerUid = process.env.INITIAL_OWNER_UID?.trim();
      if (!configuredOwnerUid || !VALID_UID_REGEX.test(configuredOwnerUid)) {
        res.status(403).json({
          error: 'Sunucuda geçerli bir INITIAL_OWNER_UID ortam değişkeni ayarlı değil.',
        });
        return;
      }

      const decoded = await verifyCallerToken(req.headers.authorization, true);
      if (decoded.uid !== configuredOwnerUid) {
        res.status(403).json({
          error: 'Bu hesap ilk Owner kurulumu için yetkili değil.',
        });
        return;
      }

      const verification = await ensureInitialOwnerSetup(decoded.uid);
      if (
        verification.actionTaken !== 'assigned_owner' &&
        verification.actionTaken !== 'already_owner'
      ) {
        const status = verification.actionTaken === 'stopped_existing_other_owner' ? 409 : 403;
        res.status(status).json({
          error: verification.errorMessage || 'İlk Owner kurulumu gerçekleştirilemedi.',
        });
        return;
      }

      res.json({ ok: true, role: 'owner', uid: decoded.uid });
    } catch (error) {
      handleServerError(res, error, 'Owner kurulumu sırasında hata oluştu.');
    }
  });

  // -------------------------------------------------------
  // Owner Panel: List Players (Owner Only)
  // -------------------------------------------------------
  app.get('/api/owner/players', requireOwner, async (_req: AuthedRequest, res: Response) => {
    try {
      const [authList, usersSnapshot] = await Promise.all([
        adminAuth.listUsers(200),
        adminDb.collection('users').get(),
      ]);

      const firestoreMap = new Map<string, Record<string, unknown>>();
      usersSnapshot.forEach((docSnap) => {
        firestoreMap.set(docSnap.id, docSnap.data());
      });

      const players = authList.users.map((u) => {
        const fsData = firestoreMap.get(u.uid);
        const claimRole = u.customClaims?.role;
        const role: ServerRole =
          claimRole === 'owner' ||
          claimRole === 'admin' ||
          claimRole === 'moderator'
            ? claimRole
            : 'player';

        return {
          uid: u.uid,
          email: u.email ?? null,
          username:
            typeof fsData?.username === 'string' && fsData.username.trim()
              ? fsData.username
              : u.displayName || u.email?.split('@')[0] || 'Oyuncu',
          role,
          totalPixelsPlaced:
            typeof fsData?.totalPixelsPlaced === 'number' ? fsData.totalPixelsPlaced : 0,
          disabled: Boolean(u.disabled || fsData?.disabled),
          createdAt:
            typeof fsData?.createdAt === 'number'
              ? fsData.createdAt
              : u.metadata.creationTime
                ? Date.parse(u.metadata.creationTime)
                : Date.now(),
        };
      });

      players.sort((a, b) => {
        const order: Record<ServerRole, number> = {
          owner: 0,
          admin: 1,
          moderator: 2,
          player: 3,
        };
        if (order[a.role] !== order[b.role]) {
          return order[a.role] - order[b.role];
        }
        return b.totalPixelsPlaced - a.totalPixelsPlaced;
      });

      res.json({ players });
    } catch (error) {
      handleServerError(res, error, 'Oyuncu listesi alınamadı.');
    }
  });

  // -------------------------------------------------------
  // Owner Panel: Assign Admin / Moderator / Player Role
  // -------------------------------------------------------
  app.post('/api/owner/set-role', requireOwner, async (req: AuthedRequest, res: Response) => {
    try {
      const targetUid = typeof req.body?.targetUid === 'string' ? req.body.targetUid.trim() : '';
      const role = req.body?.role;

      if (!targetUid || targetUid.length > 128) {
        res.status(400).json({ error: 'Geçersiz kullanıcı kimliği.' });
        return;
      }

      if (role !== 'player' && role !== 'moderator' && role !== 'admin') {
        res.status(400).json({
          error: 'Yalnızca player, moderator veya admin rolü atanabilir.',
        });
        return;
      }

      if (targetUid === req.caller?.uid) {
        res.status(400).json({ error: 'Kendi Owner rolünüzü değiştiremezsiniz.' });
        return;
      }

      const targetUser = await adminAuth.getUser(targetUid);
      if (targetUser.customClaims?.role === 'owner') {
        res.status(403).json({ error: 'Başka bir Owner rolü değiştirilemez.' });
        return;
      }

      await adminAuth.setCustomUserClaims(targetUid, { role });
      const now = Date.now();
      const targetUserRef = adminDb.collection('users').doc(targetUid);
      const targetPublicRef = adminDb.collection('publicProfiles').doc(targetUid);
      const fallbackName =
        (typeof targetUser.displayName === 'string' && targetUser.displayName.trim()
          ? targetUser.displayName.trim()
          : targetUser.email?.split('@')[0] || 'Oyuncu'
        ).slice(0, 20);

      await adminDb.runTransaction(async (tx) => {
        const [uSnap, pSnap] = await Promise.all([tx.get(targetUserRef), tx.get(targetPublicRef)]);
        if (uSnap.exists) {
          tx.set(targetUserRef, { id: targetUid, role, updatedAt: now }, { merge: true });
        } else {
          tx.set(targetUserRef, {
            id: targetUid,
            username: fallbackName,
            bio: 'PixNation kaşifi.',
            countryCode: 'TR',
            accentColor: '#F59E0B',
            emblem: 'compass',
            totalPixelsPlaced: 0,
            role,
            disabled: Boolean(targetUser.disabled),
            createdAt: now,
            updatedAt: now,
          });
        }

        if (pSnap.exists) {
          tx.set(targetPublicRef, { id: targetUid, role, updatedAt: now }, { merge: true });
        } else {
          const uData = uSnap.exists ? uSnap.data() : null;
          tx.set(targetPublicRef, {
            id: targetUid,
            username: typeof uData?.username === 'string' ? uData.username : fallbackName,
            bio: typeof uData?.bio === 'string' ? uData.bio : 'PixNation kaşifi.',
            countryCode: typeof uData?.countryCode === 'string' ? uData.countryCode : 'TR',
            accentColor: typeof uData?.accentColor === 'string' ? uData.accentColor : '#F59E0B',
            emblem: typeof uData?.emblem === 'string' ? uData.emblem : 'compass',
            totalPixelsPlaced:
              typeof uData?.totalPixelsPlaced === 'number' ? uData.totalPixelsPlaced : 0,
            role,
            updatedAt: now,
          });
        }
      });

      res.json({ ok: true, uid: targetUid, role });
    } catch (error) {
      handleServerError(res, error, 'Rol güncellenemedi.');
    }
  });

  // -------------------------------------------------------
  // Owner Panel: Suspend / Activate Player Account
  // -------------------------------------------------------
  app.post('/api/owner/set-status', requireOwner, async (req: AuthedRequest, res: Response) => {
    try {
      const targetUid = typeof req.body?.targetUid === 'string' ? req.body.targetUid.trim() : '';
      const disabled = Boolean(req.body?.disabled);

      if (!targetUid || targetUid.length > 128) {
        res.status(400).json({ error: 'Geçersiz kullanıcı kimliği.' });
        return;
      }

      if (targetUid === req.caller?.uid) {
        res.status(400).json({ error: 'Kendi Owner hesabınızı askıya alamazsınız.' });
        return;
      }

      const targetUser = await adminAuth.getUser(targetUid);
      if (targetUser.customClaims?.role === 'owner') {
        res.status(403).json({ error: 'Owner hesabı askıya alınamaz.' });
        return;
      }

      await adminAuth.updateUser(targetUid, { disabled });
      if (disabled) {
        await adminAuth.revokeRefreshTokens(targetUid);
      }

      const targetUserRef = adminDb.collection('users').doc(targetUid);
      const uSnap = await targetUserRef.get();
      if (uSnap.exists) {
        await targetUserRef.set(
          {
            id: targetUid,
            disabled,
            updatedAt: Date.now(),
          },
          { merge: true }
        );
      } else {
        const now = Date.now();
        const fallbackName =
          (typeof targetUser.displayName === 'string' && targetUser.displayName.trim()
            ? targetUser.displayName.trim()
            : targetUser.email?.split('@')[0] || 'Oyuncu'
          ).slice(0, 20);
        await targetUserRef.set({
          id: targetUid,
          username: fallbackName,
          bio: 'PixNation kaşifi.',
          countryCode: 'TR',
          accentColor: '#F59E0B',
          emblem: 'compass',
          totalPixelsPlaced: 0,
          role: 'player',
          disabled,
          createdAt: now,
          updatedAt: now,
        });
      }

      res.json({ ok: true, uid: targetUid, disabled });
    } catch (error) {
      handleServerError(res, error, 'Kullanıcı durumu güncellenemedi.');
    }
  });

  // -------------------------------------------------------
  // Server-Authoritative Pixel Placement Endpoint
  // Enforces server clock cooldown, overwrite protection, and server-only counter increment
  // -------------------------------------------------------
  app.post(
    '/api/pixels/place',
    requireAuthenticated,
    async (req: AuthedRequest, res: Response) => {
      try {
        const caller = req.caller!;
        const x = Number(req.body?.x);
        const y = Number(req.body?.y);
        const color = typeof req.body?.color === 'string' ? req.body.color.trim().toUpperCase() : '';

        if (
          !Number.isInteger(x) ||
          !Number.isInteger(y) ||
          x < 0 ||
          x >= WORLD_WIDTH ||
          y < 0 ||
          y >= WORLD_HEIGHT
        ) {
          res.status(400).json({ error: 'Geçersiz piksel koordinatı.' });
          return;
        }

        if (!VALID_HEX_REGEX.test(color)) {
          res.status(400).json({ error: 'Geçersiz renk kodu.' });
          return;
        }

        const callerRole = getTokenRole(caller);
        const isStaff =
          callerRole === 'owner' || callerRole === 'admin' || callerRole === 'moderator';

        const pixelId = `${x}_${y}`;
        const pixelRef = adminDb.collection('pixels').doc(pixelId);
        const userRef = adminDb.collection('users').doc(caller.uid);
        const publicProfileRef = adminDb.collection('publicProfiles').doc(caller.uid);
        const cooldownRef = adminDb.collection('cooldowns').doc(caller.uid);
        const moderationRef = adminDb.collection('moderation').doc(caller.uid);

        const serverNowMs = Date.now();
        const serverNowTs = Timestamp.fromMillis(serverNowMs);

        const result = await adminDb.runTransaction(async (tx) => {
          const [userSnap, publicSnap, cooldownSnap, pixelSnap, modSnap] = await Promise.all([
            tx.get(userRef),
            tx.get(publicProfileRef),
            tx.get(cooldownRef),
            tx.get(pixelRef),
            tx.get(moderationRef),
          ]);

          if (!userSnap.exists) {
            throw new HttpError(403, 'Önce geçerli bir oyuncu profili oluşturulmalıdır.');
          }

          const userData = userSnap.data()!;
          if (userData.disabled === true) {
            throw new HttpError(403, 'Hesabınız askıya alınmış durumda.');
          }

          if (modSnap.exists) {
            const modData = modSnap.data()!;
            const banActive = modData.banActive === true;
            const banPermanent = modData.banPermanent === true;
            const banExpiresTs = modData.banExpiresAt;
            const banStillValid =
              banActive &&
              (banPermanent ||
                (banExpiresTs instanceof Timestamp && serverNowMs < banExpiresTs.toMillis()));
            if (banStillValid) {
              const reasonText =
                typeof modData.banReason === 'string' && modData.banReason
                  ? modData.banReason
                  : 'Kural ihlali';
              const durationLabel = banPermanent
                ? 'Kalıcı'
                : banExpiresTs instanceof Timestamp
                  ? `Kalan: ${formatRemainingTr(banExpiresTs.toMillis() - serverNowMs)}`
                  : 'Süreli';
              throw new HttpError(
                403,
                `Yasaklandığınız için piksel yerleştiremezsiniz (${durationLabel}). Neden: ${reasonText}`
              );
            }
          }

          if (cooldownSnap.exists) {
            const lastTs = cooldownSnap.data()?.lastPlacedAt;
            if (lastTs instanceof Timestamp) {
              const lastPlacedMs = lastTs.toMillis();
              const requiredCooldownMs = getGlobalCooldownDurationMs(serverNowMs);
              const elapsedMs = serverNowMs - lastPlacedMs;
              if (elapsedMs < requiredCooldownMs) {
                const remaining = ((requiredCooldownMs - elapsedMs) / 1000).toFixed(1);
                throw new HttpError(429, `Bekleme süresi (sunucu): ${remaining}s`);
              }
            }
          }

          if (pixelSnap.exists) {
            const existingAuthorId = pixelSnap.data()?.authorId;
            if (existingAuthorId && existingAuthorId !== caller.uid && !isStaff) {
              throw new HttpError(
                403,
                'Bu koordinattaki piksel başka bir oyuncuya ait; üzerine yazılamaz.'
              );
            }
          }

          const username =
            typeof userData.username === 'string' && userData.username.trim()
              ? userData.username.trim().slice(0, 20)
              : 'Oyuncu';

          const pixelRecord = {
            x,
            y,
            color,
            authorId: caller.uid,
            authorUsername: username,
            placedAt: serverNowMs,
            updatedAt: serverNowTs,
          };

          tx.set(pixelRef, pixelRecord);
          tx.set(cooldownRef, {
            userId: caller.uid,
            lastPlacedAt: serverNowTs,
          });
          tx.update(userRef, {
            totalPixelsPlaced: FieldValue.increment(1),
            updatedAt: serverNowMs,
          });

          if (publicSnap.exists) {
            tx.update(publicProfileRef, {
              totalPixelsPlaced: FieldValue.increment(1),
              updatedAt: serverNowMs,
            });
          } else {
            tx.set(publicProfileRef, {
              id: caller.uid,
              username,
              bio: typeof userData.bio === 'string' ? userData.bio : '',
              countryCode: typeof userData.countryCode === 'string' ? userData.countryCode : 'TR',
              accentColor: typeof userData.accentColor === 'string' ? userData.accentColor : '#F59E0B',
              emblem: typeof userData.emblem === 'string' ? userData.emblem : 'compass',
              totalPixelsPlaced:
                (typeof userData.totalPixelsPlaced === 'number' ? userData.totalPixelsPlaced : 0) + 1,
              role: callerRole,
              updatedAt: serverNowMs,
            });
          }

          return {
            ...pixelRecord,
            updatedAt: serverNowMs,
            cooldownDurationMs: getGlobalCooldownDurationMs(serverNowMs),
          };
        });

        res.json({ ok: true, pixel: result });
      } catch (error) {
        handleServerError(res, error, 'Piksel sunucuda kaydedilemedi.');
      }
    }
  );

  // -------------------------------------------------------
  // Moderation System Endpoints (Owner & Admin Custom Claims)
  // -------------------------------------------------------
  app.post(
    '/api/moderation/apply',
    requireOwnerOrAdmin,
    async (req: AuthedRequest, res: Response) => {
      try {
        const caller = req.caller!;
        const callerRole = getTokenRole(caller);
        const targetUid = typeof req.body?.targetUid === 'string' ? req.body.targetUid.trim() : '';
        const type = req.body?.type;
        const durationKey =
          typeof req.body?.durationKey === 'string' ? req.body.durationKey.trim() : '';
        const reason = typeof req.body?.reason === 'string' ? req.body.reason.trim().slice(0, 200) : '';

        if (!VALID_UID_REGEX.test(targetUid)) {
          res.status(400).json({ error: 'Geçersiz hedef kullanıcı kimliği.' });
          return;
        }
        if (targetUid === caller.uid) {
          res.status(403).json({ error: 'Kendi hesabınıza ceza uygulayamazsınız.' });
          return;
        }
        if (type !== 'mute' && type !== 'ban') {
          res.status(400).json({ error: 'Geçersiz ceza türü.' });
          return;
        }
        if (!reason) {
          res.status(400).json({ error: 'Ceza nedeni girilmesi zorunludur.' });
          return;
        }

        const durationTable = type === 'mute' ? MUTE_DURATIONS_MS : BAN_DURATIONS_MS;
        if (!(durationKey in durationTable)) {
          res.status(400).json({ error: 'Geçersiz ceza süresi seçeneği.' });
          return;
        }
        const durationMs = durationTable[durationKey];
        const permanent = durationMs === null;

        const targetAuthUser = await adminAuth.getUser(targetUid);
        const targetUserRef = adminDb.collection('users').doc(targetUid);
        const actorUserRef = adminDb.collection('users').doc(caller.uid);
        const moderationRef = adminDb.collection('moderation').doc(targetUid);
        const logRef = adminDb.collection('moderationLogs').doc();

        const serverNowMs = Date.now();
        const serverNowTs = Timestamp.fromMillis(serverNowMs);
        const expiresAtTs =
          permanent || durationMs === null ? null : Timestamp.fromMillis(serverNowMs + durationMs);

        const state = await adminDb.runTransaction(async (tx) => {
          const [actorSnap, targetSnap, modSnap] = await Promise.all([
            tx.get(actorUserRef),
            tx.get(targetUserRef),
            tx.get(moderationRef),
          ]);

          const actorUsername = (
            typeof actorSnap.data()?.username === 'string' && actorSnap.data()!.username.trim()
              ? actorSnap.data()!.username.trim()
              : caller.name || caller.email?.split('@')[0] || 'Yetkili'
          ).slice(0, 20);

          const targetUsername = (
            typeof targetSnap.data()?.username === 'string' && targetSnap.data()!.username.trim()
              ? targetSnap.data()!.username.trim()
              : targetAuthUser.displayName || targetAuthUser.email?.split('@')[0] || 'Oyuncu'
          ).slice(0, 20);

          const targetRole = getEffectiveRole(
            targetAuthUser.customClaims?.role,
            targetSnap.data()?.role
          );
          assertCanModerateTarget(callerRole, targetRole);

          const prev = modSnap.exists ? modSnap.data()! : null;
          const baseMute = {
            muteActive: Boolean(prev?.muteActive),
            muteReason: typeof prev?.muteReason === 'string' ? prev.muteReason : '',
            muteDurationKey: typeof prev?.muteDurationKey === 'string' ? prev.muteDurationKey : '',
            mutePermanent: Boolean(prev?.mutePermanent),
            muteActorUid: typeof prev?.muteActorUid === 'string' ? prev.muteActorUid : '',
            muteActorUsername:
              typeof prev?.muteActorUsername === 'string' ? prev.muteActorUsername : '',
            muteActorRole: typeof prev?.muteActorRole === 'string' ? prev.muteActorRole : '',
            muteStartedAt: prev?.muteStartedAt instanceof Timestamp ? prev.muteStartedAt : null,
            muteExpiresAt: prev?.muteExpiresAt instanceof Timestamp ? prev.muteExpiresAt : null,
          };

          const baseBan = {
            banActive: Boolean(prev?.banActive),
            banReason: typeof prev?.banReason === 'string' ? prev.banReason : '',
            banDurationKey: typeof prev?.banDurationKey === 'string' ? prev.banDurationKey : '',
            banPermanent: Boolean(prev?.banPermanent),
            banActorUid: typeof prev?.banActorUid === 'string' ? prev.banActorUid : '',
            banActorUsername:
              typeof prev?.banActorUsername === 'string' ? prev.banActorUsername : '',
            banActorRole: typeof prev?.banActorRole === 'string' ? prev.banActorRole : '',
            banStartedAt: prev?.banStartedAt instanceof Timestamp ? prev.banStartedAt : null,
            banExpiresAt: prev?.banExpiresAt instanceof Timestamp ? prev.banExpiresAt : null,
          };

          const nextDoc = {
            userId: targetUid,
            targetUsername,
            targetRole,
            ...(type === 'mute'
              ? {
                  muteActive: true,
                  muteReason: reason,
                  muteDurationKey: durationKey,
                  mutePermanent: permanent,
                  muteActorUid: caller.uid,
                  muteActorUsername: actorUsername,
                  muteActorRole: callerRole,
                  muteStartedAt: serverNowTs,
                  muteExpiresAt: expiresAtTs,
                }
              : baseMute),
            ...(type === 'ban'
              ? {
                  banActive: true,
                  banReason: reason,
                  banDurationKey: durationKey,
                  banPermanent: permanent,
                  banActorUid: caller.uid,
                  banActorUsername: actorUsername,
                  banActorRole: callerRole,
                  banStartedAt: serverNowTs,
                  banExpiresAt: expiresAtTs,
                }
              : baseBan),
            lastLogId: logRef.id,
            updatedAt: serverNowTs,
          };

          tx.set(moderationRef, nextDoc);
          tx.set(logRef, {
            action: type,
            actorUid: caller.uid,
            actorUsername,
            actorRole: callerRole,
            targetUid,
            targetUsername,
            targetRole,
            reason,
            durationKey,
            durationMs: durationMs ?? 0,
            permanent,
            expiresAt: expiresAtTs,
            createdAt: serverNowTs,
          });

          return nextDoc;
        });

        res.json({ ok: true, moderation: state });
      } catch (error) {
        handleServerError(res, error, 'Ceza işlemi uygulanamadı.');
      }
    }
  );

  app.post(
    '/api/moderation/revoke',
    requireOwnerOrAdmin,
    async (req: AuthedRequest, res: Response) => {
      try {
        const caller = req.caller!;
        const callerRole = getTokenRole(caller);
        const targetUid = typeof req.body?.targetUid === 'string' ? req.body.targetUid.trim() : '';
        const type = req.body?.type;
        const rawReason = typeof req.body?.reason === 'string' ? req.body.reason.trim() : '';
        const reason = (rawReason || 'Yetkili tarafından ceza kaldırıldı.').slice(0, 200);

        if (!VALID_UID_REGEX.test(targetUid)) {
          res.status(400).json({ error: 'Geçersiz hedef kullanıcı kimliği.' });
          return;
        }
        if (targetUid === caller.uid) {
          res.status(403).json({ error: 'Kendi cezanızı kaldıramazsınız.' });
          return;
        }
        if (type !== 'mute' && type !== 'ban') {
          res.status(400).json({ error: 'Geçersiz ceza kaldırma türü.' });
          return;
        }

        const targetAuthUser = await adminAuth.getUser(targetUid).catch(() => null);
        const targetUserRef = adminDb.collection('users').doc(targetUid);
        const actorUserRef = adminDb.collection('users').doc(caller.uid);
        const moderationRef = adminDb.collection('moderation').doc(targetUid);
        const logRef = adminDb.collection('moderationLogs').doc();

        const serverNowMs = Date.now();
        const serverNowTs = Timestamp.fromMillis(serverNowMs);

        await adminDb.runTransaction(async (tx) => {
          const [actorSnap, targetSnap, modSnap] = await Promise.all([
            tx.get(actorUserRef),
            tx.get(targetUserRef),
            tx.get(moderationRef),
          ]);

          if (!modSnap.exists) {
            throw new HttpError(404, 'Bu kullanıcıya ait aktif bir ceza kaydı bulunamadı.');
          }

          const targetRole = getEffectiveRole(
            targetAuthUser?.customClaims?.role,
            targetSnap.data()?.role
          );
          assertCanModerateTarget(callerRole, targetRole);

          const actorUsername = (
            typeof actorSnap.data()?.username === 'string' && actorSnap.data()!.username.trim()
              ? actorSnap.data()!.username.trim()
              : caller.name || caller.email?.split('@')[0] || 'Yetkili'
          ).slice(0, 20);

          const prev = modSnap.data()!;
          const targetUsername = (
            typeof targetSnap.data()?.username === 'string' && targetSnap.data()!.username.trim()
              ? targetSnap.data()!.username.trim()
              : typeof prev.targetUsername === 'string' && prev.targetUsername
                ? prev.targetUsername
                : 'Oyuncu'
          ).slice(0, 20);

          const clearedMute = {
            muteActive: false,
            muteReason: '',
            muteDurationKey: '',
            mutePermanent: false,
            muteActorUid: '',
            muteActorUsername: '',
            muteActorRole: '',
            muteStartedAt: null,
            muteExpiresAt: null,
          };

          const clearedBan = {
            banActive: false,
            banReason: '',
            banDurationKey: '',
            banPermanent: false,
            banActorUid: '',
            banActorUsername: '',
            banActorRole: '',
            banStartedAt: null,
            banExpiresAt: null,
          };

          const nextDoc = {
            ...prev,
            userId: targetUid,
            targetUsername,
            targetRole,
            ...(type === 'mute' ? clearedMute : {}),
            ...(type === 'ban' ? clearedBan : {}),
            lastLogId: logRef.id,
            updatedAt: serverNowTs,
          };

          tx.set(moderationRef, nextDoc);
          tx.set(logRef, {
            action: type === 'mute' ? 'unmute' : 'unban',
            actorUid: caller.uid,
            actorUsername,
            actorRole: callerRole,
            targetUid,
            targetUsername,
            targetRole,
            reason,
            durationKey: 'none',
            durationMs: 0,
            permanent: false,
            expiresAt: null,
            createdAt: serverNowTs,
          });
        });

        res.json({ ok: true, targetUid, action: type === 'mute' ? 'unmute' : 'unban' });
      } catch (error) {
        handleServerError(res, error, 'Ceza kaldırılamadı.');
      }
    }
  );

  app.get(
    '/api/moderation/list',
    requireOwnerOrAdmin,
    async (_req: AuthedRequest, res: Response) => {
      try {
        const nowMs = Date.now();
        const [modSnap, logSnap] = await Promise.all([
          adminDb.collection('moderation').get(),
          adminDb
            .collection('moderationLogs')
            .orderBy('createdAt', 'desc')
            .limit(60)
            .get(),
        ]);

        const activePenalties = modSnap.docs
          .map((d) => {
            const data = d.data();
            const muteExp =
              data.muteExpiresAt instanceof Timestamp ? data.muteExpiresAt.toMillis() : null;
            const banExp =
              data.banExpiresAt instanceof Timestamp ? data.banExpiresAt.toMillis() : null;
            const muteActive =
              data.muteActive === true &&
              (data.mutePermanent === true || (muteExp !== null && nowMs < muteExp));
            const banActive =
              data.banActive === true &&
              (data.banPermanent === true || (banExp !== null && nowMs < banExp));

            return {
              userId: d.id,
              targetUsername: typeof data.targetUsername === 'string' ? data.targetUsername : 'Oyuncu',
              targetRole:
                data.targetRole === 'owner' ||
                data.targetRole === 'admin' ||
                data.targetRole === 'moderator'
                  ? data.targetRole
                  : 'player',
              muteActive,
              muteReason: typeof data.muteReason === 'string' ? data.muteReason : '',
              muteDurationKey: typeof data.muteDurationKey === 'string' ? data.muteDurationKey : '',
              mutePermanent: Boolean(data.mutePermanent),
              muteActorUid: typeof data.muteActorUid === 'string' ? data.muteActorUid : '',
              muteActorUsername:
                typeof data.muteActorUsername === 'string' ? data.muteActorUsername : '',
              muteActorRole: typeof data.muteActorRole === 'string' ? data.muteActorRole : '',
              muteStartedAtMs:
                data.muteStartedAt instanceof Timestamp ? data.muteStartedAt.toMillis() : null,
              muteExpiresAtMs: muteExp,
              banActive,
              banReason: typeof data.banReason === 'string' ? data.banReason : '',
              banDurationKey: typeof data.banDurationKey === 'string' ? data.banDurationKey : '',
              banPermanent: Boolean(data.banPermanent),
              banActorUid: typeof data.banActorUid === 'string' ? data.banActorUid : '',
              banActorUsername:
                typeof data.banActorUsername === 'string' ? data.banActorUsername : '',
              banActorRole: typeof data.banActorRole === 'string' ? data.banActorRole : '',
              banStartedAtMs:
                data.banStartedAt instanceof Timestamp ? data.banStartedAt.toMillis() : null,
              banExpiresAtMs: banExp,
              updatedAtMs:
                data.updatedAt instanceof Timestamp ? data.updatedAt.toMillis() : nowMs,
            };
          })
          .filter((item) => item.muteActive || item.banActive);

        const logs = logSnap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            action: data.action,
            actorUid: data.actorUid,
            actorUsername: data.actorUsername,
            actorRole: data.actorRole,
            targetUid: data.targetUid,
            targetUsername: data.targetUsername,
            targetRole: data.targetRole,
            reason: data.reason,
            durationKey: data.durationKey,
            durationMs: typeof data.durationMs === 'number' ? data.durationMs : 0,
            permanent: Boolean(data.permanent),
            expiresAtMs: data.expiresAt instanceof Timestamp ? data.expiresAt.toMillis() : null,
            createdAtMs: data.createdAt instanceof Timestamp ? data.createdAt.toMillis() : nowMs,
          };
        });

        res.json({ activePenalties, logs, serverTimeMs: nowMs });
      } catch (error) {
        handleServerError(res, error, 'Moderasyon kayıtları alınamadı.');
      }
    }
  );

  // -------------------------------------------------------
  // Vite Middleware (Dev) or Static Assets (Prod)
  // -------------------------------------------------------
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const configuredOwnerUid = process.env.INITIAL_OWNER_UID?.trim();
  if (configuredOwnerUid) {
    try {
      const verification = await ensureInitialOwnerSetup(configuredOwnerUid);
      await writeFile(
        '/tmp/pixnation-owner-bootstrap.json',
        JSON.stringify(verification, null, 2),
        'utf8'
      );
      console.log(
        `İlk Owner kontrolü: ${verification.actionTaken} (uid=${verification.targetUid}, role=${verification.verifiedClaimRole})`
      );
    } catch (error) {
      const fallbackResult: OwnerBootstrapVerification = {
        checkedAt: new Date().toISOString(),
        targetUid: configuredOwnerUid,
        authUserExists: false,
        authUserDisabled: false,
        existingAuthOwnersCount: 0,
        hasOtherOwner: false,
        existingConfigOwner: null,
        actionTaken: 'stopped_error',
        verifiedClaimRole: null,
        verifiedConfigOwner: null,
        errorMessage:
          error instanceof Error ? error.message : 'İlk Owner kurulumu sırasında hata oluştu.',
      };
      await writeFile(
        '/tmp/pixnation-owner-bootstrap.json',
        JSON.stringify(fallbackResult, null, 2),
        'utf8'
      ).catch(() => undefined);
      console.error('İlk Owner otomatik kurulumu başarısız:', error);
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PixNation sunucusu http://0.0.0.0:${PORT} üzerinde çalışıyor.`);
  });
}

void startServer();
