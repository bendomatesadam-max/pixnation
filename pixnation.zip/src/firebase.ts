import { initializeApp } from 'firebase/app';
import { browserLocalPersistence, getAuth, setPersistence } from 'firebase/auth';
import { doc, getDocFromServer, getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'AIzaSyBCGt1MU3ZVv3tWMRsKa-ZsGI7-8gJJdWA',
  authDomain: 'pixnation-b77f1.firebaseapp.com',
  projectId: 'pixnation-b77f1',
  storageBucket: 'pixnation-b77f1.firebasestorage.app',
  messagingSenderId: '818298491033',
  appId: '1:818298491033:web:9b5adaf46b292ee800e808',
  measurementId: 'G-0WH2LZSQWQ',
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

void setPersistence(auth, browserLocalPersistence).catch(() => undefined);

export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Firebase yapılandırması veya ağ bağlantısı doğrulanamadı.');
      return false;
    }
    // Missing document or permission check still confirms server reachability
    return true;
  }
}
