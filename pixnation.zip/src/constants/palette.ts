import { PaletteColor, RegionPreset } from '../types/game';

export const COOLDOWN_FIRST_PHASE_MS = 1_000;
export const COOLDOWN_SECOND_PHASE_MS = 500;
export const COOLDOWN_PHASE_INTERVAL_MS = 30 * 60 * 1000;

/**
 * PixNation global cooldown cycle (synced with server UTC clock):
 * - First 30 minutes of every hour (UTC 00..29): 1s (1000ms) cooldown
 * - Next 30 minutes of every hour (UTC 30..59): 500ms cooldown
 */
export function getGlobalCooldownDurationMs(timestampMs: number): number {
  const minute = new Date(timestampMs).getUTCMinutes();
  return minute < 30 ? COOLDOWN_FIRST_PHASE_MS : COOLDOWN_SECOND_PHASE_MS;
}

export const COOLDOWN_DURATION_MS = COOLDOWN_FIRST_PHASE_MS;

export const MIN_ZOOM = 0.2;
export const MAX_ZOOM = 48;

export const PIXEL_PALETTE: PaletteColor[] = [
  { id: 'ink-black', name: 'Kömür Siyahı', hex: '#111827' },
  { id: 'slate-gray', name: 'Kurşun Gri', hex: '#4B5563' },
  { id: 'silver-mist', name: 'Gümüş Gri', hex: '#9CA3AF' },
  { id: 'pure-white', name: 'Saf Beyaz', hex: '#FFFFFF' },
  { id: 'deep-crimson', name: 'Koyu Kızıl', hex: '#991B1B' },
  { id: 'signal-red', name: 'Mercan Kırmızı', hex: '#EF4444' },
  { id: 'warm-coral', name: 'Gün Batımı Turuncu', hex: '#F97316' },
  { id: 'amber-gold', name: 'Kehribar Altın', hex: '#F59E0B' },
  { id: 'sun-yellow', name: 'Güneş Sarısı', hex: '#FACC15' },
  { id: 'lime-sprout', name: 'Fıstık Yeşili', hex: '#84CC16' },
  { id: 'forest-emerald', name: 'Zümrüt Yeşili', hex: '#10B981' },
  { id: 'pine-green', name: 'Çam Yeşili', hex: '#166534' },
  { id: 'teal-lagoon', name: 'Turkuaz Lagün', hex: '#14B8A6' },
  { id: 'sky-cyan', name: 'Gökyüzü Mavisi', hex: '#06B6D4' },
  { id: 'azure-ocean', name: 'Açık Mavi', hex: '#3B82F6' },
  { id: 'sea-blue', name: 'Deniz Mavisi', hex: '#CAE3FF' },
  { id: 'royal-cobalt', name: 'Kobalt Lacivert', hex: '#1D4ED8' },
  { id: 'deep-indigo', name: 'Gece İndigo', hex: '#312E81' },
  { id: 'violet-iris', name: 'Süsen Moru', hex: '#7C3AED' },
  { id: 'orchid-plum', name: 'Orkide Eflatun', hex: '#C026D3' },
  { id: 'rose-petal', name: 'Gül Pembe', hex: '#EC4899' },
  { id: 'peach-sand', name: 'Şeftali Kum', hex: '#FDBA74' },
  { id: 'terracotta', name: 'Terrakota', hex: '#B45309' },
  { id: 'earth-umber', name: 'Toprak Kahve', hex: '#78350F' },
];

export const PROFILE_ACCENT_COLORS = [
  '#F59E0B',
  '#EF4444',
  '#10B981',
  '#3B82F6',
  '#8B5CF6',
  '#EC4899',
  '#14B8A6',
  '#F97316',
];

/**
 * Coordinates calibrated for the 2048x2048 Web Mercator world map.
 */
export const REGION_PRESETS: RegionPreset[] = [
  {
    id: 'world',
    label: 'Tüm Dünya',
    centerX: 1024,
    centerY: 960,
    zoom: 0.45,
  },
  {
    id: 'turkey',
    label: 'Türkiye ve Akdeniz',
    centerX: 1223,
    centerY: 782,
    zoom: 5.5,
  },
  {
    id: 'europe',
    label: 'Avrupa',
    centerX: 1092,
    centerY: 695,
    zoom: 3.5,
  },
  {
    id: 'north-america',
    label: 'Kuzey Amerika',
    centerX: 455,
    centerY: 760,
    zoom: 2.2,
  },
  {
    id: 'south-america',
    label: 'Güney Amerika',
    centerX: 683,
    centerY: 1110,
    zoom: 2.4,
  },
  {
    id: 'east-asia',
    label: 'Doğu Asya',
    centerX: 1678,
    centerY: 808,
    zoom: 2.6,
  },
  {
    id: 'oceania',
    label: 'Avustralya',
    centerX: 1786,
    centerY: 1173,
    zoom: 3.2,
  },
];
