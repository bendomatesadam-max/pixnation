import React, { useEffect, useRef, useState } from 'react';
import {
  Ban,
  ChevronRight,
  Clock,
  Crown,
  LogIn,
  MessageSquare,
  Send,
  Shield,
  ShieldCheck,
  Trash2,
  VolumeX,
} from 'lucide-react';
import { ChatMessage, UserRole } from '../types/game';
import { ActivePenaltyInfo, formatRemainingDuration } from '../utils/moderation';

interface ChatPanelProps {
  isOpen: boolean;
  isAuthenticated: boolean;
  currentUserId: string | null;
  currentUserRole: UserRole;
  messages: ChatMessage[];
  unreadCount: number;
  errorMessage: string | null;
  activeBan?: ActivePenaltyInfo | null;
  activeMute?: ActivePenaltyInfo | null;
  onToggleOpen: (open: boolean) => void;
  onSendMessage: (text: string) => Promise<void>;
  onDeleteMessage: (messageId: string) => Promise<void>;
  onOpenAuth: () => void;
  onInspectPlayer: (userId: string, username: string) => void;
}

const MAX_MESSAGE_LENGTH = 240;

function formatMessageTime(ms: number): string {
  try {
    return new Date(ms).toLocaleTimeString('tr-TR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return '';
  }
}

function getRoleStyles(role: UserRole): {
  cardClass: string;
  usernameClass: string;
  roleLabel: string;
  roleClass: string;
} {
  switch (role) {
    case 'owner':
      return {
        cardClass: 'bg-amber-500/12 border border-amber-400/40',
        usernameClass: 'text-amber-300 hover:text-amber-200 font-bold',
        roleLabel: 'Owner',
        roleClass: 'text-amber-300 font-semibold',
      };
    case 'admin':
      return {
        cardClass: 'bg-rose-500/10 border border-rose-400/35',
        usernameClass: 'text-rose-300 hover:text-rose-200 font-bold',
        roleLabel: 'Admin',
        roleClass: 'text-rose-300 font-semibold',
      };
    case 'moderator':
      return {
        cardClass: 'bg-sky-500/10 border border-sky-400/35',
        usernameClass: 'text-sky-300 hover:text-sky-200 font-semibold',
        roleLabel: 'Moderatör',
        roleClass: 'text-sky-300 font-semibold',
      };
    default:
      return {
        cardClass: 'bg-slate-900/75 border border-slate-800/80',
        usernameClass: 'text-slate-100 hover:text-amber-200 font-semibold',
        roleLabel: 'Oyuncu',
        roleClass: 'text-slate-400',
      };
  }
}

function RoleIcon({ role }: { role: UserRole }) {
  if (role === 'owner') {
    return <Crown size={12} className="text-amber-300 shrink-0" aria-hidden="true" />;
  }
  if (role === 'admin') {
    return <ShieldCheck size={12} className="text-rose-300 shrink-0" aria-hidden="true" />;
  }
  if (role === 'moderator') {
    return <Shield size={12} className="text-sky-300 shrink-0" aria-hidden="true" />;
  }
  return null;
}

export const ChatPanel: React.FC<ChatPanelProps> = ({
  isOpen,
  isAuthenticated,
  currentUserId,
  currentUserRole,
  messages,
  unreadCount,
  errorMessage,
  activeBan = null,
  activeMute = null,
  onToggleOpen,
  onSendMessage,
  onDeleteMessage,
  onOpenAuth,
  onInspectPlayer,
}) => {
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const isStaff =
    currentUserRole === 'owner' ||
    currentUserRole === 'admin' ||
    currentUserRole === 'moderator';

  useEffect(() => {
    if (!isOpen) return;
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [isOpen, messages.length]);

  useEffect(() => {
    if (isOpen && isAuthenticated) {
      const timer = window.setTimeout(() => {
        inputRef.current?.focus();
      }, 120);
      return () => window.clearTimeout(timer);
    }
    return undefined;
  }, [isOpen, isAuthenticated]);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = draft.trim();
    if (!trimmed || sending) return;
    if (trimmed.length > MAX_MESSAGE_LENGTH) {
      setLocalError('Mesaj en fazla 240 karakter olabilir.');
      return;
    }

    setSending(true);
    setLocalError(null);
    try {
      await onSendMessage(trimmed);
      setDraft('');
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'Mesaj gönderilemedi.');
    } finally {
      setSending(false);
    }
  };

  if (!isOpen) {
    return (
      <div className="fixed right-3 sm:right-4 top-18 sm:top-20 z-20">
        <button
          type="button"
          onClick={() => onToggleOpen(true)}
          aria-label="Genel sohbet panelini aç"
          className="flex items-center gap-2 px-3.5 py-2.5 min-h-[42px] rounded-xl bg-slate-950/92 border border-slate-700/75 hover:border-slate-500 text-slate-100 text-xs sm:text-sm font-semibold shadow-xl backdrop-blur-md transition-colors cursor-pointer whitespace-nowrap"
        >
          <MessageSquare size={16} className="text-amber-300 shrink-0" aria-hidden="true" />
          <span>Sohbet</span>
          {unreadCount > 0 && (
            <span className="font-mono-tabular px-1.5 py-0.5 rounded-md bg-amber-400 text-slate-950 text-[11px] font-bold leading-none">
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </button>
      </div>
    );
  }

  const trimmedLength = draft.trim().length;
  const charCount = draft.length;
  const activePenalty = activeBan ?? activeMute;
  const isPenalized = Boolean(activePenalty);

  return (
    <aside
      aria-label="Genel Sohbet Paneli"
      className="fixed top-[72px] bottom-[76px] left-3 right-3 sm:left-auto sm:top-20 sm:bottom-20 sm:right-4 sm:w-[340px] z-30 flex flex-col rounded-2xl bg-slate-950/95 border border-slate-700/80 shadow-2xl backdrop-blur-md overflow-hidden"
    >
      {/* Header */}
      <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-slate-800/90 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <MessageSquare size={16} className="text-amber-300 shrink-0" aria-hidden="true" />
          <h2 className="font-display text-sm font-bold text-slate-100 truncate">
            Genel Sohbet
          </h2>
          {isAuthenticated && (
            <>
              <span className="text-slate-600 text-xs" aria-hidden="true">·</span>
              <span className="font-mono-tabular text-xs text-slate-400 whitespace-nowrap">
                {messages.length}
              </span>
            </>
          )}
        </div>
        <button
          type="button"
          onClick={() => onToggleOpen(false)}
          aria-label="Sohbet panelini kapat"
          title="Sohbeti küçült"
          className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/90 transition-colors cursor-pointer shrink-0"
        >
          <ChevronRight size={18} />
        </button>
      </div>

      {/* Body */}
      {!isAuthenticated ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center px-6 py-8 gap-4">
          <MessageSquare size={28} className="text-slate-500" aria-hidden="true" />
          <p className="text-sm text-slate-300 leading-relaxed max-w-[240px]">
            Genel sohbet mesajlarını okumak ve yazmak için hesabınıza giriş yapın.
          </p>
          <button
            type="button"
            onClick={onOpenAuth}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs sm:text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap"
          >
            <LogIn size={15} />
            <span>Giriş Yap</span>
          </button>
        </div>
      ) : (
        <>
          <div className="flex-1 overflow-y-auto touch-pan-y overscroll-contain px-3 py-3 space-y-2.5">
            {errorMessage && (
              <div className="px-3 py-2.5 rounded-xl bg-rose-500/12 border border-rose-400/35 text-xs text-rose-200 leading-relaxed">
                {errorMessage}
              </div>
            )}

            {messages.length === 0 && !errorMessage ? (
              <div className="h-full flex items-center justify-center text-center px-4 py-8">
                <p className="text-xs text-slate-400 leading-relaxed">
                  Henüz mesaj yok. İlk mesajı sen gönder!
                </p>
              </div>
            ) : (
              messages.map((msg) => {
                const styles = getRoleStyles(msg.authorRole);
                const canDelete =
                  !msg.pending && (msg.authorId === currentUserId || isStaff);

                return (
                  <article
                    key={msg.id}
                    className={`rounded-xl px-3 py-2.5 transition-opacity ${styles.cardClass} ${
                      msg.pending ? 'opacity-70' : 'opacity-100'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-1.5 min-w-0 text-xs">
                        <RoleIcon role={msg.authorRole} />
                        <button
                          type="button"
                          onClick={() => onInspectPlayer(msg.authorId, msg.authorUsername)}
                          title="Oyuncunun profilini görüntüle"
                          className={`truncate max-w-[125px] text-left cursor-pointer whitespace-nowrap ${styles.usernameClass}`}
                        >
                          {msg.authorUsername}
                        </button>
                        <span className="text-slate-600 shrink-0" aria-hidden="true">·</span>
                        <span className={`text-[11px] whitespace-nowrap shrink-0 ${styles.roleClass}`}>
                          {styles.roleLabel}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="font-mono-tabular text-[10px] text-slate-500 whitespace-nowrap">
                          {formatMessageTime(msg.createdAt)}
                        </span>
                        {canDelete && (
                          <button
                            type="button"
                            onClick={() => void onDeleteMessage(msg.id)}
                            aria-label="Mesajı sil"
                            title="Mesajı sil"
                            className="w-6 h-6 flex items-center justify-center rounded-md text-slate-500 hover:text-rose-300 hover:bg-slate-800/80 transition-colors cursor-pointer"
                          >
                            <Trash2 size={12} />
                          </button>
                        )}
                      </div>
                    </div>

                    <p className="text-[13px] leading-relaxed text-slate-100 break-words whitespace-pre-wrap">
                      {msg.text}
                    </p>
                  </article>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Composer */}
          <form
            onSubmit={handleSubmit}
            className="p-3 border-t border-slate-800/90 bg-slate-950/95 space-y-2 shrink-0"
          >
            {activePenalty && (
              <div
                role="alert"
                className={`rounded-xl px-3 py-2.5 border text-xs space-y-1 ${
                  activePenalty.type === 'ban'
                    ? 'bg-rose-500/12 border-rose-400/40 text-rose-100'
                    : 'bg-amber-500/12 border-amber-400/40 text-amber-100'
                }`}
              >
                <div className="flex items-center justify-between gap-2 font-semibold">
                  <span className="inline-flex items-center gap-1.5">
                    {activePenalty.type === 'ban' ? <Ban size={13} /> : <VolumeX size={13} />}
                    {activePenalty.type === 'ban' ? 'Oyundan Yasaklandınız' : 'Sohbetten Susturuldunuz'}
                  </span>
                  <span className="inline-flex items-center gap-1 font-mono-tabular text-[11px] whitespace-nowrap">
                    <Clock size={11} />
                    {activePenalty.permanent
                      ? 'Kalıcı'
                      : activePenalty.remainingMs !== null
                        ? formatRemainingDuration(activePenalty.remainingMs)
                        : 'Süreli'}
                  </span>
                </div>
                <p className="text-[11px] opacity-90 break-words">
                  Neden: {activePenalty.reason}
                </p>
              </div>
            )}

            {localError && (
              <p className="text-[11px] text-rose-300 leading-snug">{localError}</p>
            )}

            <div className="flex items-center gap-2">
              <label htmlFor="global-chat-input" className="sr-only">
                Genel sohbet mesajı
              </label>
              <input
                ref={inputRef}
                id="global-chat-input"
                type="text"
                value={draft}
                maxLength={MAX_MESSAGE_LENGTH}
                disabled={sending || isPenalized}
                placeholder={
                  isPenalized ? 'Ceza süresince mesaj gönderilemez...' : 'Bir mesaj yazın...'
                }
                onChange={(e) => {
                  setDraft(e.target.value);
                  if (localError) setLocalError(null);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    void handleSubmit();
                  }
                }}
                className="flex-1 min-w-0 h-10 px-3 rounded-xl bg-slate-900 border border-slate-700/80 focus:border-amber-400 focus:outline-none text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 disabled:opacity-60"
              />
              <button
                type="submit"
                disabled={sending || isPenalized || trimmedLength === 0}
                aria-label="Mesaj gönder"
                title="Gönder (Enter)"
                className="w-10 h-10 flex items-center justify-center rounded-xl bg-amber-400 hover:bg-amber-300 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 transition-colors cursor-pointer disabled:cursor-not-allowed shrink-0"
              >
                <Send size={16} />
              </button>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span>Enter ile gönder</span>
              <span
                className={`font-mono-tabular ${
                  charCount >= 220 ? 'text-amber-300 font-semibold' : 'text-slate-500'
                }`}
              >
                {charCount}/{MAX_MESSAGE_LENGTH}
              </span>
            </div>
          </form>
        </>
      )}
    </aside>
  );
};
