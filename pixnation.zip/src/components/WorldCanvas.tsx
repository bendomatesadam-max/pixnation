import React, { useCallback, useEffect, useRef, useState } from 'react';
import { MAX_ZOOM, MIN_ZOOM } from '../constants/palette';
import { PixelMap } from '../services/storage';
import { ActiveTool, CameraState, PixelPoint, PlacedPixelRecord } from '../types/game';
import {
  getBasePixelColor,
  loadWorldMap,
  WORLD_HEIGHT,
  WORLD_WIDTH,
  WorldMapData,
} from '../utils/worldMapGenerator';

interface WorldCanvasProps {
  camera: CameraState;
  onCameraChange: (next: CameraState) => void;
  pixels: PixelMap;
  selectedColor: string;
  activeTool: ActiveTool;
  showGrid: boolean;
  isCooldownReady: boolean;
  onHoverPixel: (point: PixelPoint | null, record: PlacedPixelRecord | null) => void;
  onPlacePixel: (x: number, y: number) => void;
  onSampleColor: (hex: string) => void;
}

interface RippleEffect {
  x: number;
  y: number;
  color: string;
  startedAt: number;
}

export const WorldCanvas: React.FC<WorldCanvasProps> = ({
  camera,
  onCameraChange,
  pixels,
  selectedColor,
  activeTool,
  showGrid,
  isCooldownReady,
  onHoverPixel,
  onPlacePixel,
  onSampleColor,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const cameraRef = useRef<CameraState>(camera);
  const hoverRef = useRef<PixelPoint | null>(null);
  const ripplesRef = useRef<RippleEffect[]>([]);
  const [worldMap, setWorldMap] = useState<WorldMapData | null>(null);

  useEffect(() => {
    let mounted = true;
    void loadWorldMap().then((data) => {
      if (mounted) setWorldMap(data);
    });
    return () => {
      mounted = false;
    };
  }, []);

  // Pointer & pinch tracking refs
  const activePointersRef = useRef<Map<number, { x: number; y: number }>>(new Map());
  const dragStateRef = useRef<{
    isDragging: boolean;
    startX: number;
    startY: number;
    lastX: number;
    lastY: number;
    totalMove: number;
    pinchStartDist: number | null;
    pinchStartZoom: number;
    wasPinching: boolean;
  }>({
    isDragging: false,
    startX: 0,
    startY: 0,
    lastX: 0,
    lastY: 0,
    totalMove: 0,
    pinchStartDist: null,
    pinchStartZoom: camera.zoom,
    wasPinching: false,
  });

  cameraRef.current = camera;

  // Keep an offscreen canvas synced with all placed pixels
  useEffect(() => {
    if (!overlayCanvasRef.current) {
      const offscreen = document.createElement('canvas');
      offscreen.width = WORLD_WIDTH;
      offscreen.height = WORLD_HEIGHT;
      overlayCanvasRef.current = offscreen;
    }
    const overlay = overlayCanvasRef.current;
    const ctx = overlay.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
    pixels.forEach((record) => {
      ctx.fillStyle = record.color;
      ctx.fillRect(record.x, record.y, 1, 1);
    });
  }, [pixels]);

  const clampCamera = useCallback((next: CameraState): CameraState => {
    const zoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, next.zoom));
    const centerX = Math.min(WORLD_WIDTH, Math.max(0, next.centerX));
    const centerY = Math.min(WORLD_HEIGHT, Math.max(0, next.centerY));
    return { centerX, centerY, zoom };
  }, []);

  const screenToWorld = useCallback(
    (clientX: number, clientY: number): PixelPoint | null => {
      const canvas = canvasRef.current;
      if (!canvas) return null;
      const rect = canvas.getBoundingClientRect();
      const cam = cameraRef.current;
      const sx = clientX - rect.left;
      const sy = clientY - rect.top;

      const worldX = Math.floor(cam.centerX + (sx - rect.width / 2) / cam.zoom);
      const worldY = Math.floor(cam.centerY + (sy - rect.height / 2) / cam.zoom);

      if (worldX < 0 || worldX >= WORLD_WIDTH || worldY < 0 || worldY >= WORLD_HEIGHT) {
        return null;
      }
      return { x: worldX, y: worldY };
    },
    []
  );

  // Main render loop
  useEffect(() => {
    if (!worldMap) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;

    const render = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      const targetWidth = Math.max(1, Math.floor(rect.width * dpr));
      const targetHeight = Math.max(1, Math.floor(rect.height * dpr));

      if (canvas.width !== targetWidth || canvas.height !== targetHeight) {
        canvas.width = targetWidth;
        canvas.height = targetHeight;
      }

      ctx.save();
      ctx.scale(dpr, dpr);

      // Seamless ocean color outside map bounds
      ctx.fillStyle = '#CAE3FF';
      ctx.fillRect(0, 0, rect.width, rect.height);

      const cam = cameraRef.current;
      const mapLeft = rect.width / 2 - cam.centerX * cam.zoom;
      const mapTop = rect.height / 2 - cam.centerY * cam.zoom;
      const mapW = WORLD_WIDTH * cam.zoom;
      const mapH = WORLD_HEIGHT * cam.zoom;

      // Crisp pixel-art drawing
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(worldMap.baseCanvas, mapLeft, mapTop, mapW, mapH);

      if (overlayCanvasRef.current) {
        ctx.drawImage(overlayCanvasRef.current, mapLeft, mapTop, mapW, mapH);
      }

      // Subtle cartographic graticule lines every 128 world pixels
      ctx.strokeStyle = 'rgba(15, 23, 42, 0.06)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let gx = 0; gx <= WORLD_WIDTH; gx += 128) {
        const px = Math.round(mapLeft + gx * cam.zoom) + 0.5;
        if (px >= 0 && px <= rect.width) {
          ctx.moveTo(px, Math.max(0, mapTop));
          ctx.lineTo(px, Math.min(rect.height, mapTop + mapH));
        }
      }
      for (let gy = 0; gy <= WORLD_HEIGHT; gy += 128) {
        const py = Math.round(mapTop + gy * cam.zoom) + 0.5;
        if (py >= 0 && py <= rect.height) {
          ctx.moveTo(Math.max(0, mapLeft), py);
          ctx.lineTo(Math.min(rect.width, mapLeft + mapW), py);
        }
      }
      ctx.stroke();

      // World border frame
      ctx.strokeStyle = 'rgba(15, 23, 42, 0.16)';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(mapLeft, mapTop, mapW, mapH);

      // Optional pixel grid when zoomed in
      if (showGrid && cam.zoom >= 7) {
        const startX = Math.max(0, Math.floor(-mapLeft / cam.zoom));
        const endX = Math.min(WORLD_WIDTH, Math.ceil((rect.width - mapLeft) / cam.zoom));
        const startY = Math.max(0, Math.floor(-mapTop / cam.zoom));
        const endY = Math.min(WORLD_HEIGHT, Math.ceil((rect.height - mapTop) / cam.zoom));

        ctx.strokeStyle = cam.zoom >= 14 ? 'rgba(15, 23, 42, 0.28)' : 'rgba(15, 23, 42, 0.16)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let gx = startX; gx <= endX; gx++) {
          const px = Math.round(mapLeft + gx * cam.zoom) + 0.5;
          ctx.moveTo(px, Math.max(0, mapTop));
          ctx.lineTo(px, Math.min(rect.height, mapTop + mapH));
        }
        for (let gy = startY; gy <= endY; gy++) {
          const py = Math.round(mapTop + gy * cam.zoom) + 0.5;
          ctx.moveTo(Math.max(0, mapLeft), py);
          ctx.lineTo(Math.min(rect.width, mapLeft + mapW), py);
        }
        ctx.stroke();
      }

      // Active placement ripples
      const now = performance.now();
      ripplesRef.current = ripplesRef.current.filter((r) => now - r.startedAt < 450);
      for (const ripple of ripplesRef.current) {
        const progress = (now - ripple.startedAt) / 450;
        const rx = mapLeft + (ripple.x + 0.5) * cam.zoom;
        const ry = mapTop + (ripple.y + 0.5) * cam.zoom;
        const radius = cam.zoom * (0.6 + progress * 1.4);
        ctx.save();
        ctx.globalAlpha = (1 - progress) * 0.85;
        ctx.strokeStyle = ripple.color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(rx, ry, Math.max(4, radius), 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // Hover cell preview reticle
      const hovered = hoverRef.current;
      if (hovered) {
        const hx = mapLeft + hovered.x * cam.zoom;
        const hy = mapTop + hovered.y * cam.zoom;
        const cellSize = Math.max(3, cam.zoom);

        if (activeTool === 'paint') {
          ctx.save();
          ctx.globalAlpha = isCooldownReady ? 0.72 : 0.35;
          ctx.fillStyle = selectedColor;
          ctx.fillRect(hx, hy, cellSize, cellSize);
          ctx.restore();
        }

        ctx.strokeStyle = activeTool === 'eyedropper' ? '#38BDF8' : '#FFFFFF';
        ctx.lineWidth = 2;
        ctx.strokeRect(hx - 0.5, hy - 0.5, cellSize + 1, cellSize + 1);
        ctx.strokeStyle = '#0F172A';
        ctx.lineWidth = 1;
        ctx.strokeRect(hx - 1.5, hy - 1.5, cellSize + 3, cellSize + 3);
      }

      ctx.restore();
      rafId = requestAnimationFrame(render);
    };

    rafId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(rafId);
  }, [activeTool, isCooldownReady, selectedColor, showGrid, worldMap]);

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;

    const cam = cameraRef.current;
    const zoomFactor = e.deltaY < 0 ? 1.18 : 1 / 1.18;
    const nextZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, cam.zoom * zoomFactor));

    if (nextZoom === cam.zoom) return;

    // Keep world coordinate under cursor anchored
    const worldXAtCursor = cam.centerX + (sx - rect.width / 2) / cam.zoom;
    const worldYAtCursor = cam.centerY + (sy - rect.height / 2) / cam.zoom;

    const nextCenterX = worldXAtCursor - (sx - rect.width / 2) / nextZoom;
    const nextCenterY = worldYAtCursor - (sy - rect.height / 2) / nextZoom;

    onCameraChange(clampCamera({ centerX: nextCenterX, centerY: nextCenterY, zoom: nextZoom }));
  };

  const triggerClickAt = (clientX: number, clientY: number) => {
    const point = screenToWorld(clientX, clientY);
    if (!point) return;

    if (activeTool === 'eyedropper') {
      const existing = pixels.get(`${point.x}:${point.y}`);
      const color = existing ? existing.color : getBasePixelColor(point.x, point.y);
      onSampleColor(color);
      return;
    }

    if (isCooldownReady) {
      ripplesRef.current.push({
        x: point.x,
        y: point.y,
        color: selectedColor,
        startedAt: performance.now(),
      });
    }
    onPlacePixel(point.x, point.y);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.button === 2) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    activePointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    const pointers = Array.from(activePointersRef.current.values());
    if (pointers.length === 1) {
      dragStateRef.current = {
        isDragging: true,
        startX: e.clientX,
        startY: e.clientY,
        lastX: e.clientX,
        lastY: e.clientY,
        totalMove: 0,
        pinchStartDist: null,
        pinchStartZoom: cameraRef.current.zoom,
        wasPinching: false,
      };
    } else if (pointers.length === 2) {
      const dx = pointers[1].x - pointers[0].x;
      const dy = pointers[1].y - pointers[0].y;
      dragStateRef.current.pinchStartDist = Math.hypot(dx, dy);
      dragStateRef.current.pinchStartZoom = cameraRef.current.zoom;
      dragStateRef.current.wasPinching = true;
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (activePointersRef.current.has(e.pointerId)) {
      activePointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    }

    const pointers = Array.from(activePointersRef.current.values());

    if (pointers.length === 2 && dragStateRef.current.pinchStartDist) {
      const dx = pointers[1].x - pointers[0].x;
      const dy = pointers[1].y - pointers[0].y;
      const dist = Math.hypot(dx, dy);
      const scale = dist / dragStateRef.current.pinchStartDist;
      const nextZoom = Math.min(
        MAX_ZOOM,
        Math.max(MIN_ZOOM, dragStateRef.current.pinchStartZoom * scale)
      );
      onCameraChange(clampCamera({ ...cameraRef.current, zoom: nextZoom }));
      return;
    }

    if (dragStateRef.current.isDragging && pointers.length === 1) {
      const dx = e.clientX - dragStateRef.current.lastX;
      const dy = e.clientY - dragStateRef.current.lastY;
      dragStateRef.current.lastX = e.clientX;
      dragStateRef.current.lastY = e.clientY;
      dragStateRef.current.totalMove += Math.hypot(dx, dy);

      const cam = cameraRef.current;
      onCameraChange(
        clampCamera({
          centerX: cam.centerX - dx / cam.zoom,
          centerY: cam.centerY - dy / cam.zoom,
          zoom: cam.zoom,
        })
      );
    }

    const point = screenToWorld(e.clientX, e.clientY);
    hoverRef.current = point;
    if (point) {
      const record = pixels.get(`${point.x}:${point.y}`) ?? null;
      onHoverPixel(point, record);
    } else {
      onHoverPixel(null, null);
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    activePointersRef.current.delete(e.pointerId);

    const remaining = activePointersRef.current.size;
    if (remaining === 0) {
      const shouldClick =
        dragStateRef.current.isDragging &&
        !dragStateRef.current.wasPinching &&
        dragStateRef.current.totalMove < 6;

      dragStateRef.current.isDragging = false;
      dragStateRef.current.pinchStartDist = null;
      dragStateRef.current.wasPinching = false;

      if (shouldClick && (e.button === 0 || e.pointerType !== 'mouse')) {
        triggerClickAt(e.clientX, e.clientY);
      }
    } else if (remaining === 1) {
      const [only] = Array.from(activePointersRef.current.values());
      dragStateRef.current.lastX = only.x;
      dragStateRef.current.lastY = only.y;
      dragStateRef.current.pinchStartDist = null;
    }
  };

  const handlePointerLeave = () => {
    hoverRef.current = null;
    onHoverPixel(null, null);
  };

  const handleContextMenu = (e: React.MouseEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const point = screenToWorld(e.clientX, e.clientY);
    if (!point) return;
    const existing = pixels.get(`${point.x}:${point.y}`);
    const color = existing ? existing.color : getBasePixelColor(point.x, point.y);
    onSampleColor(color);
  };

  return (
    <canvas
      ref={canvasRef}
      onWheel={handleWheel}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onPointerLeave={handlePointerLeave}
      onContextMenu={handleContextMenu}
      aria-label="PixNation dünya piksel haritası"
      className={`block w-full h-full pixel-canvas select-none touch-none ${
        activeTool === 'eyedropper' ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'
      }`}
    />
  );
};
