import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  Crown,
  RefreshCw,
  Search,
  Shield,
  ShieldAlert,
  UserCheck,
  UserX,
  X,
} from 'lucide-react';
import { firebaseAuthProfiles } from '../services/storage';
import { ManagedPlayerSummary, UserRole } from '../types/game';

interface OwnerPanelModalProps {
  isOpen: boolean;
  ownerUid: string;
  onClose: () => void;
}

const ROLE_LABELS: Record<UserRole, { label: string; className: string }> = {
  owner: {
    label: 'Owner',
    className: 'bg-amber-400/20 text-amber-300 border-amber-400/40',
  },
  admin: {
    label: 'Admin',
    className: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
  },
  moderator: {
    label: 'Moderatör',
    className: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
  },
  player: {
    label: 'Oyuncu',
    className: 'bg-slate-800 text-slate-300 border-slate-700',
  },
};

export const OwnerPanelModal: React.FC<OwnerPanelModalProps> = ({
  isOpen,
  ownerUid,
  onClose,
}) => {
  const [players, setPlayers] = useState<ManagedPlayerSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [busyUid, setBusyUid] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const loadPlayers = useCallback(async () => {
    setLoading(true);
    setErrorMessage(null);
    try {
      const list = await firebaseAuthProfiles.fetchManagedPlayers();
      setPlayers(list);
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Sunucu üzerinden oyuncu listesi alınamadı.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      void loadPlayers();
    }
  }, [isOpen, loadPlayers]);

  if (!isOpen) return null;

  const handleRoleChange = async (
    targetUid: string,
    nextRole: 'player' | 'moderator' | 'admin'
  ) => {
    setBusyUid(targetUid);
    setErrorMessage(null);
    setSuccessMessage(null);
    try {
      await firebaseAuthProfiles.assignPlayerRole(targetUid, nextRole);
      setPlayers((prev) =>
        prev.map((p) => (p.uid === targetUid ? { ...p, role: nextRole } : p))
      );
      setSuccessMessage(
        `Yetki güncellendi (${ROLE_LABELS[nextRole].label}). Kullanıcının oturumunu yenilemesiyle aktif olur.`
      );
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Rol değiştirilemedi.');
    } finally {
      setBusyUid(null);
    }
  };

  const handleToggleStatus = async (target: ManagedPlayerSummary) => {
    setBusyUid(target.uid);
    setErrorMessage(null);
    setSuccessMessage(null);
    try {
      const nextDisabled = !target.disabled;
      await firebaseAuthProfiles.setPlayerDisabled(target.uid, nextDisabled);
      setPlayers((prev) =>
        prev.map((p) => (p.uid === target.uid ? { ...p, disabled: nextDisabled } : p))
      );
      setSuccessMessage(
        nextDisabled
          ? `${target.username} hesabı askıya alındı.`
          : `${target.username} hesabı yeniden aktifleştirildi.`
      );
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Hesap durumu güncellenemedi.');
    } finally {
      setBusyUid(null);
    }
  };

  const normalizedQuery = searchTerm.trim().toLowerCase();
  const filteredPlayers = players.filter((p) => {
    if (!normalizedQuery) return true;
    return (
      p.username.toLowerCase().includes(normalizedQuery) ||
      (p.email && p.email.toLowerCase().includes(normalizedQuery)) ||
      p.uid.toLowerCase().includes(normalizedQuery)
    );
  });

  const adminCount = players.filter((p) => p.role === 'admin').length;
  const modCount = players.filter((p) => p.role === 'moderator').length;

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="owner-panel-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[90dvh] flex flex-col rounded-2xl bg-slate-900 border border-amber-400/35 shadow-2xl text-slate-100 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 px-5 py-4 sm:px-6 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-amber-400/15 border border-amber-400/40 flex items-center justify-center text-amber-300 shrink-0">
              <Crown size={20} />
            </div>
            <div className="min-w-0">
              <h2 id="owner-panel-title" className="font-display text-lg sm:text-xl font-bold text-white">
                Owner Yönetim Paneli
              </h2>
              <p className="text-xs text-slate-400 truncate">
                Firebase Custom Claims üzerinden sunucu doğrulamalı rol ve oyuncu yönetimi
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Owner panelini kapat"
            className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
          >
            <X size={18} />
          </button>
        </div>

        {/* Summary & Search Bar */}
        <div className="px-5 py-3.5 sm:px-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-xs">
            <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono-tabular">
              Toplam: {players.length}
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 font-mono-tabular">
              Admin: {adminCount}
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-sky-500/10 border border-sky-500/30 text-sky-300 font-mono-tabular">
              Moderatör: {modCount}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative flex-1 sm:w-64">
              <Search
                size={14}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"
                aria-hidden="true"
              />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Kullanıcı adı, e-posta veya UID ara"
                className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>
            <button
              type="button"
              onClick={() => void loadPlayers()}
              disabled={loading}
              aria-label="Listeyi yenile"
              className="w-8 h-8 flex items-center justify-center rounded-xl bg-slate-950 border border-slate-700 text-slate-300 hover:text-white hover:border-slate-500 transition-colors cursor-pointer shrink-0"
            >
              <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>

        {/* Notices */}
        {(errorMessage || successMessage) && (
          <div className="px-5 pt-3 sm:px-6 space-y-2">
            {errorMessage && (
              <div
                role="alert"
                className="flex items-start gap-2 px-3 py-2.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-xs text-rose-200"
              >
                <AlertTriangle size={15} className="shrink-0 mt-0.5 text-rose-400" />
                <span>{errorMessage}</span>
              </div>
            )}
            {successMessage && (
              <div
                role="status"
                className="px-3 py-2 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-xs text-emerald-200"
              >
                {successMessage}
              </div>
            )}
          </div>
        )}

        {/* Player List */}
        <div className="flex-1 overflow-y-auto touch-pan-y px-5 py-4 sm:px-6 space-y-2.5">
          {loading && players.length === 0 ? (
            <p className="text-xs text-slate-400 py-8 text-center">
              Oyuncular sunucudan yükleniyor...
            </p>
          ) : filteredPlayers.length === 0 ? (
            <p className="text-xs text-slate-400 py-8 text-center">
              Eşleşen oyuncu bulunamadı.
            </p>
          ) : (
            filteredPlayers.map((player) => {
              const isSelfOwner = player.uid === ownerUid || player.role === 'owner';
              const roleBadge = ROLE_LABELS[player.role];
              const isBusy = busyUid === player.uid;

              return (
                <div
                  key={player.uid}
                  className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl border transition-colors ${
                    player.disabled
                      ? 'bg-rose-950/20 border-rose-900/50'
                      : 'bg-slate-950/75 border-slate-800'
                  }`}
                >
                  <div className="min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-white truncate">
                        {player.username}
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md border text-[11px] font-medium ${roleBadge.className}`}
                      >
                        {player.role === 'owner' && <Crown size={11} />}
                        {player.role === 'admin' && <ShieldAlert size={11} />}
                        {player.role === 'moderator' && <Shield size={11} />}
                        {roleBadge.label}
                      </span>
                      {player.disabled && (
                        <span className="px-2 py-0.5 rounded-md bg-rose-500/20 border border-rose-500/40 text-[11px] text-rose-300">
                          Askıda
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-slate-400">
                      {player.email && <span className="truncate">{player.email}</span>}
                      <span className="font-mono-tabular text-slate-500">
                        UID: {player.uid}
                      </span>
                      <span className="font-mono-tabular text-slate-300">
                        {player.totalPixelsPlaced} piksel
                      </span>
                    </div>
                  </div>

                  {/* Controls (Locked for Owner account itself) */}
                  {isSelfOwner ? (
                    <span className="text-[11px] text-amber-300/80 font-medium shrink-0">
                      Ana Owner (Korumalı)
                    </span>
                  ) : (
                    <div className="flex items-center gap-2 shrink-0">
                      <label htmlFor={`role-${player.uid}`} className="sr-only">
                        {player.username} rolü
                      </label>
                      <select
                        id={`role-${player.uid}`}
                        value={player.role}
                        disabled={isBusy}
                        onChange={(e) =>
                          void handleRoleChange(
                            player.uid,
                            e.target.value as 'player' | 'moderator' | 'admin'
                          )
                        }
                        className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-100 focus:outline-none focus:border-amber-400 cursor-pointer disabled:opacity-50"
                      >
                        <option value="player">Oyuncu</option>
                        <option value="moderator">Moderatör</option>
                        <option value="admin">Admin</option>
                      </select>

                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => void handleToggleStatus(player)}
                        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-medium transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap ${
                          player.disabled
                            ? 'border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/10'
                            : 'border-rose-500/40 text-rose-300 hover:bg-rose-500/10'
                        }`}
                      >
                        {player.disabled ? (
                          <>
                            <UserCheck size={13} />
                            <span>Aktifleştir</span>
                          </>
                        ) : (
                          <>
                            <UserX size={13} />
                            <span>Askıya Al</span>
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer Security Note */}
        <div className="px-5 py-3 sm:px-6 border-t border-slate-800 bg-slate-950/60 text-[11px] text-slate-400">
          Yeni Owner ataması panel üzerinden yapılamaz; tüm rol değişiklikleri sunucu tarafında Firebase Custom Claims ile imzalanır.
        </div>
      </div>
    </div>
  );
};
