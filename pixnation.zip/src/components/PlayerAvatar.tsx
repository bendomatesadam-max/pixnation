import React from 'react';
import { Anchor, Compass, Crown, Mountain, Palette, Star } from 'lucide-react';
import { AvatarEmblem } from '../types/game';

interface PlayerAvatarProps {
  emblem: AvatarEmblem;
  accentColor: string;
  size?: 'sm' | 'md' | 'lg';
}

const EMBLEM_MAP = {
  compass: Compass,
  crown: Crown,
  palette: Palette,
  anchor: Anchor,
  mountain: Mountain,
  star: Star,
};

export const PlayerAvatar: React.FC<PlayerAvatarProps> = ({
  emblem,
  accentColor,
  size = 'md',
}) => {
  const Icon = EMBLEM_MAP[emblem] ?? Compass;

  const dimensions =
    size === 'sm'
      ? 'w-7 h-7 rounded-lg'
      : size === 'lg'
        ? 'w-12 h-12 rounded-xl'
        : 'w-9 h-9 rounded-lg';

  const iconPx = size === 'sm' ? 14 : size === 'lg' ? 22 : 17;

  return (
    <div
      className={`${dimensions} flex items-center justify-center shrink-0 border border-white/15 shadow-sm`}
      style={{ backgroundColor: accentColor }}
      aria-hidden="true"
    >
      <Icon size={iconPx} className="text-slate-950 stroke-[2.2]" />
    </div>
  );
};
