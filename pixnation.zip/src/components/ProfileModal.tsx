import React, { useEffect, useState } from 'react';
import {
  Anchor,
  Check,
  Compass,
  Copy,
  Crown,
  LogOut,
  MapPin,
  Mountain,
  Palette,
  RefreshCw,
  Star,
  X,
} from 'lucide-react';
import { PROFILE_ACCENT_COLORS } from '../constants/palette';
import { translateFirebaseError } from '../services/storage';
import { AvatarEmblem, PlacedPixelRecord, PlayerProfile, UserRole } from '../types/game';
import { PlayerAvatar } from './PlayerAvatar';

interface ProfileModalProps {
  isOpen: boolean;
  activeProfile: PlayerProfile;
  userEmail: string | null;
  customRole: UserRole;
  recentPlacements: PlacedPixelRecord[];
  onClose: () => void;
  onSaveProfile: (data: {
    id: string;
    username: string;
    bio: string;
    countryCode: string;
    accentColor: string;
    emblem: AvatarEmblem;
  }) => Promise<void>;
  onRefreshClaims: () => Promise<void>;
  onCheckOwnerBootstrap?: () => Promise<boolean>;
  onClaimInitialOwner?: () => Promise<void>;
  onOpenOwnerPanel?: () => void;
  onSignOut: () => Promise<void>;
  onJumpToCoordinate: (x: number, y: number) => void;
}

const EMBLEM_OPTIONS: { id: AvatarEmblem; label: string; Icon: React.FC<{ size?: number }> }[] = [
  { id: 'compass', label: 'Pusula', Icon: Compass },
  { id: 'crown', label: 'Taç', Icon: Crown },
  { id: 'palette', label: 'Palet', Icon: Palette },
  { id: 'anchor', label: 'Çapa', Icon: Anchor },
  { id: 'mountain', label: 'Dağ', Icon: Mountain },
  { id: 'star', label: 'Yıldız', Icon: Star },
];

const ROLE_BADGE_MAP: Record<UserRole, { label: string; style: string }> = {
  owner: { label: 'Owner', style: 'bg-amber-400/20 text-amber-300 border-amber-400/40' },
  admin: { label: 'Admin', style: 'bg-rose-500/20 text-rose-300 border-rose-500/40' },
  moderator: { label: 'Moderatör', style: 'bg-sky-500/20 text-sky-300 border-sky-500/40' },
  player: { label: 'Oyuncu', style: 'bg-slate-800 text-slate-300 border-slate-700' },
};

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  activeProfile,
  userEmail,
  customRole,
  recentPlacements,
  onClose,
  onSaveProfile,
  onRefreshClaims,
  onCheckOwnerBootstrap,
  onClaimInitialOwner,
  onOpenOwnerPanel,
  onSignOut,
  onJumpToCoordinate,
}) => {
  const [username, setUsername] = useState(activeProfile.username);
  const [bio, setBio] = useState(activeProfile.bio);
  const [countryCode, setCountryCode] = useState(activeProfile.countryCode);
  const [accentColor, setAccentColor] = useState(activeProfile.accentColor);
  const [emblem, setEmblem] = useState<AvatarEmblem>(activeProfile.emblem);

  const [saving, setSaving] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);
  const [errorNotice, setErrorNotice] = useState<string | null>(null);
  const [copiedUid, setCopiedUid] = useState(false);
  const [refreshingRole, setRefreshingRole] = useState(false);
  const [canClaimOwner, setCanClaimOwner] = useState(false);
  const [claimingOwner, setClaimingOwner] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setUsername(activeProfile.username);
    setBio(activeProfile.bio);
    setCountryCode(activeProfile.countryCode);
    setAccentColor(activeProfile.accentColor);
    setEmblem(activeProfile.emblem);
    setErrorNotice(null);
  }, [activeProfile.id, isOpen]);

  useEffect(() => {
    let active = true;
    if (!isOpen || customRole === 'owner' || !onCheckOwnerBootstrap) {
      setCanClaimOwner(false);
      return;
    }
    void onCheckOwnerBootstrap().then((eligible) => {
      if (active) setCanClaimOwner(eligible);
    });
    return () => {
      active = false;
    };
  }, [isOpen, customRole, onCheckOwnerBootstrap]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;
    setSaving(true);
    setErrorNotice(null);
    try {
      await onSaveProfile({
        id: activeProfile.id,
        username: username.trim(),
        bio: bio.trim(),
        countryCode: countryCode.trim().toUpperCase() || 'TR',
        accentColor,
        emblem,
      });
      setSavedNotice(true);
      setTimeout(() => setSavedNotice(false), 1800);
    } catch (err) {
      setErrorNotice(translateFirebaseError(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="profile-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg max-h-[88dvh] overflow-y-auto touch-pan-y rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl text-slate-100 p-5 sm:p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3.5 min-w-0">
            <PlayerAvatar emblem={emblem} accentColor={accentColor} size="lg" />
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 id="profile-modal-title" className="font-display text-xl font-bold text-white truncate">
                  {activeProfile.username}
                </h2>
                <span
                  className={`px-2 py-0.5 rounded-md border text-[11px] font-semibold ${ROLE_BADGE_MAP[customRole].style}`}
                >
                  {ROLE_BADGE_MAP[customRole].label}
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate">
                {activeProfile.countryCode} ·{' '}
                <span className="font-mono-tabular text-slate-300">
                  {activeProfile.totalPixelsPlaced} piksel yerleştirildi
                </span>
              </p>
              {userEmail && (
                <p className="text-[11px] text-slate-500 truncate mt-0.5">{userEmail}</p>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Profili kapat"
            className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
          >
            <X size={18} />
          </button>
        </div>

        {/* Firebase UID & Verified Claim Controls */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px]">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-slate-400 shrink-0">UID:</span>
            <code className="font-mono-tabular text-slate-200 truncate">{activeProfile.id}</code>
            <button
              type="button"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(activeProfile.id);
                  setCopiedUid(true);
                  setTimeout(() => setCopiedUid(false), 1600);
                } catch {
                  // Ignore clipboard restrictions
                }
              }}
              aria-label="UID kopyala"
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer shrink-0"
            >
              {copiedUid ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
              <span>{copiedUid ? 'Kopyalandı' : 'Kopyala'}</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              disabled={refreshingRole}
              onClick={async () => {
                setRefreshingRole(true);
                try {
                  await onRefreshClaims();
                } finally {
                  setRefreshingRole(false);
                }
              }}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer shrink-0"
            >
              <RefreshCw size={11} className={refreshingRole ? 'animate-spin' : ''} />
              <span>Yetkiyi Yenile</span>
            </button>

            {canClaimOwner && onClaimInitialOwner && (
              <button
                type="button"
                disabled={claimingOwner}
                onClick={async () => {
                  setClaimingOwner(true);
                  setErrorNotice(null);
                  try {
                    await onClaimInitialOwner();
                    setCanClaimOwner(false);
                  } catch (err) {
                    setErrorNotice(
                      err instanceof Error ? err.message : 'İlk Owner kurulumu tamamlanamadı.'
                    );
                  } finally {
                    setClaimingOwner(false);
                  }
                }}
                className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-amber-400 text-slate-950 hover:bg-amber-300 font-semibold transition-colors cursor-pointer shrink-0 disabled:opacity-60"
              >
                <Crown size={11} />
                <span>{claimingOwner ? 'Aktifleştiriliyor...' : 'İlk Owner Yetkisini Aktifleştir'}</span>
              </button>
            )}

            {customRole === 'owner' && onOpenOwnerPanel && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenOwnerPanel();
                }}
                className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-amber-400/20 border border-amber-400/40 text-amber-300 hover:bg-amber-400/30 font-semibold transition-colors cursor-pointer shrink-0"
              >
                <Crown size={11} />
                <span>Owner Paneli</span>
              </button>
            )}
          </div>
        </div>

        {/* Profile Edit Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-2 border-t border-slate-800">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-3">
              <label htmlFor="player-username" className="block text-xs font-medium text-slate-300 mb-1.5">
                Kullanıcı Adı
              </label>
              <input
                id="player-username"
                type="text"
                maxLength={20}
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Örn. KaptanPiksel"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label htmlFor="player-country" className="block text-xs font-medium text-slate-300 mb-1.5">
                Ülke Kodu
              </label>
              <input
                id="player-country"
                type="text"
                maxLength={3}
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value.toUpperCase())}
                placeholder="TR"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm font-mono-tabular text-white uppercase placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div>
            <label htmlFor="player-bio" className="block text-xs font-medium text-slate-300 mb-1.5">
              Profil Notu
            </label>
            <input
              id="player-bio"
              type="text"
              maxLength={80}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Kısa bir imza veya motto yazın"
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Emblem & Color Picker */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <span className="block text-xs font-medium text-slate-300 mb-2">Amblem</span>
              <div className="flex flex-wrap gap-1.5">
                {EMBLEM_OPTIONS.map(({ id, label, Icon }) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setEmblem(id)}
                    aria-label={label}
                    title={label}
                    className={`w-9 h-9 flex items-center justify-center rounded-xl border transition-colors cursor-pointer ${
                      emblem === id
                        ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Icon size={16} />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="block text-xs font-medium text-slate-300 mb-2">Profil Rengi</span>
              <div className="flex flex-wrap gap-1.5">
                {PROFILE_ACCENT_COLORS.map((hex) => (
                  <button
                    key={hex}
                    type="button"
                    onClick={() => setAccentColor(hex)}
                    aria-label={`Profil rengi ${hex}`}
                    className={`w-8 h-8 rounded-lg transition-transform cursor-pointer ${
                      accentColor === hex
                        ? 'ring-2 ring-white ring-offset-2 ring-offset-slate-900 scale-105'
                        : 'border border-white/15 hover:scale-105'
                    }`}
                    style={{ backgroundColor: hex }}
                  />
                ))}
              </div>
            </div>
          </div>

          {errorNotice && (
            <div className="px-3 py-2 rounded-xl bg-rose-500/15 border border-rose-500/40 text-xs text-rose-200">
              {errorNotice}
            </div>
          )}

          <div className="flex items-center justify-between gap-3 pt-1">
            <span className="text-xs text-emerald-400 min-h-[1rem]">
              {savedNotice ? 'Profil kaydedildi.' : ''}
            </span>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-slate-950 text-xs sm:text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              {saving ? 'Kaydediliyor...' : 'Değişiklikleri Kaydet'}
            </button>
          </div>
        </form>

        {/* Recent Placed Pixels */}
        <div className="pt-4 border-t border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-200">Son Yerleştirilen Pikseller</h3>
            <span className="text-xs text-slate-400 font-mono-tabular">
              {recentPlacements.length} kayıt
            </span>
          </div>

          {recentPlacements.length === 0 ? (
            <p className="text-xs text-slate-400 py-2">
              Henüz haritaya piksel yerleştirmediniz. Haritaya tıklayarak ilk pikselinizi koyabilirsiniz.
            </p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-36 overflow-y-auto pr-1">
              {recentPlacements.slice(0, 8).map((item) => (
                <button
                  key={`${item.x}:${item.y}:${item.placedAt}`}
                  type="button"
                  onClick={() => {
                    onJumpToCoordinate(item.x, item.y);
                    onClose();
                  }}
                  className="flex items-center justify-between gap-2 px-2.5 py-2 rounded-xl bg-slate-950/90 border border-slate-800 hover:border-slate-600 text-left transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className="w-4 h-4 rounded border border-white/20 shrink-0"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="font-mono-tabular text-xs text-slate-200 truncate">
                      X: {item.x}, Y: {item.y}
                    </span>
                  </div>
                  <MapPin size={13} className="text-amber-400 shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Account Sign Out */}
        <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
          <span className="text-xs text-slate-400">Firebase hesabı ile senkronize</span>
          <button
            type="button"
            onClick={async () => {
              await onSignOut();
              onClose();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-500/40 text-rose-300 hover:bg-rose-500/10 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap"
          >
            <LogOut size={13} />
            <span>Çıkış Yap</span>
          </button>
        </div>
      </div>
    </div>
  );
};
