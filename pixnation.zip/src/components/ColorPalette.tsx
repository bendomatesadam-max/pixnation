import React, { useState } from 'react';
import { Check, ChevronRight, Palette as PaletteIcon, Pipette } from 'lucide-react';
import { PIXEL_PALETTE } from '../constants/palette';
import { ActiveTool } from '../types/game';

interface ColorPaletteProps {
  selectedColor: string;
  activeTool: ActiveTool;
  isChatOpen?: boolean;
  onSelectColor: (hex: string) => void;
  onToggleEyedropper: () => void;
}

export const ColorPalette: React.FC<ColorPaletteProps> = ({
  selectedColor,
  activeTool,
  isChatOpen = false,
  onSelectColor,
  onToggleEyedropper,
}) => {
  const [collapsed, setCollapsed] = useState(false);

  const selectedObj = PIXEL_PALETTE.find(
    (c) => c.hex.toLowerCase() === selectedColor.toLowerCase()
  );

  const positionClass = isChatOpen
    ? 'right-3 sm:right-[364px]'
    : 'right-3 sm:right-4';

  if (collapsed) {
    return (
      <aside
        aria-label="Renk Paleti"
        className={`fixed ${positionClass} top-[54%] -translate-y-1/2 z-20 transition-[right] duration-200`}
      >
        <button
          type="button"
          onClick={() => setCollapsed(false)}
          aria-label="Renk paletini aç"
          className="flex flex-col items-center gap-2 p-2.5 rounded-xl bg-slate-950/92 border border-slate-700/70 shadow-xl backdrop-blur-md text-slate-100 hover:border-slate-500 transition-colors cursor-pointer"
        >
          <span
            className="w-6 h-6 rounded-md border border-white/30"
            style={{ backgroundColor: selectedColor }}
          />
          <PaletteIcon size={16} className="text-slate-300" />
        </button>
      </aside>
    );
  }

  return (
    <aside
      aria-label="Dikey Renk Paleti"
      className={`fixed ${positionClass} top-[54%] -translate-y-1/2 z-20 flex flex-col items-center gap-2 p-2.5 rounded-2xl bg-slate-950/92 border border-slate-700/75 shadow-2xl backdrop-blur-md max-h-[60dvh] transition-[right] duration-200`}
    >
      {/* Active color preview + collapse toggle */}
      <div className="flex items-center justify-between w-full gap-1.5 pb-1.5 border-b border-slate-800">
        <div
          className="w-7 h-7 rounded-lg border border-white/25 shrink-0 shadow-inner"
          style={{ backgroundColor: selectedColor }}
          title={selectedObj ? `${selectedObj.name} (${selectedColor})` : selectedColor}
        />
        <button
          type="button"
          onClick={() => setCollapsed(true)}
          aria-label="Paleti küçült"
          title="Paleti küçült"
          className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800/80 transition-colors cursor-pointer"
        >
          <ChevronRight size={15} />
        </button>
      </div>

      {/* Eyedropper tool button */}
      <button
        type="button"
        onClick={onToggleEyedropper}
        aria-pressed={activeTool === 'eyedropper'}
        aria-label="Haritadan renk seç (I)"
        title="Renk Seçici (I)"
        className={`w-full h-9 flex items-center justify-center gap-1 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
          activeTool === 'eyedropper'
            ? 'bg-sky-500/20 border-sky-400 text-sky-200'
            : 'bg-slate-900/90 border-slate-800 text-slate-300 hover:text-white hover:border-slate-600'
        }`}
      >
        <Pipette size={14} />
        <span className="hidden sm:inline text-[11px]">Seç</span>
      </button>

      {/* Vertical 2-column swatch grid */}
      <div className="grid grid-cols-2 gap-1.5 overflow-y-auto no-scrollbar py-0.5 pr-0.5">
        {PIXEL_PALETTE.map((swatch) => {
          const isSelected =
            activeTool === 'paint' &&
            selectedColor.toLowerCase() === swatch.hex.toLowerCase();
          const isLight =
            swatch.hex === '#FFFFFF' ||
            swatch.hex === '#FACC15' ||
            swatch.hex === '#CAE3FF' ||
            swatch.hex === '#FDBA74';

          return (
            <button
              key={swatch.id}
              type="button"
              onClick={() => onSelectColor(swatch.hex)}
              aria-label={swatch.name}
              aria-pressed={isSelected}
              title={swatch.name}
              className={`relative w-7 h-7 sm:w-8 sm:h-8 rounded-lg transition-transform duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-amber-400 ${
                isSelected
                  ? 'scale-105 ring-2 ring-white ring-offset-2 ring-offset-slate-950 z-10'
                  : 'hover:scale-105 border border-white/15'
              }`}
              style={{ backgroundColor: swatch.hex }}
            >
              {isSelected && (
                <Check
                  size={14}
                  className={`mx-auto stroke-[3] ${
                    isLight ? 'text-slate-900' : 'text-white'
                  }`}
                />
              )}
            </button>
          );
        })}
      </div>
    </aside>
  );
};
