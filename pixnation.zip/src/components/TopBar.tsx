import React from 'react';
import {
  Compass,
  Crown,
  Grid3X3,
  HelpCircle,
  LogIn,
  ShieldAlert,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { REGION_PRESETS } from '../constants/palette';
import { PlayerProfile, RegionPreset, UserRole } from '../types/game';
import { PixNationLogo } from './PixNationLogo';
import { PlayerAvatar } from './PlayerAvatar';

interface TopBarProps {
  profile: PlayerProfile | null;
  customRole: UserRole;
  showGrid: boolean;
  soundEnabled: boolean;
  onToggleGrid: () => void;
  onToggleSound: () => void;
  onSelectRegion: (region: RegionPreset) => void;
  onOpenProfile: () => void;
  onOpenOwnerPanel: () => void;
  onOpenModerationPanel: () => void;
  onOpenAuth: () => void;
  onOpenHelp: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  profile,
  customRole,
  showGrid,
  soundEnabled,
  onToggleGrid,
  onToggleSound,
  onSelectRegion,
  onOpenProfile,
  onOpenOwnerPanel,
  onOpenModerationPanel,
  onOpenAuth,
  onOpenHelp,
}) => {
  return (
    <header className="fixed top-3 left-3 right-3 sm:top-4 sm:left-4 sm:right-4 z-20 flex items-center justify-between gap-3 pointer-events-none">
      {/* Left: Brand & Quick Map Controls */}
      <div className="flex items-center gap-2 sm:gap-3 px-3 py-2 rounded-2xl bg-slate-950/90 border border-slate-700/75 shadow-xl backdrop-blur-md pointer-events-auto min-w-0">
        <PixNationLogo size="sm" />

        <div className="h-5 w-px bg-slate-800 hidden sm:block shrink-0" />

        {/* Region jump selector */}
        <div className="hidden md:flex items-center gap-1.5">
          <Compass size={14} className="text-slate-400 shrink-0" aria-hidden="true" />
          <label htmlFor="region-select" className="sr-only">
            Bölgeye git
          </label>
          <select
            id="region-select"
            defaultValue="world"
            onChange={(e) => {
              const target = REGION_PRESETS.find((r) => r.id === e.target.value);
              if (target) onSelectRegion(target);
            }}
            className="bg-transparent text-xs font-medium text-slate-200 hover:text-white focus:outline-none cursor-pointer pr-1"
          >
            {REGION_PRESETS.map((preset) => (
              <option key={preset.id} value={preset.id} className="bg-slate-900 text-slate-100">
                {preset.label}
              </option>
            ))}
          </select>
        </div>

        <div className="h-5 w-px bg-slate-800 hidden md:block shrink-0" />

        {/* Map Utility Toggles */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onToggleGrid}
            aria-pressed={showGrid}
            aria-label="Piksel ızgarasını aç/kapat (G)"
            title="Izgara (G)"
            className={`w-9 h-9 flex items-center justify-center rounded-xl transition-colors cursor-pointer ${
              showGrid
                ? 'bg-amber-400/15 text-amber-300 border border-amber-400/40'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80 border border-transparent'
            }`}
          >
            <Grid3X3 size={16} />
          </button>

          <button
            type="button"
            onClick={onToggleSound}
            aria-pressed={soundEnabled}
            aria-label={soundEnabled ? 'Sesleri kapat' : 'Sesleri aç'}
            title={soundEnabled ? 'Ses Açık' : 'Ses Kapalı'}
            className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>

          <button
            type="button"
            onClick={onOpenHelp}
            aria-label="Kontroller ve yardım"
            title="Nasıl Oynanır?"
            className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
          >
            <HelpCircle size={16} />
          </button>
        </div>
      </div>

      {/* Right: Moderation / Owner Panel & Player Profile / Sign-In */}
      <div className="flex items-center gap-2 pointer-events-auto shrink-0">
        {profile && (customRole === 'owner' || customRole === 'admin') && (
          <button
            type="button"
            onClick={onOpenModerationPanel}
            aria-label="Moderasyon Merkezi"
            className="flex items-center gap-1.5 px-3 py-2.5 rounded-2xl bg-rose-500/90 hover:bg-rose-400 text-white text-xs sm:text-sm font-bold shadow-xl transition-colors cursor-pointer shrink-0 whitespace-nowrap"
          >
            <ShieldAlert size={15} />
            <span className="hidden sm:inline">Moderasyon</span>
          </button>
        )}

        {profile && customRole === 'owner' && (
          <button
            type="button"
            onClick={onOpenOwnerPanel}
            aria-label="Owner Yönetim Paneli"
            className="flex items-center gap-1.5 px-3 py-2.5 rounded-2xl bg-amber-400/95 hover:bg-amber-300 text-slate-950 text-xs sm:text-sm font-bold shadow-xl transition-colors cursor-pointer shrink-0 whitespace-nowrap"
          >
            <Crown size={15} />
            <span className="hidden sm:inline">Owner Paneli</span>
          </button>
        )}

        {profile ? (
          <button
            type="button"
            onClick={onOpenProfile}
            className="flex items-center gap-2.5 pl-2 pr-3 py-1.5 rounded-2xl bg-slate-950/90 border border-slate-700/75 hover:border-slate-500 shadow-xl backdrop-blur-md transition-colors cursor-pointer shrink-0 max-w-[190px] sm:max-w-[260px]"
          >
            <PlayerAvatar
              emblem={profile.emblem}
              accentColor={profile.accentColor}
              size="sm"
            />
            <div className="flex flex-col items-start min-w-0 text-left">
              <span className="text-xs sm:text-sm font-semibold text-slate-100 truncate max-w-[110px] sm:max-w-[150px] whitespace-nowrap">
                {profile.username}
              </span>
              <span className="text-[11px] text-slate-400 font-mono-tabular whitespace-nowrap">
                {profile.totalPixelsPlaced} piksel
              </span>
            </div>
          </button>
        ) : (
          <button
            type="button"
            onClick={onOpenAuth}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs sm:text-sm font-semibold shadow-xl transition-colors cursor-pointer shrink-0 whitespace-nowrap"
          >
            <LogIn size={15} />
            <span>Giriş Yap</span>
          </button>
        )}
      </div>
    </header>
  );
};
