import React from 'react';

interface PixNationLogoProps {
  size?: 'sm' | 'md';
}

export const PixNationLogo: React.FC<PixNationLogoProps> = ({ size = 'md' }) => {
  const iconSize = size === 'sm' ? 28 : 32;

  return (
    <div className="flex items-center gap-2.5 select-none shrink-0">
      <svg
        width={iconSize}
        height={iconSize}
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="shrink-0"
      >
        {/* Outer rounded atlas frame */}
        <rect x="2" y="2" width="28" height="28" rx="7" fill="#0F2238" stroke="#334155" strokeWidth="1.5" />
        {/* Pixel mosaic globe motif */}
        <rect x="11" y="6" width="5" height="5" rx="1" fill="#F59E0B" />
        <rect x="16" y="6" width="5" height="5" rx="1" fill="#F97316" />
        <rect x="6" y="11" width="5" height="5" rx="1" fill="#14B8A6" />
        <rect x="11" y="11" width="5" height="5" rx="1" fill="#FEF3C7" />
        <rect x="16" y="11" width="5" height="5" rx="1" fill="#EF4444" />
        <rect x="21" y="11" width="5" height="5" rx="1" fill="#3B82F6" />
        <rect x="6" y="16" width="5" height="5" rx="1" fill="#3B82F6" />
        <rect x="11" y="16" width="5" height="5" rx="1" fill="#10B981" />
        <rect x="16" y="16" width="5" height="5" rx="1" fill="#F59E0B" />
        <rect x="21" y="16" width="5" height="5" rx="1" fill="#14B8A6" />
        <rect x="11" y="21" width="5" height="5" rx="1" fill="#06B6D4" />
        <rect x="16" y="21" width="5" height="5" rx="1" fill="#10B981" />
      </svg>
      <span className="font-display text-lg sm:text-xl font-bold tracking-tight text-slate-50 whitespace-nowrap">
        Pix<span className="text-amber-400">Nation</span>
      </span>
    </div>
  );
};
