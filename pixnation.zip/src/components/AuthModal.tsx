import React, { useState } from 'react';
import { ArrowLeft, Eye, EyeOff, KeyRound, LogIn, UserPlus, X } from 'lucide-react';
import { translateFirebaseError } from '../services/storage';
import { PixNationLogo } from './PixNationLogo';

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: 'login' | 'register';
  onClose: () => void;
  onSignIn: (email: string, password: string) => Promise<void>;
  onRegister: (email: string, password: string, username: string) => Promise<void>;
  onResetPassword?: (email: string) => Promise<void>;
}

type AuthMode = 'login' | 'register' | 'reset';

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode = 'login',
  onClose,
  onSignIn,
  onRegister,
  onResetPassword,
}) => {
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const switchMode = (nextMode: AuthMode) => {
    setMode(nextMode);
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      setErrorMessage('E-posta adresini girin.');
      return;
    }

    if (mode === 'reset') {
      if (!onResetPassword) return;
      setSubmitting(true);
      try {
        await onResetPassword(trimmedEmail);
        setSuccessMessage(
          'Şifre sıfırlama bağlantısı e-posta adresinize gönderildi.'
        );
      } catch (err) {
        setErrorMessage(translateFirebaseError(err));
      } finally {
        setSubmitting(false);
      }
      return;
    }

    if (!password) {
      setErrorMessage('E-posta ve şifre alanlarını doldurun.');
      return;
    }

    if (mode === 'register' && username.trim().length < 2) {
      setErrorMessage('Kullanıcı adı en az 2 karakter olmalıdır.');
      return;
    }

    setSubmitting(true);
    try {
      if (mode === 'login') {
        await onSignIn(trimmedEmail, password);
      } else {
        await onRegister(trimmedEmail, password, username);
      }
      setPassword('');
      onClose();
    } catch (err) {
      setErrorMessage(translateFirebaseError(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md max-h-[90dvh] overflow-y-auto touch-pan-y rounded-2xl bg-slate-900/98 border border-slate-700/80 shadow-2xl text-slate-100 p-5 sm:p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1.5">
            <PixNationLogo size="sm" />
            <h2 id="auth-modal-title" className="font-display text-xl font-bold text-white">
              {mode === 'login'
                ? 'PixNation Hesabına Gir'
                : mode === 'register'
                  ? 'Yeni Hesap Oluştur'
                  : 'Şifreni Sıfırla'}
            </h2>
            <p className="text-xs text-slate-400">
              {mode === 'login'
                ? 'Haritaya piksel yerleştirmek ve sohbete katılmak için oturum aç.'
                : mode === 'register'
                  ? 'Ücretsiz hesabını oluştur ve canlı dünya haritasında oyna.'
                  : 'Kayıtlı e-posta adresine sıfırlama bağlantısı gönder.'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Kapat"
            className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
          >
            <X size={18} />
          </button>
        </div>

        {/* Mode Switcher */}
        {mode !== 'reset' ? (
          <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-950 border border-slate-800">
            <button
              type="button"
              onClick={() => switchMode('login')}
              className={`min-h-[40px] flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                mode === 'login'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <LogIn size={14} />
              <span>Giriş Yap</span>
            </button>
            <button
              type="button"
              onClick={() => switchMode('register')}
              className={`min-h-[40px] flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                mode === 'register'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserPlus size={14} />
              <span>Kayıt Ol</span>
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => switchMode('login')}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft size={14} />
            <span>Giriş ekranına dön</span>
          </button>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {mode === 'register' && (
            <div>
              <label htmlFor="auth-username" className="block text-xs font-medium text-slate-300 mb-1.5">
                Kullanıcı Adı
              </label>
              <input
                id="auth-username"
                type="text"
                maxLength={20}
                required
                autoComplete="nickname"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Örn. KaptanPiksel"
                className="w-full min-h-[44px] px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>
          )}

          <div>
            <label htmlFor="auth-email" className="block text-xs font-medium text-slate-300 mb-1.5">
              E-posta
            </label>
            <input
              id="auth-email"
              type="email"
              required
              autoComplete="email"
              inputMode="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="ornek@eposta.com"
              className="w-full min-h-[44px] px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          {mode !== 'reset' && (
            <div>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <label htmlFor="auth-password" className="block text-xs font-medium text-slate-300">
                  Şifre
                </label>
                {mode === 'login' && onResetPassword && (
                  <button
                    type="button"
                    onClick={() => switchMode('reset')}
                    className="text-[11px] text-amber-300 hover:text-amber-200 transition-colors cursor-pointer"
                  >
                    Şifremi unuttum
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  id="auth-password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="En az 6 karakter"
                  className="w-full min-h-[44px] pl-3 pr-11 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? 'Şifreyi gizle' : 'Şifreyi göster'}
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 w-9 h-9 flex items-center justify-center rounded-lg text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
          )}

          {errorMessage && (
            <div
              role="alert"
              className="px-3 py-2 rounded-xl bg-rose-500/15 border border-rose-500/40 text-xs text-rose-200"
            >
              {errorMessage}
            </div>
          )}

          {successMessage && (
            <div
              role="status"
              className="px-3 py-2 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-xs text-emerald-200"
            >
              {successMessage}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-slate-950 text-sm font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            {mode === 'reset' && <KeyRound size={15} />}
            <span>
              {submitting
                ? 'İşleniyor...'
                : mode === 'login'
                  ? 'Giriş Yap'
                  : mode === 'register'
                    ? 'Hesap Oluştur'
                    : 'Sıfırlama Bağlantısı Gönder'}
            </span>
          </button>
        </form>
      </div>
    </div>
  );
};
