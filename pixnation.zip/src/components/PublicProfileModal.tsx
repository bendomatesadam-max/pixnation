import React, { useCallback, useEffect, useState } from 'react';
import {
  Ban,
  CheckCircle2,
  Clock,
  Crown,
  MapPin,
  Shield,
  ShieldAlert,
  VolumeX,
  X,
} from 'lucide-react';
import {
  firebaseAuthProfiles,
  firebaseModeration,
  firebasePixels,
  translateFirebaseError,
} from '../services/storage';
import {
  BanDurationKey,
  ModerationType,
  MuteDurationKey,
  PlacedPixelRecord,
  PublicPlayerProfile,
  UserModerationState,
  UserRole,
} from '../types/game';
import {
  BAN_DURATION_OPTIONS,
  canViewerModerateTarget,
  formatRemainingDuration,
  getActiveBan,
  getActiveMute,
  MUTE_DURATION_OPTIONS,
} from '../utils/moderation';
import { PlayerAvatar } from './PlayerAvatar';

interface PublicProfileModalProps {
  isOpen: boolean;
  targetUserId: string | null;
  fallbackUsername?: string;
  currentUserId: string | null;
  currentUserRole: UserRole;
  serverTimeOffsetMs: number;
  onClose: () => void;
  onJumpToCoordinate: (x: number, y: number) => void;
}

const ROLE_LABELS: Record<UserRole, { label: string; style: string }> = {
  owner: { label: 'Owner', style: 'bg-amber-400/20 text-amber-300 border-amber-400/40' },
  admin: { label: 'Admin', style: 'bg-rose-500/20 text-rose-300 border-rose-500/40' },
  moderator: { label: 'Moderatör', style: 'bg-sky-500/20 text-sky-300 border-sky-500/40' },
  player: { label: 'Oyuncu', style: 'bg-slate-800 text-slate-300 border-slate-700' },
};

export const PublicProfileModal: React.FC<PublicProfileModalProps> = ({
  isOpen,
  targetUserId,
  fallbackUsername,
  currentUserId,
  currentUserRole,
  serverTimeOffsetMs,
  onClose,
  onJumpToCoordinate,
}) => {
  const [publicProfile, setPublicProfile] = useState<PublicPlayerProfile | null>(null);
  const [placements, setPlacements] = useState<PlacedPixelRecord[]>([]);
  const [moderationState, setModerationState] = useState<UserModerationState | null>(null);
  const [loading, setLoading] = useState(false);

  const [activeForm, setActiveForm] = useState<ModerationType | null>(null);
  const [muteDuration, setMuteDuration] = useState<MuteDurationKey>('5m');
  const [banDuration, setBanDuration] = useState<BanDurationKey>('1h');
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [nowTickMs, setNowTickMs] = useState<number>(() => Date.now() + serverTimeOffsetMs);

  const isAdminOrOwner = currentUserRole === 'owner' || currentUserRole === 'admin';

  const loadData = useCallback(
    async (uid: string) => {
      setLoading(true);
      try {
        const [prof, px, mod] = await Promise.all([
          firebaseAuthProfiles.getPublicProfile(uid).catch(() => null),
          firebasePixels.getPixelsByAuthor(uid, 8).catch(() => []),
          isAdminOrOwner
            ? firebaseModeration.getUserModeration(uid).catch(() => null)
            : Promise.resolve(null),
        ]);
        setPublicProfile(prof);
        setPlacements(px);
        setModerationState(mod);
      } finally {
        setLoading(false);
      }
    },
    [isAdminOrOwner]
  );

  useEffect(() => {
    if (!isOpen || !targetUserId) {
      setPublicProfile(null);
      setPlacements([]);
      setModerationState(null);
      setActiveForm(null);
      setReason('');
      setActionError(null);
      setActionSuccess(null);
      return;
    }
    setActiveForm(null);
    setReason('');
    setActionError(null);
    setActionSuccess(null);
    setNowTickMs(Date.now() + serverTimeOffsetMs);
    void loadData(targetUserId);
  }, [isOpen, targetUserId, loadData, serverTimeOffsetMs]);

  useEffect(() => {
    if (!isOpen || !moderationState) return;
    const interval = window.setInterval(() => {
      setNowTickMs(Date.now() + serverTimeOffsetMs);
    }, 1000);
    return () => window.clearInterval(interval);
  }, [isOpen, moderationState, serverTimeOffsetMs]);

  if (!isOpen || !targetUserId) return null;

  const displayName = publicProfile?.username || fallbackUsername || 'Oyuncu';
  const targetRole: UserRole = publicProfile?.role ?? 'player';
  const roleInfo = ROLE_LABELS[targetRole];
  const modPermission = canViewerModerateTarget(
    currentUserRole,
    currentUserId,
    targetRole,
    targetUserId
  );
  const activeMute = getActiveMute(moderationState, nowTickMs);
  const activeBan = getActiveBan(moderationState, nowTickMs);

  const handleApplyPenalty = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeForm || submitting) return;

    const trimmedReason = reason.trim();
    if (!trimmedReason) {
      setActionError('Ceza nedeni girilmesi zorunludur.');
      return;
    }

    setSubmitting(true);
    setActionError(null);
    setActionSuccess(null);
    try {
      await firebaseModeration.applyModeration({
        targetUid: targetUserId,
        targetUsername: displayName,
        type: activeForm,
        durationKey: activeForm === 'mute' ? muteDuration : banDuration,
        reason: trimmedReason,
        serverTimeOffsetMs,
      });
      setActionSuccess(
        activeForm === 'mute'
          ? `${displayName} sohbetten susturuldu.`
          : `${displayName} oyundan yasaklandı.`
      );
      setReason('');
      setActiveForm(null);
      await loadData(targetUserId);
    } catch (err) {
      setActionError(translateFirebaseError(err));
    } finally {
      setSubmitting(false);
    }
  };

  const handleRevokePenalty = async (type: ModerationType) => {
    if (submitting) return;
    setSubmitting(true);
    setActionError(null);
    setActionSuccess(null);
    try {
      await firebaseModeration.revokeModeration({
        targetUid: targetUserId,
        type,
      });
      setActionSuccess(
        type === 'mute' ? 'Susturma cezası kaldırıldı.' : 'Yasaklama cezası kaldırıldı.'
      );
      await loadData(targetUserId);
    } catch (err) {
      setActionError(translateFirebaseError(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="public-profile-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md max-h-[90dvh] overflow-y-auto touch-pan-y rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl text-slate-100 p-5 sm:p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3.5 min-w-0">
            <PlayerAvatar
              emblem={publicProfile?.emblem ?? 'compass'}
              accentColor={publicProfile?.accentColor ?? '#F59E0B'}
              size="lg"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2
                  id="public-profile-title"
                  className="font-display text-xl font-bold text-white truncate"
                >
                  {displayName}
                </h2>
                <span
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md border text-[11px] font-semibold ${roleInfo.style}`}
                >
                  {targetRole === 'owner' && <Crown size={11} />}
                  {targetRole === 'admin' && <ShieldAlert size={11} />}
                  {targetRole === 'moderator' && <Shield size={11} />}
                  {roleInfo.label}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {publicProfile?.countryCode ?? 'TR'} ·{' '}
                <span className="font-mono-tabular text-slate-300">
                  {publicProfile?.totalPixelsPlaced ?? placements.length} piksel
                </span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Oyuncu profilini kapat"
            className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
          >
            <X size={18} />
          </button>
        </div>

        {loading ? (
          <p className="text-xs text-slate-400 py-4 text-center">Oyuncu profili yükleniyor...</p>
        ) : (
          <>
            {publicProfile?.bio ? (
              <p className="text-sm text-slate-300 bg-slate-950/75 border border-slate-800 rounded-xl px-3.5 py-2.5">
                {publicProfile.bio}
              </p>
            ) : (
              <p className="text-xs text-slate-500">
                Bu oyuncu henüz herkese açık bir profil notu eklememiş.
              </p>
            )}

            {/* Owner & Admin Moderation Section */}
            {isAdminOrOwner && (
              <div className="pt-3 border-t border-slate-800 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                    Moderasyon İşlemleri
                  </h3>
                  {modPermission.allowed && (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setActionError(null);
                          setActionSuccess(null);
                          setActiveForm((prev) => (prev === 'mute' ? null : 'mute'));
                        }}
                        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                          activeForm === 'mute'
                            ? 'bg-amber-400 text-slate-950 border-amber-300'
                            : 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-200 border-amber-400/35'
                        }`}
                      >
                        <VolumeX size={13} />
                        <span>Sustur</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setActionError(null);
                          setActionSuccess(null);
                          setActiveForm((prev) => (prev === 'ban' ? null : 'ban'));
                        }}
                        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                          activeForm === 'ban'
                            ? 'bg-rose-500 text-white border-rose-400'
                            : 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-200 border-rose-400/35'
                        }`}
                      >
                        <Ban size={13} />
                        <span>Yasakla</span>
                      </button>
                    </div>
                  )}
                </div>

                {!modPermission.allowed && modPermission.reason && (
                  <p className="text-xs text-slate-400 bg-slate-950/70 border border-slate-800 rounded-xl px-3 py-2">
                    {modPermission.reason}
                  </p>
                )}

                {actionError && (
                  <p className="text-xs text-rose-200 bg-rose-500/15 border border-rose-500/40 rounded-xl px-3 py-2">
                    {actionError}
                  </p>
                )}
                {actionSuccess && (
                  <p className="text-xs text-emerald-200 bg-emerald-500/15 border border-emerald-500/40 rounded-xl px-3 py-2 flex items-center gap-1.5">
                    <CheckCircle2 size={14} className="shrink-0" />
                    <span>{actionSuccess}</span>
                  </p>
                )}

                {/* Active Penalties Status */}
                {(activeMute || activeBan) && (
                  <div className="space-y-2">
                    {activeMute && (
                      <div className="rounded-xl bg-amber-500/10 border border-amber-400/35 p-3 space-y-1.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-200">
                            <VolumeX size={13} />
                            Aktif Susturma
                          </span>
                          <span className="inline-flex items-center gap-1 text-[11px] font-mono-tabular text-amber-300">
                            <Clock size={11} />
                            {activeMute.permanent
                              ? 'Kalıcı'
                              : activeMute.remainingMs !== null
                                ? formatRemainingDuration(activeMute.remainingMs)
                                : ''}
                          </span>
                        </div>
                        <p className="text-xs text-slate-200">Neden: {activeMute.reason}</p>
                        {modPermission.allowed && (
                          <button
                            type="button"
                            disabled={submitting}
                            onClick={() => void handleRevokePenalty('mute')}
                            className="mt-1 px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[11px] font-semibold text-slate-200 transition-colors cursor-pointer disabled:opacity-50"
                          >
                            Susturmayı Kaldır
                          </button>
                        )}
                      </div>
                    )}

                    {activeBan && (
                      <div className="rounded-xl bg-rose-500/10 border border-rose-400/35 p-3 space-y-1.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-rose-200">
                            <Ban size={13} />
                            Aktif Yasaklama (Ban)
                          </span>
                          <span className="inline-flex items-center gap-1 text-[11px] font-mono-tabular text-rose-300">
                            <Clock size={11} />
                            {activeBan.permanent
                              ? 'Kalıcı'
                              : activeBan.remainingMs !== null
                                ? formatRemainingDuration(activeBan.remainingMs)
                                : ''}
                          </span>
                        </div>
                        <p className="text-xs text-slate-200">Neden: {activeBan.reason}</p>
                        {modPermission.allowed && (
                          <button
                            type="button"
                            disabled={submitting}
                            onClick={() => void handleRevokePenalty('ban')}
                            className="mt-1 px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[11px] font-semibold text-slate-200 transition-colors cursor-pointer disabled:opacity-50"
                          >
                            Banı Kaldır
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Apply Mute / Ban Form */}
                {activeForm && modPermission.allowed && (
                  <form
                    onSubmit={handleApplyPenalty}
                    className="rounded-xl bg-slate-950/85 border border-slate-800 p-3.5 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-200">
                        {activeForm === 'mute' ? 'Sohbetten Sustur (Mute)' : 'Oyundan Yasakla (Ban)'}
                      </span>
                      <button
                        type="button"
                        onClick={() => setActiveForm(null)}
                        className="text-[11px] text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        İptal
                      </button>
                    </div>

                    <div className="space-y-1.5">
                      <span className="block text-[11px] font-medium text-slate-400">
                        Ceza Süresi
                      </span>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                        {(activeForm === 'mute'
                          ? MUTE_DURATION_OPTIONS
                          : BAN_DURATION_OPTIONS
                        ).map((opt) => {
                          const selected =
                            activeForm === 'mute'
                              ? muteDuration === opt.key
                              : banDuration === opt.key;
                          return (
                            <button
                              key={opt.key}
                              type="button"
                              onClick={() => {
                                if (activeForm === 'mute') {
                                  setMuteDuration(opt.key as MuteDurationKey);
                                } else {
                                  setBanDuration(opt.key as BanDurationKey);
                                }
                              }}
                              className={`px-2 py-1.5 rounded-lg border text-[11px] font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                                selected
                                  ? activeForm === 'mute'
                                    ? 'bg-amber-400 text-slate-950 border-amber-300'
                                    : 'bg-rose-500 text-white border-rose-400'
                                  : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-slate-500'
                              }`}
                            >
                              {opt.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label
                        htmlFor="moderation-reason-input"
                        className="block text-[11px] font-medium text-slate-400"
                      >
                        Ceza Nedeni (Zorunlu)
                      </label>
                      <input
                        id="moderation-reason-input"
                        type="text"
                        value={reason}
                        maxLength={200}
                        required
                        placeholder="Örn: Sohbette spam / kural ihlali..."
                        onChange={(e) => {
                          setReason(e.target.value);
                          if (actionError) setActionError(null);
                        }}
                        className="w-full h-9 px-3 rounded-lg bg-slate-900 border border-slate-700 focus:border-amber-400 focus:outline-none text-xs text-slate-100 placeholder:text-slate-500"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={submitting || !reason.trim()}
                      className={`w-full py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                        activeForm === 'mute'
                          ? 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                          : 'bg-rose-500 hover:bg-rose-400 text-white'
                      }`}
                    >
                      {submitting
                        ? 'Uygulanıyor...'
                        : activeForm === 'mute'
                          ? 'Susturmayı Uygula'
                          : 'Yasaklamayı Uygula'}
                    </button>
                  </form>
                )}
              </div>
            )}

            <div className="pt-3 border-t border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Son Yerleştirdiği Pikseller
                </h3>
                <span className="text-xs text-slate-500 font-mono-tabular">
                  {placements.length} kayıt
                </span>
              </div>

              {placements.length === 0 ? (
                <p className="text-xs text-slate-400">Haritada henüz kayıtlı piksel görünmüyor.</p>
              ) : (
                <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto pr-1">
                  {placements.map((item) => (
                    <button
                      key={`${item.x}:${item.y}:${item.placedAt}`}
                      type="button"
                      onClick={() => {
                        onJumpToCoordinate(item.x, item.y);
                        onClose();
                      }}
                      className="flex items-center justify-between gap-2 px-2.5 py-2 rounded-xl bg-slate-950/90 border border-slate-800 hover:border-slate-600 text-left transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className="w-3.5 h-3.5 rounded border border-white/20 shrink-0"
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="font-mono-tabular text-xs text-slate-200 truncate">
                          {item.x}, {item.y}
                        </span>
                      </div>
                      <MapPin size={12} className="text-amber-400 shrink-0" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
