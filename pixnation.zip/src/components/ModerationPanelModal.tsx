import React, { useCallback, useEffect, useState } from 'react';
import {
  Ban,
  CheckCircle2,
  Clock,
  FileText,
  RefreshCw,
  ShieldAlert,
  VolumeX,
  X,
} from 'lucide-react';
import { firebaseModeration, translateFirebaseError } from '../services/storage';
import {
  ModerationAction,
  ModerationLogEntry,
  ModerationType,
  UserModerationState,
  UserRole,
} from '../types/game';
import {
  canViewerModerateTarget,
  DURATION_LABELS,
  formatRemainingDuration,
  getActiveBan,
  getActiveMute,
} from '../utils/moderation';

interface ModerationPanelModalProps {
  isOpen: boolean;
  currentUserId: string;
  currentUserRole: UserRole;
  serverTimeOffsetMs: number;
  onClose: () => void;
}

const ACTION_BADGES: Record<ModerationAction, { label: string; style: string }> = {
  mute: { label: 'Susturma', style: 'bg-amber-500/15 text-amber-300 border-amber-400/35' },
  ban: { label: 'Yasaklama', style: 'bg-rose-500/15 text-rose-300 border-rose-400/35' },
  unmute: { label: 'Susturma Kaldırıldı', style: 'bg-emerald-500/15 text-emerald-300 border-emerald-400/35' },
  unban: { label: 'Ban Kaldırıldı', style: 'bg-sky-500/15 text-sky-300 border-sky-400/35' },
};

function formatTimestampTr(ms: number): string {
  try {
    return new Date(ms).toLocaleString('tr-TR', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return '';
  }
}

export const ModerationPanelModal: React.FC<ModerationPanelModalProps> = ({
  isOpen,
  currentUserId,
  currentUserRole,
  serverTimeOffsetMs,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'active' | 'logs'>('active');
  const [penalties, setPenalties] = useState<UserModerationState[]>([]);
  const [logs, setLogs] = useState<ModerationLogEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [nowTickMs, setNowTickMs] = useState<number>(() => Date.now() + serverTimeOffsetMs);

  const loadOverview = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await firebaseModeration.listModerationOverview(serverTimeOffsetMs);
      setPenalties(result.activePenalties);
      setLogs(result.logs);
    } catch (err) {
      setError(translateFirebaseError(err));
    } finally {
      setLoading(false);
    }
  }, [serverTimeOffsetMs]);

  useEffect(() => {
    if (!isOpen) return;
    setFeedback(null);
    setNowTickMs(Date.now() + serverTimeOffsetMs);
    void loadOverview();
  }, [isOpen, loadOverview, serverTimeOffsetMs]);

  useEffect(() => {
    if (!isOpen) return;
    const interval = window.setInterval(() => {
      setNowTickMs(Date.now() + serverTimeOffsetMs);
    }, 1000);
    return () => window.clearInterval(interval);
  }, [isOpen, serverTimeOffsetMs]);

  if (!isOpen) return null;

  const handleRevoke = async (targetUid: string, targetUsername: string, type: ModerationType) => {
    const key = `${targetUid}:${type}`;
    setBusyKey(key);
    setError(null);
    setFeedback(null);
    try {
      await firebaseModeration.revokeModeration({ targetUid, type });
      setFeedback(
        type === 'mute'
          ? `${targetUsername} kullanıcısının susturma cezası kaldırıldı.`
          : `${targetUsername} kullanıcısının yasaklaması kaldırıldı.`
      );
      await loadOverview();
    } catch (err) {
      setError(translateFirebaseError(err));
    } finally {
      setBusyKey(null);
    }
  };

  const livePenalties = penalties.filter((p) => {
    const hasMute = Boolean(getActiveMute(p, nowTickMs));
    const hasBan = Boolean(getActiveBan(p, nowTickMs));
    return hasMute || hasBan;
  });

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="moderation-panel-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[88dvh] flex flex-col rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl text-slate-100 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-rose-500/15 border border-rose-400/35 flex items-center justify-center text-rose-300 shrink-0">
              <ShieldAlert size={18} />
            </div>
            <div className="min-w-0">
              <h2 id="moderation-panel-title" className="font-display text-lg font-bold text-white">
                Moderasyon Merkezi
              </h2>
              <p className="text-xs text-slate-400 truncate">
                {currentUserRole === 'owner'
                  ? 'Owner Yetkisi: Oyuncu ve Moderatör cezalarını yönetebilirsiniz (Adminler hariç)'
                  : 'Admin Yetkisi: Normal oyunculara susturma/ban uygulayıp kaldırabilirsiniz'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => void loadOverview()}
              disabled={loading}
              aria-label="Moderasyon listesini yenile"
              className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer disabled:opacity-50"
            >
              <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Moderasyon panelini kapat"
              className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 px-5 pt-3 border-b border-slate-800 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('active')}
            className={`px-3.5 py-2 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'active'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Aktif Cezalar ({livePenalties.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('logs')}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'logs'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText size={13} />
            <span>Ceza Geçmişi ({logs.length})</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto touch-pan-y p-5 space-y-3">
          {error && (
            <div className="px-3.5 py-2.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-xs text-rose-200">
              {error}
            </div>
          )}

          {feedback && (
            <div className="px-3.5 py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-xs text-emerald-200 flex items-center gap-2">
              <CheckCircle2 size={15} className="shrink-0" />
              <span>{feedback}</span>
            </div>
          )}

          {loading ? (
            <p className="text-sm text-slate-400 py-8 text-center">Kayıtlar yükleniyor...</p>
          ) : activeTab === 'active' ? (
            livePenalties.length === 0 ? (
              <p className="text-sm text-slate-400 py-8 text-center">
                Şu anda aktif susturma veya yasaklama cezası bulunmuyor.
              </p>
            ) : (
              <div className="space-y-2.5">
                {livePenalties.map((entry) => {
                  const activeMute = getActiveMute(entry, nowTickMs);
                  const activeBan = getActiveBan(entry, nowTickMs);
                  const perm = canViewerModerateTarget(
                    currentUserRole,
                    currentUserId,
                    entry.targetRole,
                    entry.userId
                  );

                  return (
                    <div
                      key={entry.userId}
                      className="rounded-xl bg-slate-950/85 border border-slate-800 p-3.5 space-y-2.5"
                    >
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-sm font-bold text-white truncate">
                            {entry.targetUsername}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-[11px] font-semibold text-slate-300">
                            {entry.targetRole}
                          </span>
                        </div>
                        <span className="font-mono-tabular text-[11px] text-slate-500">
                          UID: {entry.userId.slice(0, 10)}...
                        </span>
                      </div>

                      {activeMute && (
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 rounded-lg bg-amber-500/10 border border-amber-400/30 px-3 py-2">
                          <div className="space-y-0.5 min-w-0">
                            <div className="flex items-center gap-2 text-xs font-semibold text-amber-200 flex-wrap">
                              <VolumeX size={13} />
                              <span>Susturma</span>
                              <span className="text-slate-500">·</span>
                              <span className="inline-flex items-center gap-1 font-mono-tabular">
                                <Clock size={11} />
                                {activeMute.permanent
                                  ? 'Kalıcı'
                                  : activeMute.remainingMs !== null
                                    ? formatRemainingDuration(activeMute.remainingMs)
                                    : ''}
                              </span>
                            </div>
                            <p className="text-xs text-slate-200 break-words">
                              Neden: {activeMute.reason}
                            </p>
                            <p className="text-[11px] text-slate-400">
                              Veren: {activeMute.actorUsername}
                            </p>
                          </div>

                          {perm.allowed && (
                            <button
                              type="button"
                              disabled={busyKey === `${entry.userId}:mute`}
                              onClick={() =>
                                void handleRevoke(entry.userId, entry.targetUsername, 'mute')
                              }
                              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-100 transition-colors cursor-pointer disabled:opacity-50 shrink-0 whitespace-nowrap"
                            >
                              {busyKey === `${entry.userId}:mute`
                                ? 'Kaldırılıyor...'
                                : 'Susturmayı Kaldır'}
                            </button>
                          )}
                        </div>
                      )}

                      {activeBan && (
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 rounded-lg bg-rose-500/10 border border-rose-400/30 px-3 py-2">
                          <div className="space-y-0.5 min-w-0">
                            <div className="flex items-center gap-2 text-xs font-semibold text-rose-200 flex-wrap">
                              <Ban size={13} />
                              <span>Yasaklama (Ban)</span>
                              <span className="text-slate-500">·</span>
                              <span className="inline-flex items-center gap-1 font-mono-tabular">
                                <Clock size={11} />
                                {activeBan.permanent
                                  ? 'Kalıcı'
                                  : activeBan.remainingMs !== null
                                    ? formatRemainingDuration(activeBan.remainingMs)
                                    : ''}
                              </span>
                            </div>
                            <p className="text-xs text-slate-200 break-words">
                              Neden: {activeBan.reason}
                            </p>
                            <p className="text-[11px] text-slate-400">
                              Veren: {activeBan.actorUsername}
                            </p>
                          </div>

                          {perm.allowed && (
                            <button
                              type="button"
                              disabled={busyKey === `${entry.userId}:ban`}
                              onClick={() =>
                                void handleRevoke(entry.userId, entry.targetUsername, 'ban')
                              }
                              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-100 transition-colors cursor-pointer disabled:opacity-50 shrink-0 whitespace-nowrap"
                            >
                              {busyKey === `${entry.userId}:ban`
                                ? 'Kaldırılıyor...'
                                : 'Banı Kaldır'}
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )
          ) : logs.length === 0 ? (
            <p className="text-sm text-slate-400 py-8 text-center">
              Henüz kaydedilmiş bir ceza işlemi bulunmuyor.
            </p>
          ) : (
            <div className="space-y-2">
              {logs.map((log) => {
                const badge = ACTION_BADGES[log.action];
                return (
                  <div
                    key={log.id}
                    className="rounded-xl bg-slate-950/85 border border-slate-800 px-3.5 py-2.5 space-y-1"
                  >
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2 flex-wrap text-xs">
                        <span
                          className={`px-2 py-0.5 rounded-md border text-[11px] font-semibold ${badge.style}`}
                        >
                          {badge.label}
                        </span>
                        <span className="font-semibold text-white">{log.targetUsername}</span>
                        <span className="text-slate-500">·</span>
                        <span className="text-slate-400">
                          Yetkili: <strong className="text-slate-200">{log.actorUsername}</strong> (
                          {log.actorRole})
                        </span>
                      </div>
                      <span className="font-mono-tabular text-[11px] text-slate-500 whitespace-nowrap">
                        {formatTimestampTr(log.createdAtMs)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-3 text-xs text-slate-300 flex-wrap">
                      <p className="break-words">Neden: {log.reason}</p>
                      <span className="font-mono-tabular text-[11px] text-slate-400 whitespace-nowrap">
                        Süre: {DURATION_LABELS[log.durationKey] ?? log.durationKey}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
