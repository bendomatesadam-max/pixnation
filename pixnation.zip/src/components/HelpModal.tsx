import React from 'react';
import { Compass, MousePointerClick, Move, Pipette, X, ZoomIn } from 'lucide-react';
import { REGION_PRESETS } from '../constants/palette';
import { RegionPreset } from '../types/game';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRegion: (region: RegionPreset) => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({
  isOpen,
  onClose,
  onSelectRegion,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="help-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md max-h-[90dvh] overflow-y-auto touch-pan-y rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl text-slate-100 p-5 sm:p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 id="help-modal-title" className="font-display text-xl font-bold text-white">
            PixNation Kontrolleri
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Yardımı kapat"
            className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <ul className="space-y-3 text-sm text-slate-300">
          <li className="flex items-start gap-3">
            <MousePointerClick size={18} className="text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">Piksel Yerleştir:</span> Sağdaki paletten bir
              renk seçin ve haritada istediğiniz noktaya tıklayın veya dokunun.
            </div>
          </li>
          <li className="flex items-start gap-3">
            <Move size={18} className="text-sky-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">Haritayı Kaydır:</span> Fare ile sürükleyin
              veya tek parmakla kaydırın.
            </div>
          </li>
          <li className="flex items-start gap-3">
            <ZoomIn size={18} className="text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">Yakınlaştır / Uzaklaştır:</span> Fare
              tekerleğini kullanın, iki parmakla kıstırın veya alttaki + / − düğmelerine basın.
            </div>
          </li>
          <li className="flex items-start gap-3">
            <Pipette size={18} className="text-violet-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">Renk Seçici:</span> Haritadaki herhangi bir
              rengi kopyalamak için sağ tıklayın veya paletten Seç (I) aracını kullanın.
            </div>
          </li>
        </ul>

        {/* Quick Region Jump (especially handy on mobile) */}
        <div className="pt-4 border-t border-slate-800 space-y-2.5">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <Compass size={14} className="text-amber-400" />
            <span>Hızlı Bölge Atlama</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {REGION_PRESETS.map((region) => (
              <button
                key={region.id}
                type="button"
                onClick={() => {
                  onSelectRegion(region);
                  onClose();
                }}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-400/60 text-xs font-medium text-slate-200 hover:text-white text-left transition-colors cursor-pointer truncate"
              >
                {region.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
