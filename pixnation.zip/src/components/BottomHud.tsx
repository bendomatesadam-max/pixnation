import React from 'react';
import { CheckCircle2, Clock, LogIn, Maximize2, Minus, Plus, User } from 'lucide-react';
import { COOLDOWN_FIRST_PHASE_MS } from '../constants/palette';
import { PixelPoint, PlacedPixelRecord, PlayerProfile } from '../types/game';
import { getTerrainLabel } from '../utils/worldMapGenerator';

interface BottomHudProps {
  hoveredPoint: PixelPoint | null;
  hoveredRecord: PlacedPixelRecord | null;
  inspectedRecord: PlacedPixelRecord | null;
  zoom: number;
  cooldownRemainingMs: number;
  cooldownDurationMs: number;
  activePhaseCooldownMs: number;
  profile: PlayerProfile | null;
  totalWorldPixels: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onResetCamera: () => void;
  onOpenProfile: () => void;
  onOpenAuth: () => void;
  onInspectPlayer: (userId: string, username: string) => void;
}

export const BottomHud: React.FC<BottomHudProps> = ({
  hoveredPoint,
  hoveredRecord,
  inspectedRecord,
  zoom,
  cooldownRemainingMs,
  cooldownDurationMs,
  activePhaseCooldownMs,
  profile,
  totalWorldPixels,
  onZoomIn,
  onZoomOut,
  onResetCamera,
  onOpenProfile,
  onOpenAuth,
  onInspectPlayer,
}) => {
  const effectiveDurationMs = cooldownDurationMs > 0 ? cooldownDurationMs : COOLDOWN_FIRST_PHASE_MS;
  const isReady = cooldownRemainingMs <= 0;
  const secondsText = (cooldownRemainingMs / 1000).toFixed(1);
  const activePhaseLabel =
    activePhaseCooldownMs >= 1000
      ? `${(activePhaseCooldownMs / 1000).toFixed(activePhaseCooldownMs % 1000 === 0 ? 0 : 1)}s`
      : `${activePhaseCooldownMs}ms`;
  const progressPct = isReady
    ? 100
    : Math.max(
        0,
        Math.min(100, ((effectiveDurationMs - cooldownRemainingMs) / effectiveDurationMs) * 100)
      );

  const terrainLabel = hoveredPoint ? getTerrainLabel(hoveredPoint.x, hoveredPoint.y) : null;
  const activeRecord = hoveredRecord ?? (!hoveredPoint ? inspectedRecord : null);

  return (
    <footer className="fixed bottom-3 left-3 right-3 sm:bottom-4 sm:left-1/2 sm:-translate-x-1/2 sm:right-auto z-20 flex items-center justify-between sm:justify-center gap-2 sm:gap-4 px-3 py-2 rounded-2xl bg-slate-950/92 border border-slate-700/75 shadow-2xl backdrop-blur-md sm:w-auto max-w-full">
      {/* Coordinates & Terrain/Author */}
      <div className="flex items-center gap-2 min-w-0">
        <div className="flex flex-col">
          <span className="font-mono-tabular text-xs sm:text-sm font-semibold text-slate-100 whitespace-nowrap">
            {hoveredPoint ? `X: ${hoveredPoint.x} · Y: ${hoveredPoint.y}` : 'X: — · Y: —'}
          </span>
          {activeRecord ? (
            <button
              type="button"
              onClick={() => onInspectPlayer(activeRecord.authorId, activeRecord.authorUsername)}
              title="Oyuncunun herkese açık profilini görüntüle"
              className="text-left text-[11px] text-amber-300 hover:text-amber-200 underline decoration-amber-400/50 underline-offset-2 truncate max-w-[125px] sm:max-w-[180px] whitespace-nowrap cursor-pointer"
            >
              {activeRecord.authorUsername}
            </button>
          ) : (
            <span className="text-[11px] text-slate-400 truncate max-w-[125px] sm:max-w-[180px] whitespace-nowrap">
              {terrainLabel ?? `${totalWorldPixels} boyalı piksel`}
            </span>
          )}
        </div>
      </div>

      <div className="h-7 w-px bg-slate-800 shrink-0" />

      {/* Cooldown Indicator */}
      <div
        className="flex flex-col gap-1 min-w-[96px] sm:min-w-[124px]"
        aria-live="polite"
        aria-label={isReady ? `Piksel yerleştirme hazır (${activePhaseLabel} döngüsü)` : `Bekleme süresi ${secondsText} saniye`}
        title={`Global Sunucu Döngüsü: ${activePhaseLabel} bekleme`}
      >
        <div className="flex items-center justify-between gap-1.5 text-xs font-medium whitespace-nowrap">
          {isReady ? (
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-emerald-400 shrink-0" aria-hidden="true" />
              <span className="text-emerald-300">Hazır</span>
            </span>
          ) : (
            <span className="flex items-center gap-1.5">
              <Clock size={14} className="text-amber-400 shrink-0" aria-hidden="true" />
              <span className="font-mono-tabular text-amber-300">{secondsText}s</span>
            </span>
          )}
          <span className="font-mono-tabular text-[10px] text-slate-400">
            {activePhaseLabel}
          </span>
        </div>
        <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
          <div
            className={`h-full transition-colors duration-150 ${
              isReady ? 'bg-emerald-400' : 'bg-amber-400'
            }`}
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>

      <div className="h-7 w-px bg-slate-800 shrink-0 hidden md:block" />

      {/* Player Quick Info (Desktop) */}
      {profile ? (
        <button
          type="button"
          onClick={onOpenProfile}
          className="hidden md:flex items-center gap-2 px-2 py-1 rounded-xl hover:bg-slate-800/80 transition-colors text-left cursor-pointer shrink-0"
          title="Oyuncu profilini aç"
        >
          <User size={14} className="text-slate-400 shrink-0" aria-hidden="true" />
          <div className="flex items-center gap-1.5 text-xs text-slate-300 whitespace-nowrap">
            <span className="font-semibold text-slate-100 max-w-[110px] truncate">
              {profile.username}
            </span>
            <span className="text-slate-500" aria-hidden="true">·</span>
            <span className="font-mono-tabular text-slate-400">{profile.totalPixelsPlaced}</span>
          </div>
        </button>
      ) : (
        <button
          type="button"
          onClick={onOpenAuth}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-xs font-medium text-amber-300 transition-colors cursor-pointer shrink-0 whitespace-nowrap"
        >
          <LogIn size={13} />
          <span>Giriş Yap</span>
        </button>
      )}

      <div className="h-7 w-px bg-slate-800 shrink-0" />

      {/* Zoom Controls */}
      <div className="flex items-center gap-1 shrink-0">
        <button
          type="button"
          onClick={onZoomOut}
          aria-label="Uzaklaştır"
          title="Uzaklaştır (-)"
          className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl text-slate-200 hover:bg-slate-800 active:bg-slate-700 transition-colors cursor-pointer"
        >
          <Minus size={16} />
        </button>
        <button
          type="button"
          onClick={onResetCamera}
          aria-label="Haritayı ortala"
          title="Tüm Dünyayı Göster (0)"
          className="px-2 h-9 sm:h-10 flex items-center justify-center gap-1 rounded-xl text-xs font-mono-tabular font-semibold text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap"
        >
          <span className="hidden sm:inline">{zoom.toFixed(1)}×</span>
          <Maximize2 size={14} className="sm:hidden" />
        </button>
        <button
          type="button"
          onClick={onZoomIn}
          aria-label="Yakınlaştır"
          title="Yakınlaştır (+)"
          className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl text-slate-200 hover:bg-slate-800 active:bg-slate-700 transition-colors cursor-pointer"
        >
          <Plus size={16} />
        </button>
      </div>
    </footer>
  );
};
