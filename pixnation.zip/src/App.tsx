import { User } from 'firebase/auth';
import { useCallback, useEffect, useRef, useState } from 'react';
import { AuthModal } from './components/AuthModal';
import { BottomHud } from './components/BottomHud';
import { ChatPanel } from './components/ChatPanel';
import { ColorPalette } from './components/ColorPalette';
import { HelpModal } from './components/HelpModal';
import { ModerationPanelModal } from './components/ModerationPanelModal';
import { OwnerPanelModal } from './components/OwnerPanelModal';
import { ProfileModal } from './components/ProfileModal';
import { PublicProfileModal } from './components/PublicProfileModal';
import { TopBar } from './components/TopBar';
import { WorldCanvas } from './components/WorldCanvas';
import {
  COOLDOWN_FIRST_PHASE_MS,
  getGlobalCooldownDurationMs,
  MAX_ZOOM,
  MIN_ZOOM,
  PIXEL_PALETTE,
  REGION_PRESETS,
} from './constants/palette';
import { testFirestoreConnection } from './firebase';
import {
  firebaseAuthProfiles,
  firebaseChat,
  firebaseModeration,
  firebasePixels,
  PixelMap,
  translateFirebaseError,
} from './services/storage';
import {
  ActiveTool,
  AvatarEmblem,
  CameraState,
  ChatMessage,
  PixelPoint,
  PlacedPixelRecord,
  PlayerProfile,
  RegionPreset,
  UserModerationState,
  UserRole,
} from './types/game';
import { formatRemainingDuration, getActiveBan, getActiveMute } from './utils/moderation';
import { soundFX } from './utils/sound';
import { WORLD_HEIGHT, WORLD_WIDTH } from './utils/worldMapGenerator';

function getInitialCamera(): CameraState {
  if (typeof window !== 'undefined') {
    const fitZoom =
      Math.min(window.innerWidth / WORLD_WIDTH, window.innerHeight / WORLD_HEIGHT) * 0.94;
    return {
      centerX: WORLD_WIDTH / 2,
      centerY: WORLD_HEIGHT * 0.46,
      zoom: Math.max(MIN_ZOOM, Math.min(1.2, fitZoom)),
    };
  }
  return REGION_PRESETS[0];
}

export default function App() {
  const [camera, setCamera] = useState<CameraState>(getInitialCamera);
  const [pixels, setPixels] = useState<PixelMap>(() => new Map());
  const [selectedColor, setSelectedColor] = useState<string>(PIXEL_PALETTE[5].hex);
  const [activeTool, setActiveTool] = useState<ActiveTool>('paint');
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  const [hoveredPoint, setHoveredPoint] = useState<PixelPoint | null>(null);
  const [hoveredRecord, setHoveredRecord] = useState<PlacedPixelRecord | null>(null);
  const [lastInspectedRecord, setLastInspectedRecord] = useState<PlacedPixelRecord | null>(null);

  const [authReady, setAuthReady] = useState<boolean>(false);
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<PlayerProfile | null>(null);
  const [customRole, setCustomRole] = useState<UserRole>('player');
  const [recentPlacements, setRecentPlacements] = useState<PlacedPixelRecord[]>([]);

  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [authDismissed, setAuthDismissed] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isOwnerPanelOpen, setIsOwnerPanelOpen] = useState<boolean>(false);
  const [isModerationPanelOpen, setIsModerationPanelOpen] = useState<boolean>(false);
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatError, setChatError] = useState<string | null>(null);
  const [unreadChatCount, setUnreadChatCount] = useState<number>(0);
  const [ownModeration, setOwnModeration] = useState<UserModerationState | null>(null);
  const [moderationNowMs, setModerationNowMs] = useState<number>(() => Date.now());
  const [inspectedPlayer, setInspectedPlayer] = useState<{ id: string; username: string } | null>(
    null
  );

  const [serverTimeOffsetMs, setServerTimeOffsetMs] = useState<number>(0);
  const [activePhaseCooldownMs, setActivePhaseCooldownMs] = useState<number>(() =>
    getGlobalCooldownDurationMs(Date.now())
  );
  const [cooldownEndAt, setCooldownEndAt] = useState<number>(0);
  const [lastPlacedAtMs, setLastPlacedAtMs] = useState<number>(0);
  const [cooldownDurationMs, setCooldownDurationMs] = useState<number>(COOLDOWN_FIRST_PHASE_MS);
  const [cooldownRemainingMs, setCooldownRemainingMs] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const serverTimeOffsetRef = useRef<number>(0);
  const isChatOpenRef = useRef<boolean>(false);
  const seenChatIdsRef = useRef<Set<string>>(new Set());
  const chatInitializedRef = useRef<boolean>(false);
  const wasCoolingDownRef = useRef<boolean>(false);
  const toastTimerRef = useRef<number | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    if (toastTimerRef.current) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 2600);
  }, []);

  // Validate Firestore connectivity & sync trusted server clock offset once on startup
  useEffect(() => {
    void testFirestoreConnection();
    void firebaseAuthProfiles.fetchServerTimeOffsetMs().then((offset) => {
      serverTimeOffsetRef.current = offset;
      setServerTimeOffsetMs(offset);
      setActivePhaseCooldownMs(getGlobalCooldownDurationMs(Date.now() + offset));
    });
  }, []);

  // Track active 1s / 500ms global cycle using server-synced UTC clock
  useEffect(() => {
    const syncPhase = () => {
      const serverNow = Date.now() + serverTimeOffsetMs;
      const phaseDuration = getGlobalCooldownDurationMs(serverNow);
      setActivePhaseCooldownMs(phaseDuration);
      if (lastPlacedAtMs > 0) {
        setCooldownDurationMs(phaseDuration);
        setCooldownEndAt(lastPlacedAtMs + phaseDuration);
      }
    };
    syncPhase();
    const interval = window.setInterval(syncPhase, 1000);
    return () => window.clearInterval(interval);
  }, [lastPlacedAtMs, serverTimeOffsetMs]);

  // Subscribe to Firebase Authentication, Custom Claims & active player profile
  useEffect(() => {
    const unsubscribe = firebaseAuthProfiles.subscribeAuthAndProfile(
      ({ user, profile: nextProfile, customRole: nextRole, authReady: ready }) => {
        setAuthUser(user);
        setProfile(nextProfile);
        setCustomRole(nextRole);
        if (user) {
          setAuthDismissed(false);
          setIsAuthOpen(false);
        }
        if (nextRole !== 'owner') {
          setIsOwnerPanelOpen(false);
        }
        if (nextRole !== 'owner' && nextRole !== 'admin') {
          setIsModerationPanelOpen(false);
        }
        setAuthReady(ready);
      }
    );
    return () => unsubscribe();
  }, []);

  // Subscribe to own active moderation penalties (real-time Mute / Ban status)
  useEffect(() => {
    if (!authUser?.uid) {
      setOwnModeration(null);
      return;
    }
    const unsubscribe = firebaseModeration.subscribeOwnModeration(
      authUser.uid,
      setOwnModeration
    );
    return () => unsubscribe();
  }, [authUser?.uid]);

  // Live 1s ticker while a mute or ban is present so temporary penalties lift automatically on time
  useEffect(() => {
    setModerationNowMs(Date.now() + serverTimeOffsetMs);
    if (!ownModeration || (!ownModeration.muteActive && !ownModeration.banActive)) {
      return;
    }
    const interval = window.setInterval(() => {
      setModerationNowMs(Date.now() + serverTimeOffsetMs);
    }, 1000);
    return () => window.clearInterval(interval);
  }, [ownModeration, serverTimeOffsetMs]);

  // Subscribe to persistent server-side cooldown document (survives refresh & logout/re-login)
  useEffect(() => {
    if (!authUser?.uid) {
      setLastPlacedAtMs(0);
      setCooldownEndAt(0);
      setCooldownRemainingMs(0);
      return;
    }

    const unsubscribe = firebaseAuthProfiles.subscribeCooldown(
      authUser.uid,
      (state) => {
        if (!state) {
          setLastPlacedAtMs(0);
          setCooldownEndAt(0);
          return;
        }
        setLastPlacedAtMs(state.lastPlacedAtMs);
        setCooldownDurationMs(state.cooldownDurationMs);
        setCooldownEndAt(state.cooldownEndAt);
      },
      () => serverTimeOffsetRef.current
    );

    return () => unsubscribe();
  }, [authUser?.uid]);

  // Real-time Firestore pixel subscription (re-subscribes on auth change)
  useEffect(() => {
    if (!authReady) return;
    let isMounted = true;

    const unsubscribe = firebasePixels.subscribePixels(
      (nextPixels) => {
        if (isMounted) {
          setPixels(nextPixels);
        }
      },
      () => {
        // If Firestore rules restrict read to authenticated users, prompt cleanly
        if (isMounted && !authUser) {
          showToast('Canlı haritayı görmek ve boyamak için giriş yapın.');
        }
      }
    );

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [authReady, authUser?.uid, showToast]);

  // Real-time Firestore Global Chat subscription
  useEffect(() => {
    isChatOpenRef.current = isChatOpen;
    if (isChatOpen) {
      setUnreadChatCount(0);
    }
  }, [isChatOpen]);

  useEffect(() => {
    if (!authReady) return;
    if (!authUser) {
      setChatMessages([]);
      setChatError(null);
      setUnreadChatCount(0);
      seenChatIdsRef.current.clear();
      chatInitializedRef.current = false;
      return;
    }

    let isMounted = true;
    chatInitializedRef.current = false;
    seenChatIdsRef.current.clear();

    const unsubscribe = firebaseChat.subscribeMessages(
      (messages) => {
        if (!isMounted) return;
        setChatError(null);
        setChatMessages(messages);

        if (!chatInitializedRef.current) {
          chatInitializedRef.current = true;
          messages.forEach((m) => seenChatIdsRef.current.add(m.id));
          return;
        }

        let newlyArrived = 0;
        messages.forEach((m) => {
          if (!seenChatIdsRef.current.has(m.id)) {
            seenChatIdsRef.current.add(m.id);
            if (m.authorId !== authUser.uid) {
              newlyArrived += 1;
            }
          }
        });

        if (newlyArrived > 0 && !isChatOpenRef.current) {
          setUnreadChatCount((prev) => prev + newlyArrived);
        }
      },
      (errMessage) => {
        if (isMounted) {
          setChatError(errMessage);
        }
      }
    );

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [authReady, authUser?.uid]);

  // Refresh author's recent placements when profile or pixels change
  useEffect(() => {
    if (!profile) {
      setRecentPlacements([]);
      return;
    }
    void firebasePixels
      .getPixelsByAuthor(profile.id, 12)
      .then(setRecentPlacements)
      .catch(() => {
        // Ignore transient read issues
      });
  }, [profile?.id, pixels]);

  // Smooth server-synced cooldown ticker
  useEffect(() => {
    const serverNow = Date.now() + serverTimeOffsetMs;
    if (cooldownEndAt <= serverNow) {
      setCooldownRemainingMs(0);
      if (wasCoolingDownRef.current) {
        wasCoolingDownRef.current = false;
        soundFX.playCooldownReady();
      }
      return;
    }

    wasCoolingDownRef.current = true;
    const update = () => {
      const serverNow = Date.now() + serverTimeOffsetMs;
      const currentPhaseDuration = getGlobalCooldownDurationMs(serverNow);
      const effectiveEnd = lastPlacedAtMs > 0 ? lastPlacedAtMs + currentPhaseDuration : cooldownEndAt;
      const rem = Math.max(0, effectiveEnd - serverNow);
      setCooldownRemainingMs(rem);
      if (rem === 0 && wasCoolingDownRef.current) {
        wasCoolingDownRef.current = false;
        soundFX.playCooldownReady();
      }
    };

    update();
    const interval = window.setInterval(update, 40);
    return () => window.clearInterval(interval);
  }, [cooldownEndAt, lastPlacedAtMs, serverTimeOffsetMs]);

  const handleToggleSound = useCallback(() => {
    setSoundEnabled((prev) => {
      const next = !prev;
      soundFX.setEnabled(next);
      return next;
    });
  }, []);

  const handleZoomIn = useCallback(() => {
    setCamera((prev) => ({
      ...prev,
      zoom: Math.min(MAX_ZOOM, prev.zoom * 1.4),
    }));
  }, []);

  const handleZoomOut = useCallback(() => {
    setCamera((prev) => ({
      ...prev,
      zoom: Math.max(MIN_ZOOM, prev.zoom / 1.4),
    }));
  }, []);

  const handleResetCamera = useCallback(() => {
    setCamera(getInitialCamera());
  }, []);

  const handleSelectRegion = useCallback((region: RegionPreset) => {
    setCamera({
      centerX: region.centerX,
      centerY: region.centerY,
      zoom: region.zoom,
    });
  }, []);

  const handleJumpToCoordinate = useCallback((x: number, y: number) => {
    setCamera({
      centerX: x + 0.5,
      centerY: y + 0.5,
      zoom: 16,
    });
  }, []);

  const handlePlacePixel = useCallback(
    async (x: number, y: number) => {
      if (!authUser || !profile) {
        soundFX.playCooldownBlocked();
        showToast('Piksel yerleştirmek için giriş yapmalısınız.');
        setIsAuthOpen(true);
        return;
      }

      const serverNow = Date.now() + serverTimeOffsetMs;
      const currentBan = getActiveBan(ownModeration, serverNow);
      if (currentBan) {
        soundFX.playCooldownBlocked();
        const durationLabel = currentBan.permanent
          ? 'Kalıcı'
          : currentBan.remainingMs !== null
            ? `Kalan: ${formatRemainingDuration(currentBan.remainingMs)}`
            : 'Süreli';
        showToast(
          `Yasaklısınız (${durationLabel}) — Neden: ${currentBan.reason}`
        );
        return;
      }

      const phaseDuration = getGlobalCooldownDurationMs(serverNow);
      const effectiveEndAt = lastPlacedAtMs > 0 ? lastPlacedAtMs + phaseDuration : cooldownEndAt;
      if (effectiveEndAt > serverNow) {
        soundFX.playCooldownBlocked();
        const secs = ((effectiveEndAt - serverNow) / 1000).toFixed(1);
        showToast(`Bekleme süresi: ${secs}s`);
        return;
      }

      const existing = pixels.get(`${x}:${y}`);
      if (existing && existing.authorId !== authUser.uid && customRole === 'player') {
        soundFX.playCooldownBlocked();
        showToast(`Bu piksel ${existing.authorUsername} tarafından boyanmış.`);
        return;
      }
      if (existing && existing.color.toLowerCase() === selectedColor.toLowerCase()) {
        showToast('Bu piksel zaten seçili renkte.');
        return;
      }

      const prevLastPlacedAtMs = lastPlacedAtMs;
      const prevCooldownEndAt = cooldownEndAt;
      const prevCooldownDurationMs = cooldownDurationMs;
      setLastPlacedAtMs(serverNow);
      setCooldownDurationMs(phaseDuration);
      setCooldownEndAt(serverNow + phaseDuration);
      soundFX.playPlacePixel();

      try {
        const saved = await firebasePixels.placePixel({
          x,
          y,
          color: selectedColor,
          authorId: profile.id,
          authorUsername: profile.username,
        });
        setPixels((prev) => {
          const next = new Map(prev);
          next.set(`${saved.x}:${saved.y}`, saved);
          return next;
        });
      } catch (err) {
        setLastPlacedAtMs(prevLastPlacedAtMs);
        setCooldownEndAt(prevCooldownEndAt);
        setCooldownDurationMs(prevCooldownDurationMs);
        showToast(translateFirebaseError(err));
      }
    },
    [
      authUser,
      cooldownDurationMs,
      cooldownEndAt,
      customRole,
      lastPlacedAtMs,
      ownModeration,
      pixels,
      profile,
      selectedColor,
      serverTimeOffsetMs,
      showToast,
    ]
  );

  const handleSampleColor = useCallback(
    (hex: string) => {
      setSelectedColor(hex);
      setActiveTool('paint');
      soundFX.playPickColor();
      showToast(`Renk seçildi: ${hex.toUpperCase()}`);
    },
    [showToast]
  );

  const handleSignIn = useCallback(
    async (email: string, password: string) => {
      await firebaseAuthProfiles.signInWithEmail(email, password);
      showToast('Hoş geldiniz!');
    },
    [showToast]
  );

  const handleRegister = useCallback(
    async (email: string, password: string, username: string) => {
      await firebaseAuthProfiles.registerWithEmail(email, password, username);
      showToast('Hesabınız oluşturuldu!');
    },
    [showToast]
  );

  const handleSignOut = useCallback(async () => {
    await firebaseAuthProfiles.signOut();
    setAuthDismissed(false);
    showToast('Oturum kapatıldı.');
  }, [showToast]);

  const handleResetPassword = useCallback(async (email: string) => {
    await firebaseAuthProfiles.sendPasswordReset(email);
  }, []);

  const handleSaveProfile = useCallback(
    async (data: {
      id: string;
      username: string;
      bio: string;
      countryCode: string;
      accentColor: string;
      emblem: AvatarEmblem;
    }) => {
      const updated = await firebaseAuthProfiles.updateProfile(data);
      setProfile(updated);
    },
    []
  );

  const handleRefreshClaims = useCallback(async () => {
    const nextRole = await firebaseAuthProfiles.getCustomRole(true);
    setCustomRole(nextRole);
    showToast(
      nextRole === 'owner'
        ? 'Owner yetkisi doğrulandı!'
        : `Mevcut yetki: ${nextRole}`
    );
  }, [showToast]);

  const handleCheckOwnerBootstrap = useCallback(async () => {
    return firebaseAuthProfiles.getOwnerBootstrapStatus();
  }, []);

  const handleClaimInitialOwner = useCallback(async () => {
    await firebaseAuthProfiles.claimInitialOwner();
    const nextRole = await firebaseAuthProfiles.getCustomRole(true);
    setCustomRole(nextRole);
    showToast(
      nextRole === 'owner'
        ? 'İlk Owner yetkisi hesabınıza tanımlandı!'
        : 'Owner kurulumu işlendi, oturumu yenileyin.'
    );
  }, [showToast]);

  // Keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT')
      ) {
        return;
      }

      if (e.key === 'Escape') {
        setIsProfileOpen(false);
        setIsOwnerPanelOpen(false);
        setIsModerationPanelOpen(false);
        setIsAuthOpen(false);
        setAuthDismissed(true);
        setIsHelpOpen(false);
        setIsChatOpen(false);
        setInspectedPlayer(null);
        setActiveTool('paint');
      } else if (e.key === 'g' || e.key === 'G') {
        setShowGrid((v) => !v);
      } else if (e.key === 'i' || e.key === 'I') {
        setActiveTool((t) => (t === 'eyedropper' ? 'paint' : 'eyedropper'));
      } else if (e.key === '+' || e.key === '=') {
        handleZoomIn();
      } else if (e.key === '-' || e.key === '_') {
        handleZoomOut();
      } else if (e.key === '0') {
        handleResetCamera();
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleResetCamera, handleZoomIn, handleZoomOut]);

  const handleSendChatMessage = useCallback(
    async (text: string) => {
      try {
        await firebaseChat.sendMessage(text, profile?.accentColor);
      } catch (err) {
        throw new Error(translateFirebaseError(err));
      }
    },
    [profile?.accentColor]
  );

  const handleDeleteChatMessage = useCallback(
    async (messageId: string) => {
      try {
        await firebaseChat.deleteMessage(messageId);
      } catch (err) {
        showToast(translateFirebaseError(err));
      }
    },
    [showToast]
  );

  const activeSelfBan = getActiveBan(ownModeration, moderationNowMs);
  const activeSelfMute = getActiveMute(ownModeration, moderationNowMs);

  return (
    <main className="relative w-screen h-dvh overflow-hidden touch-none bg-[#CAE3FF]">
      {/* Full-viewport interactive World Map */}
      <WorldCanvas
        camera={camera}
        onCameraChange={setCamera}
        pixels={pixels}
        selectedColor={selectedColor}
        activeTool={activeTool}
        showGrid={showGrid}
        isCooldownReady={cooldownRemainingMs <= 0 && !activeSelfBan}
        onHoverPixel={(point, record) => {
          setHoveredPoint(point);
          setHoveredRecord(record);
          if (record) {
            setLastInspectedRecord(record);
          }
        }}
        onPlacePixel={handlePlacePixel}
        onSampleColor={handleSampleColor}
      />

      {/* Top HUD */}
      <TopBar
        profile={profile}
        customRole={customRole}
        showGrid={showGrid}
        soundEnabled={soundEnabled}
        onToggleGrid={() => setShowGrid((v) => !v)}
        onToggleSound={handleToggleSound}
        onSelectRegion={handleSelectRegion}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenOwnerPanel={() => setIsOwnerPanelOpen(true)}
        onOpenModerationPanel={() => setIsModerationPanelOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenHelp={() => setIsHelpOpen(true)}
      />

      {/* Active Ban / Mute Notice Banner for Penalized Player */}
      {(activeSelfBan || activeSelfMute) && (
        <div
          role="alert"
          className={`fixed top-18 left-1/2 -translate-x-1/2 z-20 max-w-[calc(100vw-24px)] sm:max-w-lg px-3.5 py-2 rounded-xl border shadow-xl backdrop-blur-md text-xs ${
            activeSelfBan
              ? 'bg-rose-950/92 border-rose-500/50 text-rose-100'
              : 'bg-amber-950/92 border-amber-500/50 text-amber-100'
          }`}
        >
          <p className="font-semibold text-center">
            {activeSelfBan
              ? `Yasaklandınız (Piksel & Sohbet Kısıtlı) · Süre: ${
                  activeSelfBan.permanent
                    ? 'Kalıcı'
                    : activeSelfBan.remainingMs !== null
                      ? formatRemainingDuration(activeSelfBan.remainingMs)
                      : 'Süreli'
                }`
              : `Sohbetten Susturuldunuz · Süre: ${
                  activeSelfMute!.permanent
                    ? 'Kalıcı'
                    : activeSelfMute!.remainingMs !== null
                      ? formatRemainingDuration(activeSelfMute!.remainingMs)
                      : 'Süreli'
                }`}
          </p>
          <p className="text-[11px] opacity-90 text-center truncate">
            Neden: {(activeSelfBan ?? activeSelfMute)!.reason}
          </p>
        </div>
      )}

      {/* Right Vertical Color Palette */}
      <ColorPalette
        selectedColor={selectedColor}
        activeTool={activeTool}
        isChatOpen={isChatOpen}
        onSelectColor={(hex) => {
          setSelectedColor(hex);
          setActiveTool('paint');
        }}
        onToggleEyedropper={() =>
          setActiveTool((t) => (t === 'eyedropper' ? 'paint' : 'eyedropper'))
        }
      />

      {/* Right Collapsible Real-Time Global Chat */}
      <ChatPanel
        isOpen={isChatOpen}
        isAuthenticated={Boolean(authUser)}
        currentUserId={authUser?.uid ?? null}
        currentUserRole={customRole}
        messages={chatMessages}
        unreadCount={unreadChatCount}
        errorMessage={chatError}
        activeBan={activeSelfBan}
        activeMute={activeSelfMute}
        onToggleOpen={setIsChatOpen}
        onSendMessage={handleSendChatMessage}
        onDeleteMessage={handleDeleteChatMessage}
        onOpenAuth={() => setIsAuthOpen(true)}
        onInspectPlayer={(userId, username) => setInspectedPlayer({ id: userId, username })}
      />

      {/* Bottom Coordinates, Cooldown & Player Info HUD */}
      <BottomHud
        hoveredPoint={hoveredPoint}
        hoveredRecord={hoveredRecord}
        inspectedRecord={lastInspectedRecord}
        zoom={camera.zoom}
        cooldownRemainingMs={cooldownRemainingMs}
        cooldownDurationMs={cooldownDurationMs}
        activePhaseCooldownMs={activePhaseCooldownMs}
        profile={profile}
        totalWorldPixels={pixels.size}
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onResetCamera={handleResetCamera}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onInspectPlayer={(userId, username) => setInspectedPlayer({ id: userId, username })}
      />

      {/* Transient non-intrusive feedback toast */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed top-28 left-1/2 -translate-x-1/2 z-30 px-3.5 py-1.5 rounded-xl bg-slate-950/95 border border-slate-700 text-xs font-medium text-slate-100 shadow-lg pointer-events-none whitespace-nowrap max-w-[calc(100vw-24px)] truncate"
        >
          {toastMessage}
        </div>
      )}

      {/* Email/Password Authentication Modal (auto-shown over open map when signed out) */}
      <AuthModal
        isOpen={isAuthOpen || (authReady && !authUser && !authDismissed)}
        onClose={() => {
          setIsAuthOpen(false);
          setAuthDismissed(true);
        }}
        onSignIn={handleSignIn}
        onRegister={handleRegister}
        onResetPassword={handleResetPassword}
      />

      {/* Player Profile Modal (Authenticated) */}
      {profile && (
        <ProfileModal
          isOpen={isProfileOpen}
          activeProfile={profile}
          userEmail={authUser?.email ?? null}
          customRole={customRole}
          recentPlacements={recentPlacements}
          onClose={() => setIsProfileOpen(false)}
          onSaveProfile={handleSaveProfile}
          onRefreshClaims={handleRefreshClaims}
          onCheckOwnerBootstrap={handleCheckOwnerBootstrap}
          onClaimInitialOwner={handleClaimInitialOwner}
          onOpenOwnerPanel={
            customRole === 'owner' ? () => setIsOwnerPanelOpen(true) : undefined
          }
          onSignOut={handleSignOut}
          onJumpToCoordinate={handleJumpToCoordinate}
        />
      )}

      {/* Owner Panel Modal (Strictly Owner Custom Claim Only) */}
      {authUser && customRole === 'owner' && (
        <OwnerPanelModal
          isOpen={isOwnerPanelOpen}
          ownerUid={authUser.uid}
          onClose={() => setIsOwnerPanelOpen(false)}
        />
      )}

      {/* Moderation Center Modal (Owner & Admin Custom Claims) */}
      {authUser && (customRole === 'owner' || customRole === 'admin') && (
        <ModerationPanelModal
          isOpen={isModerationPanelOpen}
          currentUserId={authUser.uid}
          currentUserRole={customRole}
          serverTimeOffsetMs={serverTimeOffsetMs}
          onClose={() => setIsModerationPanelOpen(false)}
        />
      )}

      {/* Help & Quick Regions Modal */}
      <HelpModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        onSelectRegion={handleSelectRegion}
      />

      {/* Other Player's Public Profile Modal */}
      <PublicProfileModal
        isOpen={Boolean(inspectedPlayer)}
        targetUserId={inspectedPlayer?.id ?? null}
        fallbackUsername={inspectedPlayer?.username}
        currentUserId={authUser?.uid ?? null}
        currentUserRole={customRole}
        serverTimeOffsetMs={serverTimeOffsetMs}
        onClose={() => setInspectedPlayer(null)}
        onJumpToCoordinate={handleJumpToCoordinate}
      />
    </main>
  );
}
