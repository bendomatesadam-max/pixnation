export interface PixelPoint {
  x: number;
  y: number;
}

export interface PlacedPixelRecord {
  x: number;
  y: number;
  color: string;
  authorId: string;
  authorUsername: string;
  placedAt: number;
}

export type AvatarEmblem =
  | 'compass'
  | 'crown'
  | 'palette'
  | 'anchor'
  | 'mountain'
  | 'star';

export type UserRole = 'player' | 'moderator' | 'admin' | 'owner';

export interface PlayerProfile {
  id: string;
  username: string;
  bio: string;
  countryCode: string;
  accentColor: string;
  emblem: AvatarEmblem;
  totalPixelsPlaced: number;
  role?: UserRole;
  disabled?: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface PublicPlayerProfile {
  id: string;
  username: string;
  bio: string;
  countryCode: string;
  accentColor: string;
  emblem: AvatarEmblem;
  totalPixelsPlaced: number;
  role: UserRole;
  updatedAt: number;
}

export interface ManagedPlayerSummary {
  uid: string;
  email: string | null;
  username: string;
  role: UserRole;
  totalPixelsPlaced: number;
  disabled: boolean;
  createdAt: number;
}

export interface PaletteColor {
  id: string;
  name: string;
  hex: string;
}

export interface CameraState {
  /** World X coordinate at the center of the viewport */
  centerX: number;
  /** World Y coordinate at the center of the viewport */
  centerY: number;
  /** Screen pixels per world pixel */
  zoom: number;
}

export interface RegionPreset {
  id: string;
  label: string;
  centerX: number;
  centerY: number;
  zoom: number;
}

export type ActiveTool = 'paint' | 'eyedropper';

export interface CooldownConfig {
  durationMs: number;
}

export interface ChatMessage {
  id: string;
  authorId: string;
  authorUsername: string;
  authorColor: string;
  authorRole: UserRole;
  text: string;
  createdAt: number;
  pending?: boolean;
}

export type MuteDurationKey = '5m' | '1h' | '24h' | 'permanent';
export type BanDurationKey = '1h' | '24h' | '7d' | 'permanent';
export type ModerationType = 'mute' | 'ban';
export type ModerationAction = 'mute' | 'ban' | 'unmute' | 'unban';

export interface UserModerationState {
  userId: string;
  targetUsername: string;
  targetRole: UserRole;
  muteActive: boolean;
  muteReason: string;
  muteDurationKey: MuteDurationKey | '';
  mutePermanent: boolean;
  muteActorUid: string;
  muteActorUsername: string;
  muteActorRole: 'owner' | 'admin' | '';
  muteStartedAtMs: number | null;
  muteExpiresAtMs: number | null;
  banActive: boolean;
  banReason: string;
  banDurationKey: BanDurationKey | '';
  banPermanent: boolean;
  banActorUid: string;
  banActorUsername: string;
  banActorRole: 'owner' | 'admin' | '';
  banStartedAtMs: number | null;
  banExpiresAtMs: number | null;
  updatedAtMs: number;
}

export interface ModerationLogEntry {
  id: string;
  action: ModerationAction;
  actorUid: string;
  actorUsername: string;
  actorRole: 'owner' | 'admin';
  targetUid: string;
  targetUsername: string;
  targetRole: UserRole;
  reason: string;
  durationKey: MuteDurationKey | BanDurationKey | 'none';
  durationMs: number;
  permanent: boolean;
  expiresAtMs: number | null;
  createdAtMs: number;
}

