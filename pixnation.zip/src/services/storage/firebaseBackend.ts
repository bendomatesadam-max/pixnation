import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  updateProfile as firebaseUpdateAuthProfile,
  User,
} from 'firebase/auth';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  getGlobalCooldownDurationMs,
  PROFILE_ACCENT_COLORS,
} from '../../constants/palette';
import { auth, db } from '../../firebase';
import {
  AvatarEmblem,
  BanDurationKey,
  ChatMessage,
  ManagedPlayerSummary,
  ModerationAction,
  ModerationLogEntry,
  ModerationType,
  MuteDurationKey,
  PlacedPixelRecord,
  PlayerProfile,
  PublicPlayerProfile,
  UserModerationState,
  UserRole,
} from '../../types/game';
import {
  BAN_DURATION_OPTIONS,
  canViewerModerateTarget,
  formatRemainingDuration,
  getActiveBan,
  getActiveMute,
  MUTE_DURATION_OPTIONS,
} from '../../utils/moderation';
import { WORLD_HEIGHT, WORLD_WIDTH } from '../../utils/worldMapGenerator';
import {
  handleFirestoreError,
  isPermissionDeniedError,
  OperationType,
} from './firestoreError';
import {
  makePixelKey,
  PixelMap,
  PixelSubscriptionCallback,
  PlacePixelInput,
  UpdateProfileInput,
} from './types';

const PIXELS_COLLECTION = 'pixels';
const USERS_COLLECTION = 'users';
const PUBLIC_PROFILES_COLLECTION = 'publicProfiles';
const COOLDOWNS_COLLECTION = 'cooldowns';
const CHAT_COLLECTION = 'chat';
const MODERATION_COLLECTION = 'moderation';
const MODERATION_LOGS_COLLECTION = 'moderationLogs';

const VALID_HEX_REGEX = /^#[0-9A-Fa-f]{6}$/;

function makePixelDocId(x: number, y: number): string {
  return `${x}_${y}`;
}

function sanitizeUsername(name: string, fallback = 'GezginPiksel'): string {
  const cleaned = name.trim().replace(/\s+/g, ' ').slice(0, 20);
  return cleaned || fallback;
}

function sanitizeBio(bio: string): string {
  return bio.trim().slice(0, 80);
}

function sanitizeCountryCode(code: string): string {
  const cleaned = code.trim().toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3);
  return cleaned || 'TR';
}

function docToPixelRecord(data: Record<string, unknown>): PlacedPixelRecord | null {
  if (
    typeof data.x !== 'number' ||
    typeof data.y !== 'number' ||
    typeof data.color !== 'string' ||
    typeof data.authorId !== 'string'
  ) {
    return null;
  }
  return {
    x: data.x,
    y: data.y,
    color: data.color,
    authorId: data.authorId,
    authorUsername:
      typeof data.authorUsername === 'string' && data.authorUsername
        ? data.authorUsername
        : 'Oyuncu',
    placedAt: typeof data.placedAt === 'number' ? data.placedAt : Date.now(),
  };
}

function docToPlayerProfile(uid: string, data: Record<string, unknown>, fallbackName: string): PlayerProfile {
  const validEmblems: AvatarEmblem[] = [
    'compass',
    'crown',
    'palette',
    'anchor',
    'mountain',
    'star',
  ];
  const emblem =
    typeof data.emblem === 'string' && validEmblems.includes(data.emblem as AvatarEmblem)
      ? (data.emblem as AvatarEmblem)
      : 'compass';

  return {
    id: uid,
    username:
      typeof data.username === 'string' && data.username.trim()
        ? data.username.trim().slice(0, 20)
        : fallbackName,
    bio: typeof data.bio === 'string' ? data.bio.slice(0, 80) : '',
    countryCode:
      typeof data.countryCode === 'string' && data.countryCode.trim()
        ? data.countryCode.trim().toUpperCase().slice(0, 3)
        : 'TR',
    accentColor:
      typeof data.accentColor === 'string' && VALID_HEX_REGEX.test(data.accentColor)
        ? data.accentColor
        : PROFILE_ACCENT_COLORS[0],
    emblem,
    totalPixelsPlaced:
      typeof data.totalPixelsPlaced === 'number' && Number.isFinite(data.totalPixelsPlaced)
        ? Math.max(0, Math.floor(data.totalPixelsPlaced))
        : 0,
    role:
      data.role === 'owner' || data.role === 'admin' || data.role === 'moderator'
        ? data.role
        : 'player',
    disabled: Boolean(data.disabled),
    createdAt: typeof data.createdAt === 'number' ? data.createdAt : Date.now(),
    updatedAt: typeof data.updatedAt === 'number' ? data.updatedAt : Date.now(),
  };
}

function parseTokenRole(claims: Record<string, unknown>): UserRole {
  const role = claims.role;
  if (role === 'owner' || role === 'admin' || role === 'moderator') {
    return role;
  }
  return 'player';
}

function docToModerationState(uid: string, data: Record<string, unknown>): UserModerationState {
  const parseTs = (val: unknown): number | null => {
    if (val instanceof Timestamp) return val.toMillis();
    if (typeof val === 'number' && Number.isFinite(val)) return val;
    return null;
  };
  const parseRole = (val: unknown): UserRole =>
    val === 'owner' || val === 'admin' || val === 'moderator' ? val : 'player';
  const parseActorRole = (val: unknown): 'owner' | 'admin' | '' =>
    val === 'owner' || val === 'admin' ? val : '';

  return {
    userId: typeof data.userId === 'string' ? data.userId : uid,
    targetUsername:
      typeof data.targetUsername === 'string' && data.targetUsername
        ? data.targetUsername
        : 'Oyuncu',
    targetRole: parseRole(data.targetRole),
    muteActive: Boolean(data.muteActive),
    muteReason: typeof data.muteReason === 'string' ? data.muteReason : '',
    muteDurationKey:
      data.muteDurationKey === '5m' ||
      data.muteDurationKey === '1h' ||
      data.muteDurationKey === '24h' ||
      data.muteDurationKey === 'permanent'
        ? data.muteDurationKey
        : '',
    mutePermanent: Boolean(data.mutePermanent),
    muteActorUid: typeof data.muteActorUid === 'string' ? data.muteActorUid : '',
    muteActorUsername:
      typeof data.muteActorUsername === 'string' ? data.muteActorUsername : '',
    muteActorRole: parseActorRole(data.muteActorRole),
    muteStartedAtMs: parseTs(data.muteStartedAt),
    muteExpiresAtMs: parseTs(data.muteExpiresAt),
    banActive: Boolean(data.banActive),
    banReason: typeof data.banReason === 'string' ? data.banReason : '',
    banDurationKey:
      data.banDurationKey === '1h' ||
      data.banDurationKey === '24h' ||
      data.banDurationKey === '7d' ||
      data.banDurationKey === 'permanent'
        ? data.banDurationKey
        : '',
    banPermanent: Boolean(data.banPermanent),
    banActorUid: typeof data.banActorUid === 'string' ? data.banActorUid : '',
    banActorUsername:
      typeof data.banActorUsername === 'string' ? data.banActorUsername : '',
    banActorRole: parseActorRole(data.banActorRole),
    banStartedAtMs: parseTs(data.banStartedAt),
    banExpiresAtMs: parseTs(data.banExpiresAt),
    updatedAtMs: parseTs(data.updatedAt) ?? Date.now(),
  };
}

function docToModerationLog(id: string, data: Record<string, unknown>): ModerationLogEntry | null {
  const action = data.action;
  if (action !== 'mute' && action !== 'ban' && action !== 'unmute' && action !== 'unban') {
    return null;
  }
  const actorRole = data.actorRole === 'owner' || data.actorRole === 'admin' ? data.actorRole : null;
  if (!actorRole) return null;

  const targetRole: UserRole =
    data.targetRole === 'owner' ||
    data.targetRole === 'admin' ||
    data.targetRole === 'moderator'
      ? data.targetRole
      : 'player';

  const durationKey =
    data.durationKey === '5m' ||
    data.durationKey === '1h' ||
    data.durationKey === '24h' ||
    data.durationKey === '7d' ||
    data.durationKey === 'permanent' ||
    data.durationKey === 'none'
      ? data.durationKey
      : 'none';

  return {
    id,
    action: action as ModerationAction,
    actorUid: typeof data.actorUid === 'string' ? data.actorUid : '',
    actorUsername: typeof data.actorUsername === 'string' ? data.actorUsername : 'Yetkili',
    actorRole,
    targetUid: typeof data.targetUid === 'string' ? data.targetUid : '',
    targetUsername: typeof data.targetUsername === 'string' ? data.targetUsername : 'Oyuncu',
    targetRole,
    reason: typeof data.reason === 'string' ? data.reason : '',
    durationKey,
    durationMs: typeof data.durationMs === 'number' ? data.durationMs : 0,
    permanent: Boolean(data.permanent),
    expiresAtMs: data.expiresAt instanceof Timestamp ? data.expiresAt.toMillis() : null,
    createdAtMs: data.createdAt instanceof Timestamp ? data.createdAt.toMillis() : Date.now(),
  };
}

export class FirebasePixelService {
  private cache: PixelMap = new Map();
  private adminReadyCache: { value: boolean; checkedAt: number } | null = null;

  private async isServerAdminReady(): Promise<boolean> {
    const now = Date.now();
    if (this.adminReadyCache && now - this.adminReadyCache.checkedAt < 30_000) {
      return this.adminReadyCache.value;
    }
    try {
      const res = await fetch('/api/health');
      if (!res.ok) {
        this.adminReadyCache = { value: false, checkedAt: now };
        return false;
      }
      const data = await res.json();
      const ready = Boolean(data?.adminReady);
      this.adminReadyCache = { value: ready, checkedAt: now };
      return ready;
    } catch {
      this.adminReadyCache = { value: false, checkedAt: now };
      return false;
    }
  }

  public async loadAllPixels(): Promise<PixelMap> {
    try {
      const snap = await getDocs(collection(db, PIXELS_COLLECTION));
      const next: PixelMap = new Map();
      snap.forEach((docSnap) => {
        const record = docToPixelRecord(docSnap.data());
        if (record) {
          next.set(makePixelKey(record.x, record.y), record);
        }
      });
      this.cache = next;
      return new Map(next);
    } catch (error) {
      if (isPermissionDeniedError(error)) {
        return new Map(this.cache);
      }
      handleFirestoreError(error, OperationType.LIST, PIXELS_COLLECTION);
    }
  }

  public subscribePixels(
    callback: PixelSubscriptionCallback,
    onPermissionDenied?: () => void
  ): () => void {
    const colRef = collection(db, PIXELS_COLLECTION);
    return onSnapshot(
      colRef,
      (snapshot) => {
        const next: PixelMap = new Map();
        snapshot.forEach((docSnap) => {
          const record = docToPixelRecord(docSnap.data());
          if (record) {
            next.set(makePixelKey(record.x, record.y), record);
          }
        });
        this.cache = next;
        callback(new Map(next));
      },
      (error) => {
        if (isPermissionDeniedError(error)) {
          onPermissionDenied?.();
          return;
        }
        handleFirestoreError(error, OperationType.LIST, PIXELS_COLLECTION);
      }
    );
  }

  public async placePixel(input: PlacePixelInput): Promise<PlacedPixelRecord> {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Piksel yerleştirmek için giriş yapmalısınız.');
    }

    const x = Math.floor(input.x);
    const y = Math.floor(input.y);
    if (x < 0 || x >= WORLD_WIDTH || y < 0 || y >= WORLD_HEIGHT) {
      throw new Error('Geçersiz piksel koordinatı.');
    }
    if (!VALID_HEX_REGEX.test(input.color)) {
      throw new Error('Geçersiz renk kodu.');
    }

    const normalizedColor = input.color.toUpperCase();

    // Use trusted server endpoint (increments totalPixelsPlaced + checks server cooldown) when Admin SDK IAM is ready
    if (await this.isServerAdminReady()) {
      const token = await currentUser.getIdToken();
      const res = await fetch('/api/pixels/place', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ x, y, color: normalizedColor }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Piksel yerleştirilemedi.');
      }
      return data.pixel as PlacedPixelRecord;
    }

    // Fallback when Admin SDK IAM is not yet configured:
    // Atomic WriteBatch updating /pixels/{x}_{y} and /cooldowns/{uid} with serverTimestamp()
    // without touching totalPixelsPlaced (strictly server-only in firestore.rules).
    const now = Date.now();
    const fallbackUsername = sanitizeUsername(
      input.authorUsername,
      currentUser.displayName || currentUser.email?.split('@')[0] || 'Oyuncu'
    );
    const userRef = doc(db, USERS_COLLECTION, currentUser.uid);
    const publicRef = doc(db, PUBLIC_PROFILES_COLLECTION, currentUser.uid);
    const userPath = `${USERS_COLLECTION}/${currentUser.uid}`;

    let resolvedUsername = fallbackUsername;
    try {
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        const userData = userSnap.data();
        if (userData?.disabled === true) {
          throw new Error('Hesabınız askıya alınmış durumda.');
        }
        if (
          typeof userData?.username === 'string' &&
          userData.username.length >= 1 &&
          userData.username.length <= 20
        ) {
          // Use the exact stored username so matchesAuthorUsername() in firestore.rules passes strictly
          resolvedUsername = userData.username;
        }
      } else {
        const publicSnap = await getDoc(publicRef).catch(() => null);
        const initUsername =
          publicSnap &&
          publicSnap.exists() &&
          typeof publicSnap.data()?.username === 'string' &&
          publicSnap.data()!.username.length >= 1 &&
          publicSnap.data()!.username.length <= 20
            ? (publicSnap.data()!.username as string)
            : fallbackUsername;
        resolvedUsername = initUsername;

        const initBatch = writeBatch(db);
        initBatch.set(userRef, {
          id: currentUser.uid,
          username: initUsername,
          bio: 'PixNation kaşifi.',
          countryCode: 'TR',
          accentColor: PROFILE_ACCENT_COLORS[0],
          emblem: 'compass',
          totalPixelsPlaced: 0,
          createdAt: now,
          updatedAt: now,
        });
        if (!publicSnap || !publicSnap.exists()) {
          initBatch.set(publicRef, {
            id: currentUser.uid,
            username: initUsername,
            bio: 'PixNation kaşifi.',
            countryCode: 'TR',
            accentColor: PROFILE_ACCENT_COLORS[0],
            emblem: 'compass',
            totalPixelsPlaced: 0,
            updatedAt: now,
          });
        }
        await initBatch.commit();
      }
    } catch (error) {
      if (error instanceof Error && error.message === 'Hesabınız askıya alınmış durumda.') {
        throw error;
      }
      handleFirestoreError(error, OperationType.GET, userPath);
    }

    try {
      const modSnap = await getDoc(doc(db, MODERATION_COLLECTION, currentUser.uid));
      if (modSnap.exists()) {
        const modState = docToModerationState(currentUser.uid, modSnap.data());
        const activeBan = getActiveBan(modState, now);
        if (activeBan) {
          const durationLabel = activeBan.permanent
            ? 'Kalıcı'
            : activeBan.remainingMs !== null
              ? `Kalan: ${formatRemainingDuration(activeBan.remainingMs)}`
              : 'Süreli';
          throw new Error(
            `Yasaklandığınız için piksel yerleştiremezsiniz (${durationLabel}). Neden: ${activeBan.reason}`
          );
        }
      }
    } catch (error) {
      if (error instanceof Error && error.message.startsWith('Yasaklandığınız için')) {
        throw error;
      }
      // If read fails transiently, Firestore Rules remain authoritative on commit
    }

    const docId = makePixelDocId(x, y);
    const pixelPath = `${PIXELS_COLLECTION}/${docId}`;

    const record: PlacedPixelRecord = {
      x,
      y,
      color: normalizedColor,
      authorId: currentUser.uid,
      authorUsername: resolvedUsername,
      placedAt: now,
    };

    const batch = writeBatch(db);
    batch.set(doc(db, PIXELS_COLLECTION, docId), {
      ...record,
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, COOLDOWNS_COLLECTION, currentUser.uid), {
      userId: currentUser.uid,
      lastPlacedAt: serverTimestamp(),
    });

    try {
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, pixelPath);
    }

    return record;
  }

  public async getPixelsByAuthor(authorId: string, limitCount = 12): Promise<PlacedPixelRecord[]> {
    // Prefer fast live cache when available
    if (this.cache.size > 0) {
      const fromCache: PlacedPixelRecord[] = [];
      this.cache.forEach((pixel) => {
        if (pixel.authorId === authorId) {
          fromCache.push(pixel);
        }
      });
      if (fromCache.length > 0) {
        fromCache.sort((a, b) => b.placedAt - a.placedAt);
        return fromCache.slice(0, limitCount);
      }
    }

    try {
      const q = query(
        collection(db, PIXELS_COLLECTION),
        where('authorId', '==', authorId)
      );
      const snap = await getDocs(q);
      const results: PlacedPixelRecord[] = [];
      snap.forEach((docSnap) => {
        const record = docToPixelRecord(docSnap.data());
        if (record) results.push(record);
      });
      results.sort((a, b) => b.placedAt - a.placedAt);
      return results.slice(0, limitCount);
    } catch (error) {
      if (isPermissionDeniedError(error)) {
        return [];
      }
      handleFirestoreError(error, OperationType.LIST, PIXELS_COLLECTION);
    }
  }
}

export interface ServerCooldownState {
  lastPlacedAtMs: number;
  cooldownEndAt: number;
  cooldownDurationMs: number;
}

function docToPublicProfile(uid: string, data: Record<string, unknown>): PublicPlayerProfile {
  const validEmblems: AvatarEmblem[] = [
    'compass',
    'crown',
    'palette',
    'anchor',
    'mountain',
    'star',
  ];
  const emblem =
    typeof data.emblem === 'string' && validEmblems.includes(data.emblem as AvatarEmblem)
      ? (data.emblem as AvatarEmblem)
      : 'compass';

  return {
    id: uid,
    username:
      typeof data.username === 'string' && data.username.trim()
        ? data.username.trim().slice(0, 20)
        : 'Oyuncu',
    bio: typeof data.bio === 'string' ? data.bio.slice(0, 80) : '',
    countryCode:
      typeof data.countryCode === 'string' && data.countryCode.trim()
        ? data.countryCode.trim().toUpperCase().slice(0, 3)
        : 'TR',
    accentColor:
      typeof data.accentColor === 'string' && VALID_HEX_REGEX.test(data.accentColor)
        ? data.accentColor
        : PROFILE_ACCENT_COLORS[0],
    emblem,
    totalPixelsPlaced:
      typeof data.totalPixelsPlaced === 'number' && Number.isFinite(data.totalPixelsPlaced)
        ? Math.max(0, Math.floor(data.totalPixelsPlaced))
        : 0,
    role:
      data.role === 'owner' || data.role === 'admin' || data.role === 'moderator'
        ? data.role
        : 'player',
    updatedAt: typeof data.updatedAt === 'number' ? data.updatedAt : Date.now(),
  };
}

export class FirebaseAuthProfileService {
  private registeringPromise: Promise<void> | null = null;

  public async fetchServerTimeOffsetMs(): Promise<number> {
    try {
      const before = Date.now();
      const res = await fetch('/api/server-time');
      if (!res.ok) return 0;
      const data = await res.json();
      const after = Date.now();
      if (typeof data?.serverTimeMs === 'number') {
        const midpoint = Math.round((before + after) / 2);
        return data.serverTimeMs - midpoint;
      }
      return 0;
    } catch {
      return 0;
    }
  }

  public subscribeCooldown(
    uid: string,
    onUpdate: (state: ServerCooldownState | null) => void,
    getServerTimeOffsetMs: () => number = () => 0
  ): () => void {
    const cooldownRef = doc(db, COOLDOWNS_COLLECTION, uid);
    return onSnapshot(
      cooldownRef,
      (snap) => {
        if (!snap.exists()) {
          onUpdate(null);
          return;
        }
        const rawTs = snap.data()?.lastPlacedAt;
        // When WriteBatch writes serverTimestamp(), Firestore emits a local latency-compensated
        // snapshot with lastPlacedAt === null before the server timestamp resolves.
        // Ignore that intermediate pending state so the active cooldown isn't wiped to 0.
        if (snap.metadata.hasPendingWrites && !(rawTs instanceof Timestamp)) {
          return;
        }
        if (rawTs instanceof Timestamp) {
          const lastPlacedAtMs = rawTs.toMillis();
          const currentServerNow = Date.now() + getServerTimeOffsetMs();
          const cooldownDurationMs = getGlobalCooldownDurationMs(currentServerNow);
          onUpdate({
            lastPlacedAtMs,
            cooldownDurationMs,
            cooldownEndAt: lastPlacedAtMs + cooldownDurationMs,
          });
        } else {
          onUpdate(null);
        }
      },
      (error) => {
        if (!isPermissionDeniedError(error)) {
          console.warn('Cooldown dinleyicisi hatası:', error);
        }
      }
    );
  }

  public async getPublicProfile(userId: string): Promise<PublicPlayerProfile | null> {
    const ref = doc(db, PUBLIC_PROFILES_COLLECTION, userId);
    try {
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        return null;
      }
      return docToPublicProfile(userId, snap.data());
    } catch (error) {
      if (isPermissionDeniedError(error)) {
        return null;
      }
      handleFirestoreError(error, OperationType.GET, `${PUBLIC_PROFILES_COLLECTION}/${userId}`);
    }
  }

  public async getCustomRole(forceRefresh = false): Promise<UserRole> {
    const currentUser = auth.currentUser;
    if (!currentUser) return 'player';
    try {
      const tokenResult = await currentUser.getIdTokenResult(forceRefresh);
      return parseTokenRole(tokenResult.claims);
    } catch {
      return 'player';
    }
  }

  public subscribeAuthAndProfile(
    onUpdate: (state: {
      user: User | null;
      profile: PlayerProfile | null;
      customRole: UserRole;
      authReady: boolean;
    }) => void
  ): () => void {
    let unsubscribeProfileDoc: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (unsubscribeProfileDoc) {
        unsubscribeProfileDoc();
        unsubscribeProfileDoc = null;
      }

      if (!user) {
        onUpdate({ user: null, profile: null, customRole: 'player', authReady: true });
        return;
      }

      if (this.registeringPromise) {
        await this.registeringPromise.catch(() => undefined);
      }

      let resolvedClaimRole: UserRole = 'player';
      try {
        const tokenResult = await user.getIdTokenResult();
        resolvedClaimRole = parseTokenRole(tokenResult.claims);
      } catch {
        resolvedClaimRole = 'player';
      }

      const fallbackName = sanitizeUsername(
        user.displayName || user.email?.split('@')[0] || 'GezginPiksel'
      );

      // Ensure user profile & public profile documents exist in Firestore atomically
      const userDocRef = doc(db, USERS_COLLECTION, user.uid);
      const publicDocRef = doc(db, PUBLIC_PROFILES_COLLECTION, user.uid);
      const userPath = `${USERS_COLLECTION}/${user.uid}`;
      try {
        const [existingUser, existingPublic] = await Promise.all([
          getDoc(userDocRef),
          getDoc(publicDocRef).catch(() => null),
        ]);
        const now = Date.now();
        const needUserCreate = !existingUser.exists();
        const needPublicCreate = Boolean(existingPublic && !existingPublic.exists());

        if (needUserCreate || needPublicCreate) {
          const batch = writeBatch(db);
          const userData = existingUser.exists() ? existingUser.data() : null;
          const publicData = existingPublic && existingPublic.exists() ? existingPublic.data() : null;
          const validEmblems: AvatarEmblem[] = [
            'compass',
            'crown',
            'palette',
            'anchor',
            'mountain',
            'star',
          ];
          const rawExistingUsername =
            typeof userData?.username === 'string' && userData.username.length >= 1 && userData.username.length <= 20
              ? userData.username
              : typeof publicData?.username === 'string' && publicData.username.length >= 1 && publicData.username.length <= 20
                ? publicData.username
                : fallbackName;

          if (needUserCreate) {
            const initialProfile: PlayerProfile = {
              id: user.uid,
              username: rawExistingUsername,
              bio: 'PixNation kaşifi.',
              countryCode: 'TR',
              accentColor: PROFILE_ACCENT_COLORS[0],
              emblem: 'compass',
              totalPixelsPlaced: 0,
              createdAt: now,
              updatedAt: now,
            };
            batch.set(userDocRef, initialProfile);
          }

          if (needPublicCreate) {
            const safeEmblem =
              typeof userData?.emblem === 'string' && validEmblems.includes(userData.emblem as AvatarEmblem)
                ? userData.emblem
                : 'compass';
            batch.set(publicDocRef, {
              id: user.uid,
              username: rawExistingUsername,
              bio: typeof userData?.bio === 'string' ? userData.bio.slice(0, 80) : 'PixNation kaşifi.',
              countryCode:
                typeof userData?.countryCode === 'string' && userData.countryCode.trim()
                  ? userData.countryCode.trim().toUpperCase().slice(0, 3)
                  : 'TR',
              accentColor:
                typeof userData?.accentColor === 'string' && VALID_HEX_REGEX.test(userData.accentColor)
                  ? userData.accentColor
                  : PROFILE_ACCENT_COLORS[0],
              emblem: safeEmblem,
              totalPixelsPlaced:
                typeof userData?.totalPixelsPlaced === 'number' ? userData.totalPixelsPlaced : 0,
              updatedAt: now,
            });
          }

          await batch.commit();
        }
      } catch (error) {
        if (!isPermissionDeniedError(error)) {
          console.error('Profil oluşturma hatası:', error);
        }
      }

      unsubscribeProfileDoc = onSnapshot(
        userDocRef,
        (docSnap) => {
          if (docSnap.exists()) {
            const prof = docToPlayerProfile(user.uid, docSnap.data(), fallbackName);
            onUpdate({ user, profile: prof, customRole: resolvedClaimRole, authReady: true });
          } else {
            const now = Date.now();
            onUpdate({
              user,
              profile: {
                id: user.uid,
                username: fallbackName,
                bio: 'PixNation kaşifi.',
                countryCode: 'TR',
                accentColor: PROFILE_ACCENT_COLORS[0],
                emblem: 'compass',
                totalPixelsPlaced: 0,
                createdAt: now,
                updatedAt: now,
              },
              customRole: resolvedClaimRole,
              authReady: true,
            });
          }
        },
        (error) => {
          if (isPermissionDeniedError(error)) {
            const now = Date.now();
            onUpdate({
              user,
              profile: {
                id: user.uid,
                username: fallbackName,
                bio: '',
                countryCode: 'TR',
                accentColor: PROFILE_ACCENT_COLORS[0],
                emblem: 'compass',
                totalPixelsPlaced: 0,
                createdAt: now,
                updatedAt: now,
              },
              customRole: resolvedClaimRole,
              authReady: true,
            });
            return;
          }
          handleFirestoreError(error, OperationType.GET, userPath);
        }
      );
    });

    return () => {
      if (unsubscribeProfileDoc) {
        unsubscribeProfileDoc();
      }
      unsubscribeAuth();
    };
  }

  public async signInWithEmail(email: string, password: string): Promise<User> {
    const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
    return cred.user;
  }

  public async registerWithEmail(
    email: string,
    password: string,
    username: string
  ): Promise<User> {
    const safeUsername = sanitizeUsername(username);
    let resolveRegistration!: () => void;
    this.registeringPromise = new Promise<void>((resolve) => {
      resolveRegistration = resolve;
    });

    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);

      await firebaseUpdateAuthProfile(cred.user, {
        displayName: safeUsername,
      });

      const now = Date.now();
      const initialProfile: PlayerProfile = {
        id: cred.user.uid,
        username: safeUsername,
        bio: 'PixNation dünyasına katıldı.',
        countryCode: 'TR',
        accentColor: PROFILE_ACCENT_COLORS[0],
        emblem: 'compass',
        totalPixelsPlaced: 0,
        createdAt: now,
        updatedAt: now,
      };

      const userPath = `${USERS_COLLECTION}/${cred.user.uid}`;
      try {
        const batch = writeBatch(db);
        batch.set(doc(db, USERS_COLLECTION, cred.user.uid), initialProfile);
        batch.set(doc(db, PUBLIC_PROFILES_COLLECTION, cred.user.uid), {
          id: cred.user.uid,
          username: safeUsername,
          bio: 'PixNation dünyasına katıldı.',
          countryCode: 'TR',
          accentColor: PROFILE_ACCENT_COLORS[0],
          emblem: 'compass',
          totalPixelsPlaced: 0,
          updatedAt: now,
        });
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, userPath);
      }

      return cred.user;
    } finally {
      resolveRegistration();
      this.registeringPromise = null;
    }
  }

  public async signOut(): Promise<void> {
    await firebaseSignOut(auth);
  }

  public async sendPasswordReset(email: string): Promise<void> {
    await sendPasswordResetEmail(auth, email.trim());
  }

  public async updateProfile(input: UpdateProfileInput): Promise<PlayerProfile> {
    const currentUser = auth.currentUser;
    if (!currentUser || currentUser.uid !== input.id) {
      throw new Error('Profili güncellemek için giriş yapmalısınız.');
    }

    const safeUsername = sanitizeUsername(input.username);
    const safeBio = sanitizeBio(input.bio);
    const safeCountry = sanitizeCountryCode(input.countryCode);
    const safeAccent = VALID_HEX_REGEX.test(input.accentColor)
      ? input.accentColor
      : PROFILE_ACCENT_COLORS[0];

    const now = Date.now();
    const userPath = `${USERS_COLLECTION}/${currentUser.uid}`;
    const userRef = doc(db, USERS_COLLECTION, currentUser.uid);
    const publicRef = doc(db, PUBLIC_PROFILES_COLLECTION, currentUser.uid);

    try {
      const [existingSnap, existingPublicSnap] = await Promise.all([
        getDoc(userRef),
        getDoc(publicRef),
      ]);

      const currentPixelsPlaced =
        existingSnap.exists() && typeof existingSnap.data()?.totalPixelsPlaced === 'number'
          ? Math.max(0, Math.floor(existingSnap.data()!.totalPixelsPlaced))
          : 0;

      const batch = writeBatch(db);

      if (!existingSnap.exists()) {
        batch.set(userRef, {
          id: currentUser.uid,
          username: safeUsername,
          bio: safeBio,
          countryCode: safeCountry,
          accentColor: safeAccent,
          emblem: input.emblem,
          totalPixelsPlaced: 0,
          createdAt: now,
          updatedAt: now,
        });
      } else {
        batch.update(userRef, {
          username: safeUsername,
          bio: safeBio,
          countryCode: safeCountry,
          accentColor: safeAccent,
          emblem: input.emblem,
          updatedAt: now,
        });
      }

      if (!existingPublicSnap.exists()) {
        batch.set(publicRef, {
          id: currentUser.uid,
          username: safeUsername,
          bio: safeBio,
          countryCode: safeCountry,
          accentColor: safeAccent,
          emblem: input.emblem,
          totalPixelsPlaced: currentPixelsPlaced,
          updatedAt: now,
        });
      } else {
        batch.update(publicRef, {
          username: safeUsername,
          bio: safeBio,
          countryCode: safeCountry,
          accentColor: safeAccent,
          emblem: input.emblem,
          updatedAt: now,
        });
      }

      await batch.commit();

      if (currentUser.displayName !== safeUsername) {
        await firebaseUpdateAuthProfile(currentUser, { displayName: safeUsername });
      }

      const snap = await getDoc(userRef);
      if (snap.exists()) {
        return docToPlayerProfile(currentUser.uid, snap.data(), safeUsername);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, userPath);
    }

    return {
      id: currentUser.uid,
      username: safeUsername,
      bio: safeBio,
      countryCode: safeCountry,
      accentColor: safeAccent,
      emblem: input.emblem,
      totalPixelsPlaced: 0,
      createdAt: now,
      updatedAt: now,
    };
  }

  private async getAuthHeaders(): Promise<Record<string, string>> {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Oturum açılmamış.');
    }
    const token = await currentUser.getIdToken();
    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    };
  }

  public async fetchManagedPlayers(): Promise<ManagedPlayerSummary[]> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/owner/players', { headers });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Oyuncu listesi alınamadı.');
    }
    return data.players as ManagedPlayerSummary[];
  }

  public async assignPlayerRole(
    targetUid: string,
    role: 'player' | 'moderator' | 'admin'
  ): Promise<void> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/owner/set-role', {
      method: 'POST',
      headers,
      body: JSON.stringify({ targetUid, role }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Rol güncellenemedi.');
    }
  }

  public async setPlayerDisabled(targetUid: string, disabled: boolean): Promise<void> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/owner/set-status', {
      method: 'POST',
      headers,
      body: JSON.stringify({ targetUid, disabled }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Kullanıcı durumu güncellenemedi.');
    }
  }

  public async getOwnerBootstrapStatus(): Promise<boolean> {
    try {
      const headers = await this.getAuthHeaders();
      const res = await fetch('/api/owner/bootstrap-status', { headers });
      if (!res.ok) return false;
      const data = await res.json();
      return Boolean(data?.eligible);
    } catch {
      return false;
    }
  }

  public async claimInitialOwner(): Promise<void> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/owner/bootstrap', {
      method: 'POST',
      headers,
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'İlk Owner kurulumu tamamlanamadı.');
    }
  }
}

export class FirebaseChatService {
  public subscribeMessages(
    onUpdate: (messages: ChatMessage[]) => void,
    onError?: (errorMessage: string) => void
  ): () => void {
    const chatQuery = query(
      collection(db, CHAT_COLLECTION),
      orderBy('createdAt', 'desc'),
      limit(80)
    );

    return onSnapshot(
      chatQuery,
      (snapshot) => {
        const items: ChatMessage[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          if (
            typeof data.authorId !== 'string' ||
            typeof data.authorUsername !== 'string' ||
            typeof data.text !== 'string'
          ) {
            return;
          }

          const role: UserRole =
            data.authorRole === 'owner' ||
            data.authorRole === 'admin' ||
            data.authorRole === 'moderator'
              ? data.authorRole
              : 'player';

          const rawTs = data.createdAt;
          const createdAt =
            rawTs instanceof Timestamp ? rawTs.toMillis() : Date.now();

          items.push({
            id: docSnap.id,
            authorId: data.authorId,
            authorUsername: data.authorUsername,
            authorColor:
              typeof data.authorColor === 'string' && VALID_HEX_REGEX.test(data.authorColor)
                ? data.authorColor
                : PROFILE_ACCENT_COLORS[0],
            authorRole: role,
            text: data.text,
            createdAt,
            pending: docSnap.metadata.hasPendingWrites,
          });
        });

        items.reverse();
        onUpdate(items);
      },
      (error) => {
        if (isPermissionDeniedError(error)) {
          onError?.('Sohbet okuma izni reddedildi. Firestore güvenlik kurallarını kontrol edin.');
          return;
        }
        onError?.('Sohbet bağlantısı kurulurken bir hata oluştu.');
      }
    );
  }

  public async sendMessage(rawText: string, fallbackAccentColor?: string): Promise<void> {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Mesaj göndermek için giriş yapmalısınız.');
    }

    const trimmed = rawText.trim();
    if (!trimmed) {
      throw new Error('Boş mesaj gönderilemez.');
    }
    if (trimmed.length > 240) {
      throw new Error('Mesaj en fazla 240 karakter olabilir.');
    }

    const userRef = doc(db, USERS_COLLECTION, currentUser.uid);
    const publicRef = doc(db, PUBLIC_PROFILES_COLLECTION, currentUser.uid);
    const userPath = `${USERS_COLLECTION}/${currentUser.uid}`;
    const now = Date.now();
    const fallbackUsername = sanitizeUsername(
      currentUser.displayName || currentUser.email?.split('@')[0] || 'Oyuncu'
    );

    let resolvedUsername = fallbackUsername;
    let resolvedColor =
      fallbackAccentColor && VALID_HEX_REGEX.test(fallbackAccentColor)
        ? fallbackAccentColor
        : PROFILE_ACCENT_COLORS[0];

    try {
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        const userData = userSnap.data();
        if (userData?.disabled === true) {
          throw new Error('Hesabınız askıya alınmış durumda.');
        }
        if (
          typeof userData?.username === 'string' &&
          userData.username.length >= 1 &&
          userData.username.length <= 20
        ) {
          resolvedUsername = userData.username;
        }
        if (
          typeof userData?.accentColor === 'string' &&
          VALID_HEX_REGEX.test(userData.accentColor)
        ) {
          resolvedColor = userData.accentColor;
        }
      } else {
        const publicSnap = await getDoc(publicRef).catch(() => null);
        const initUsername =
          publicSnap &&
          publicSnap.exists() &&
          typeof publicSnap.data()?.username === 'string' &&
          publicSnap.data()!.username.length >= 1 &&
          publicSnap.data()!.username.length <= 20
            ? (publicSnap.data()!.username as string)
            : fallbackUsername;
        resolvedUsername = initUsername;

        const initBatch = writeBatch(db);
        initBatch.set(userRef, {
          id: currentUser.uid,
          username: initUsername,
          bio: 'PixNation kaşifi.',
          countryCode: 'TR',
          accentColor: resolvedColor,
          emblem: 'compass',
          totalPixelsPlaced: 0,
          createdAt: now,
          updatedAt: now,
        });
        if (!publicSnap || !publicSnap.exists()) {
          initBatch.set(publicRef, {
            id: currentUser.uid,
            username: initUsername,
            bio: 'PixNation kaşifi.',
            countryCode: 'TR',
            accentColor: resolvedColor,
            emblem: 'compass',
            totalPixelsPlaced: 0,
            updatedAt: now,
          });
        }
        await initBatch.commit();
      }
    } catch (error) {
      if (error instanceof Error && error.message === 'Hesabınız askıya alınmış durumda.') {
        throw error;
      }
      handleFirestoreError(error, OperationType.GET, userPath);
    }

    try {
      const modSnap = await getDoc(doc(db, MODERATION_COLLECTION, currentUser.uid));
      if (modSnap.exists()) {
        const modState = docToModerationState(currentUser.uid, modSnap.data());
        const activeBan = getActiveBan(modState, now);
        if (activeBan) {
          const durationLabel = activeBan.permanent
            ? 'Kalıcı'
            : activeBan.remainingMs !== null
              ? `Kalan: ${formatRemainingDuration(activeBan.remainingMs)}`
              : 'Süreli';
          throw new Error(
            `Yasaklandığınız için sohbete yazamazsınız (${durationLabel}). Neden: ${activeBan.reason}`
          );
        }
        const activeMute = getActiveMute(modState, now);
        if (activeMute) {
          const durationLabel = activeMute.permanent
            ? 'Kalıcı'
            : activeMute.remainingMs !== null
              ? `Kalan: ${formatRemainingDuration(activeMute.remainingMs)}`
              : 'Süreli';
          throw new Error(
            `Susturulduğunuz için mesaj gönderemezsiniz (${durationLabel}). Neden: ${activeMute.reason}`
          );
        }
      }
    } catch (error) {
      if (
        error instanceof Error &&
        (error.message.startsWith('Yasaklandığınız için') ||
          error.message.startsWith('Susturulduğunuz için'))
      ) {
        throw error;
      }
    }

    let tokenRole: UserRole = 'player';
    try {
      const tokenResult = await currentUser.getIdTokenResult();
      tokenRole = parseTokenRole(tokenResult.claims);
    } catch {
      tokenRole = 'player';
    }

    try {
      await addDoc(collection(db, CHAT_COLLECTION), {
        authorId: currentUser.uid,
        authorUsername: resolvedUsername,
        authorColor: resolvedColor,
        authorRole: tokenRole,
        text: trimmed,
        createdAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, CHAT_COLLECTION);
    }
  }

  public async deleteMessage(messageId: string): Promise<void> {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Mesaj silmek için giriş yapmalısınız.');
    }
    try {
      await deleteDoc(doc(db, CHAT_COLLECTION, messageId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${CHAT_COLLECTION}/${messageId}`);
    }
  }
}

export class FirebaseModerationService {
  private adminReadyCache: { value: boolean; checkedAt: number } | null = null;

  private async isServerAdminReady(): Promise<boolean> {
    const now = Date.now();
    if (this.adminReadyCache && now - this.adminReadyCache.checkedAt < 30_000) {
      return this.adminReadyCache.value;
    }
    try {
      const res = await fetch('/api/health');
      if (!res.ok) {
        this.adminReadyCache = { value: false, checkedAt: now };
        return false;
      }
      const data = await res.json();
      const ready = Boolean(data?.adminReady);
      this.adminReadyCache = { value: ready, checkedAt: now };
      return ready;
    } catch {
      this.adminReadyCache = { value: false, checkedAt: now };
      return false;
    }
  }

  public subscribeOwnModeration(
    uid: string,
    onUpdate: (state: UserModerationState | null) => void
  ): () => void {
    const ref = doc(db, MODERATION_COLLECTION, uid);
    return onSnapshot(
      ref,
      (snap) => {
        if (!snap.exists()) {
          onUpdate(null);
          return;
        }
        if (snap.metadata.hasPendingWrites) {
          return;
        }
        onUpdate(docToModerationState(uid, snap.data()));
      },
      (error) => {
        if (!isPermissionDeniedError(error)) {
          console.warn('Moderasyon durumu dinleyicisi hatası:', error);
        }
      }
    );
  }

  public async getUserModeration(targetUid: string): Promise<UserModerationState | null> {
    try {
      const snap = await getDoc(doc(db, MODERATION_COLLECTION, targetUid));
      if (!snap.exists()) return null;
      return docToModerationState(targetUid, snap.data());
    } catch (error) {
      if (isPermissionDeniedError(error)) {
        return null;
      }
      throw error;
    }
  }

  public async applyModeration(input: {
    targetUid: string;
    targetUsername?: string;
    type: ModerationType;
    durationKey: MuteDurationKey | BanDurationKey;
    reason: string;
    serverTimeOffsetMs?: number;
  }): Promise<void> {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Bu işlem için giriş yapmalısınız.');
    }

    const cleanReason = input.reason.trim().slice(0, 200);
    if (!cleanReason) {
      throw new Error('Ceza nedeni girilmesi zorunludur.');
    }

    if (await this.isServerAdminReady()) {
      const token = await currentUser.getIdToken();
      const res = await fetch('/api/moderation/apply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          targetUid: input.targetUid,
          type: input.type,
          durationKey: input.durationKey,
          reason: cleanReason,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Ceza uygulanamadı.');
      }
      return;
    }

    // Fallback when Admin SDK IAM is not configured: atomic batch strictly validated by firestore.rules Custom Claims
    const tokenResult = await currentUser.getIdTokenResult();
    const actorRole = parseTokenRole(tokenResult.claims);
    if (actorRole !== 'owner' && actorRole !== 'admin') {
      throw new Error('Bu işlem yalnızca Owner ve Admin yetkisine açıktır.');
    }

    const [actorUserSnap, targetUserSnap, modSnap] = await Promise.all([
      getDoc(doc(db, USERS_COLLECTION, currentUser.uid)),
      getDoc(doc(db, USERS_COLLECTION, input.targetUid)),
      getDoc(doc(db, MODERATION_COLLECTION, input.targetUid)),
    ]);

    if (!targetUserSnap.exists()) {
      throw new Error('Hedef kullanıcının profil kaydı bulunamadı.');
    }

    const targetData = targetUserSnap.data();
    const targetRole: UserRole =
      targetData.role === 'owner' ||
      targetData.role === 'admin' ||
      targetData.role === 'moderator'
        ? targetData.role
        : 'player';

    const hierarchyCheck = canViewerModerateTarget(
      actorRole,
      currentUser.uid,
      targetRole,
      input.targetUid
    );
    if (!hierarchyCheck.allowed) {
      throw new Error(hierarchyCheck.reason || 'Bu kullanıcıya ceza uygulayamazsınız.');
    }

    const actorUsername = sanitizeUsername(
      (typeof actorUserSnap.data()?.username === 'string' && actorUserSnap.data()!.username) ||
        currentUser.displayName ||
        currentUser.email?.split('@')[0] ||
        'Yetkili'
    );
    const targetUsername = sanitizeUsername(
      (typeof targetData.username === 'string' && targetData.username) ||
        input.targetUsername ||
        'Oyuncu'
    );

    const durationEntry =
      input.type === 'mute'
        ? MUTE_DURATION_OPTIONS.find((d) => d.key === input.durationKey)
        : BAN_DURATION_OPTIONS.find((d) => d.key === input.durationKey);

    if (!durationEntry) {
      throw new Error('Geçersiz ceza süresi.');
    }

    const serverNowMs = Date.now() + (input.serverTimeOffsetMs ?? 0);
    const permanent = durationEntry.durationMs === null;
    const expiresAtTs =
      permanent || durationEntry.durationMs === null
        ? null
        : Timestamp.fromMillis(serverNowMs + durationEntry.durationMs);

    const prev = modSnap.exists() ? modSnap.data() : null;
    const logRef = doc(collection(db, MODERATION_LOGS_COLLECTION));
    const modRef = doc(db, MODERATION_COLLECTION, input.targetUid);

    const baseMute = {
      muteActive: Boolean(prev?.muteActive),
      muteReason: typeof prev?.muteReason === 'string' ? prev.muteReason : '',
      muteDurationKey: typeof prev?.muteDurationKey === 'string' ? prev.muteDurationKey : '',
      mutePermanent: Boolean(prev?.mutePermanent),
      muteActorUid: typeof prev?.muteActorUid === 'string' ? prev.muteActorUid : '',
      muteActorUsername:
        typeof prev?.muteActorUsername === 'string' ? prev.muteActorUsername : '',
      muteActorRole: typeof prev?.muteActorRole === 'string' ? prev.muteActorRole : '',
      muteStartedAt: prev?.muteStartedAt instanceof Timestamp ? prev.muteStartedAt : null,
      muteExpiresAt: prev?.muteExpiresAt instanceof Timestamp ? prev.muteExpiresAt : null,
    };

    const baseBan = {
      banActive: Boolean(prev?.banActive),
      banReason: typeof prev?.banReason === 'string' ? prev.banReason : '',
      banDurationKey: typeof prev?.banDurationKey === 'string' ? prev.banDurationKey : '',
      banPermanent: Boolean(prev?.banPermanent),
      banActorUid: typeof prev?.banActorUid === 'string' ? prev.banActorUid : '',
      banActorUsername:
        typeof prev?.banActorUsername === 'string' ? prev.banActorUsername : '',
      banActorRole: typeof prev?.banActorRole === 'string' ? prev.banActorRole : '',
      banStartedAt: prev?.banStartedAt instanceof Timestamp ? prev.banStartedAt : null,
      banExpiresAt: prev?.banExpiresAt instanceof Timestamp ? prev.banExpiresAt : null,
    };

    const nextModDoc = {
      userId: input.targetUid,
      targetUsername,
      targetRole,
      ...(input.type === 'mute'
        ? {
            muteActive: true,
            muteReason: cleanReason,
            muteDurationKey: input.durationKey,
            mutePermanent: permanent,
            muteActorUid: currentUser.uid,
            muteActorUsername: actorUsername,
            muteActorRole: actorRole,
            muteStartedAt: serverTimestamp(),
            muteExpiresAt: expiresAtTs,
          }
        : baseMute),
      ...(input.type === 'ban'
        ? {
            banActive: true,
            banReason: cleanReason,
            banDurationKey: input.durationKey,
            banPermanent: permanent,
            banActorUid: currentUser.uid,
            banActorUsername: actorUsername,
            banActorRole: actorRole,
            banStartedAt: serverTimestamp(),
            banExpiresAt: expiresAtTs,
          }
        : baseBan),
      lastLogId: logRef.id,
      updatedAt: serverTimestamp(),
    };

    const batch = writeBatch(db);
    batch.set(modRef, nextModDoc);
    batch.set(logRef, {
      action: input.type,
      actorUid: currentUser.uid,
      actorUsername,
      actorRole,
      targetUid: input.targetUid,
      targetUsername,
      targetRole,
      reason: cleanReason,
      durationKey: input.durationKey,
      durationMs: durationEntry.durationMs ?? 0,
      permanent,
      expiresAt: expiresAtTs,
      createdAt: serverTimestamp(),
    });

    try {
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `${MODERATION_COLLECTION}/${input.targetUid}`);
    }
  }

  public async revokeModeration(input: {
    targetUid: string;
    type: ModerationType;
    reason?: string;
  }): Promise<void> {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Bu işlem için giriş yapmalısınız.');
    }

    const cleanReason =
      (input.reason?.trim() || 'Yetkili tarafından ceza kaldırıldı.').slice(0, 200);

    if (await this.isServerAdminReady()) {
      const token = await currentUser.getIdToken();
      const res = await fetch('/api/moderation/revoke', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          targetUid: input.targetUid,
          type: input.type,
          reason: cleanReason,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Ceza kaldırılamadı.');
      }
      return;
    }

    const tokenResult = await currentUser.getIdTokenResult();
    const actorRole = parseTokenRole(tokenResult.claims);
    if (actorRole !== 'owner' && actorRole !== 'admin') {
      throw new Error('Bu işlem yalnızca Owner ve Admin yetkisine açıktır.');
    }

    const [actorUserSnap, targetUserSnap, modSnap] = await Promise.all([
      getDoc(doc(db, USERS_COLLECTION, currentUser.uid)),
      getDoc(doc(db, USERS_COLLECTION, input.targetUid)),
      getDoc(doc(db, MODERATION_COLLECTION, input.targetUid)),
    ]);

    if (!modSnap.exists()) {
      throw new Error('Aktif ceza kaydı bulunamadı.');
    }

    const targetData = targetUserSnap.data();
    const targetRole: UserRole =
      targetData?.role === 'owner' ||
      targetData?.role === 'admin' ||
      targetData?.role === 'moderator'
        ? targetData.role
        : 'player';

    const hierarchyCheck = canViewerModerateTarget(
      actorRole,
      currentUser.uid,
      targetRole,
      input.targetUid
    );
    if (!hierarchyCheck.allowed) {
      throw new Error(hierarchyCheck.reason || 'Bu kullanıcının cezasını kaldıramazsınız.');
    }

    const actorUsername = sanitizeUsername(
      (typeof actorUserSnap.data()?.username === 'string' && actorUserSnap.data()!.username) ||
        currentUser.displayName ||
        currentUser.email?.split('@')[0] ||
        'Yetkili'
    );
    const prev = modSnap.data();
    const targetUsername = sanitizeUsername(
      (typeof targetData?.username === 'string' && targetData.username) ||
        (typeof prev.targetUsername === 'string' ? prev.targetUsername : '') ||
        'Oyuncu'
    );

    const logRef = doc(collection(db, MODERATION_LOGS_COLLECTION));
    const modRef = doc(db, MODERATION_COLLECTION, input.targetUid);

    const clearedMute = {
      muteActive: false,
      muteReason: '',
      muteDurationKey: '',
      mutePermanent: false,
      muteActorUid: '',
      muteActorUsername: '',
      muteActorRole: '',
      muteStartedAt: null,
      muteExpiresAt: null,
    };
    const clearedBan = {
      banActive: false,
      banReason: '',
      banDurationKey: '',
      banPermanent: false,
      banActorUid: '',
      banActorUsername: '',
      banActorRole: '',
      banStartedAt: null,
      banExpiresAt: null,
    };

    const nextModDoc = {
      userId: input.targetUid,
      targetUsername,
      targetRole,
      muteActive: Boolean(prev.muteActive),
      muteReason: typeof prev.muteReason === 'string' ? prev.muteReason : '',
      muteDurationKey: typeof prev.muteDurationKey === 'string' ? prev.muteDurationKey : '',
      mutePermanent: Boolean(prev.mutePermanent),
      muteActorUid: typeof prev.muteActorUid === 'string' ? prev.muteActorUid : '',
      muteActorUsername:
        typeof prev.muteActorUsername === 'string' ? prev.muteActorUsername : '',
      muteActorRole: typeof prev.muteActorRole === 'string' ? prev.muteActorRole : '',
      muteStartedAt: prev.muteStartedAt instanceof Timestamp ? prev.muteStartedAt : null,
      muteExpiresAt: prev.muteExpiresAt instanceof Timestamp ? prev.muteExpiresAt : null,
      banActive: Boolean(prev.banActive),
      banReason: typeof prev.banReason === 'string' ? prev.banReason : '',
      banDurationKey: typeof prev.banDurationKey === 'string' ? prev.banDurationKey : '',
      banPermanent: Boolean(prev.banPermanent),
      banActorUid: typeof prev.banActorUid === 'string' ? prev.banActorUid : '',
      banActorUsername:
        typeof prev.banActorUsername === 'string' ? prev.banActorUsername : '',
      banActorRole: typeof prev.banActorRole === 'string' ? prev.banActorRole : '',
      banStartedAt: prev.banStartedAt instanceof Timestamp ? prev.banStartedAt : null,
      banExpiresAt: prev.banExpiresAt instanceof Timestamp ? prev.banExpiresAt : null,
      ...(input.type === 'mute' ? clearedMute : {}),
      ...(input.type === 'ban' ? clearedBan : {}),
      lastLogId: logRef.id,
      updatedAt: serverTimestamp(),
    };

    const batch = writeBatch(db);
    batch.set(modRef, nextModDoc);
    batch.set(logRef, {
      action: input.type === 'mute' ? 'unmute' : 'unban',
      actorUid: currentUser.uid,
      actorUsername,
      actorRole,
      targetUid: input.targetUid,
      targetUsername,
      targetRole,
      reason: cleanReason,
      durationKey: 'none',
      durationMs: 0,
      permanent: false,
      expiresAt: null,
      createdAt: serverTimestamp(),
    });

    try {
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `${MODERATION_COLLECTION}/${input.targetUid}`);
    }
  }

  public async listModerationOverview(serverTimeOffsetMs = 0): Promise<{
    activePenalties: UserModerationState[];
    logs: ModerationLogEntry[];
  }> {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Oturum açılmamış.');
    }

    if (await this.isServerAdminReady()) {
      const token = await currentUser.getIdToken();
      const res = await fetch('/api/moderation/list', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Moderasyon kayıtları alınamadı.');
      }
      return {
        activePenalties: (data.activePenalties ?? []) as UserModerationState[],
        logs: (data.logs ?? []) as ModerationLogEntry[],
      };
    }

    const nowMs = Date.now() + serverTimeOffsetMs;
    try {
      const [modSnap, logSnap] = await Promise.all([
        getDocs(collection(db, MODERATION_COLLECTION)),
        getDocs(
          query(
            collection(db, MODERATION_LOGS_COLLECTION),
            orderBy('createdAt', 'desc'),
            limit(60)
          )
        ),
      ]);

      const activePenalties: UserModerationState[] = [];
      modSnap.forEach((d) => {
        const parsed = docToModerationState(d.id, d.data());
        const muteStillActive = Boolean(getActiveMute(parsed, nowMs));
        const banStillActive = Boolean(getActiveBan(parsed, nowMs));
        if (muteStillActive || banStillActive) {
          activePenalties.push({
            ...parsed,
            muteActive: muteStillActive,
            banActive: banStillActive,
          });
        }
      });

      const logs: ModerationLogEntry[] = [];
      logSnap.forEach((d) => {
        const parsed = docToModerationLog(d.id, d.data());
        if (parsed) logs.push(parsed);
      });

      return { activePenalties, logs };
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, MODERATION_COLLECTION);
    }
  }
}

export const firebasePixels = new FirebasePixelService();
export const firebaseAuthProfiles = new FirebaseAuthProfileService();
export const firebaseChat = new FirebaseChatService();
export const firebaseModeration = new FirebaseModerationService();

