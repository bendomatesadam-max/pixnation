import { AvatarEmblem, PlacedPixelRecord, PlayerProfile } from '../../types/game';

export type PixelMap = Map<string, PlacedPixelRecord>;

export type PixelSubscriptionCallback = (pixels: PixelMap) => void;

export interface PlacePixelInput {
  x: number;
  y: number;
  color: string;
  authorId: string;
  authorUsername: string;
}

export interface CreateProfileInput {
  username: string;
  bio?: string;
  countryCode?: string;
  accentColor?: string;
  emblem?: AvatarEmblem;
}

export interface UpdateProfileInput {
  id: string;
  username: string;
  bio: string;
  countryCode: string;
  accentColor: string;
  emblem: AvatarEmblem;
}

/**
 * Pixel storage abstraction.
 * Phase 1: LocalPixelRepository (browser localStorage).
 * Phase 2: FirestorePixelRepository (collection('pixels') + onSnapshot real-time sync).
 */
export interface IPixelRepository {
  loadAllPixels(): Promise<PixelMap>;
  placePixel(input: PlacePixelInput): Promise<PlacedPixelRecord>;
  subscribePixels(callback: PixelSubscriptionCallback): () => void;
  getPixelsByAuthor(authorId: string, limit?: number): Promise<PlacedPixelRecord[]>;
  clearAllPixels(): Promise<void>;
}

/**
 * Player profile & session abstraction.
 * Phase 1: LocalProfileRepository (local profiles in browser storage).
 * Phase 2: FirebaseAuthProfileRepository (Firebase Authentication + users/{uid} document).
 */
export interface IProfileRepository {
  getActiveProfile(): Promise<PlayerProfile>;
  listProfiles(): Promise<PlayerProfile[]>;
  createProfile(input: CreateProfileInput): Promise<PlayerProfile>;
  updateProfile(input: UpdateProfileInput): Promise<PlayerProfile>;
  switchActiveProfile(profileId: string): Promise<PlayerProfile>;
  incrementPlacedCount(profileId: string): Promise<PlayerProfile>;
}

export interface IGameBackend {
  readonly mode: 'local' | 'firebase';
  pixels: IPixelRepository;
  profiles: IProfileRepository;
}

export function makePixelKey(x: number, y: number): string {
  return `${x}:${y}`;
}
