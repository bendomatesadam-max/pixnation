import { auth } from '../../firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export function isPermissionDeniedError(error: unknown): boolean {
  if (!error) return false;
  const msg = error instanceof Error ? error.message : String(error);
  return (
    msg.includes('permission-denied') ||
    msg.includes('Missing or insufficient permissions')
  );
}

export function translateFirebaseError(error: unknown): string {
  const raw = error instanceof Error ? error.message : String(error);

  if (raw.includes('auth/invalid-credential') || raw.includes('auth/wrong-password')) {
    return 'E-posta veya şifre hatalı.';
  }
  if (raw.includes('auth/user-disabled')) {
    return 'Bu hesap askıya alınmış durumda.';
  }
  if (raw.includes('auth/user-not-found')) {
    return 'Bu e-posta adresine kayıtlı bir hesap bulunamadı.';
  }
  if (raw.includes('auth/email-already-in-use')) {
    return 'Bu e-posta adresi zaten kullanımda.';
  }
  if (raw.includes('auth/invalid-email')) {
    return 'Geçerli bir e-posta adresi girin.';
  }
  if (raw.includes('auth/weak-password')) {
    return 'Şifre en az 6 karakter olmalıdır.';
  }
  if (raw.includes('auth/too-many-requests')) {
    return 'Çok fazla deneme yapıldı. Lütfen biraz bekleyin.';
  }
  if (raw.includes('auth/network-request-failed')) {
    return 'Ağ bağlantısı kurulamadı. İnternet bağlantınızı kontrol edin.';
  }
  if (isPermissionDeniedError(error)) {
    return 'Firestore erişim izni reddedildi. Güvenlik kurallarını kontrol edin.';
  }
  if (
    raw &&
    !raw.startsWith('{') &&
    !raw.includes('FirebaseError') &&
    !raw.includes('auth/')
  ) {
    return raw;
  }
  return 'İşlem sırasında bir hata oluştu. Lütfen tekrar deneyin.';
}
