import { PROFILE_ACCENT_COLORS } from '../../constants/palette';
import { AvatarEmblem, PlacedPixelRecord, PlayerProfile } from '../../types/game';
import {
  CreateProfileInput,
  IGameBackend,
  IPixelRepository,
  IProfileRepository,
  makePixelKey,
  PixelMap,
  PixelSubscriptionCallback,
  PlacePixelInput,
  UpdateProfileInput,
} from './types';

const PIXELS_STORAGE_KEY = 'pixnation.world.pixels.v2';
const PROFILES_STORAGE_KEY = 'pixnation.players.profiles.v1';
const ACTIVE_PROFILE_ID_KEY = 'pixnation.players.activeId.v1';

function generateLocalId(prefix: string): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `${prefix}_${crypto.randomUUID().slice(0, 8)}`;
  }
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
}

class LocalPixelRepository implements IPixelRepository {
  private cache: PixelMap | null = null;
  private listeners = new Set<PixelSubscriptionCallback>();

  private ensureLoaded(): PixelMap {
    if (this.cache) return this.cache;

    const map: PixelMap = new Map();
    if (typeof window !== 'undefined') {
      try {
        const raw = window.localStorage.getItem(PIXELS_STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw) as PlacedPixelRecord[];
          if (Array.isArray(parsed)) {
            for (const item of parsed) {
              if (
                typeof item.x === 'number' &&
                typeof item.y === 'number' &&
                typeof item.color === 'string'
              ) {
                map.set(makePixelKey(item.x, item.y), item);
              }
            }
          }
        }
      } catch {
        // Ignore corrupted local storage entries and start clean
      }
    }
    this.cache = map;
    return map;
  }

  private persist(): void {
    if (!this.cache || typeof window === 'undefined') return;
    try {
      const serialized = JSON.stringify(Array.from(this.cache.values()));
      window.localStorage.setItem(PIXELS_STORAGE_KEY, serialized);
    } catch {
      // Storage quota fallback
    }
  }

  private notify(): void {
    const snapshot = new Map(this.ensureLoaded());
    this.listeners.forEach((cb) => cb(snapshot));
  }

  public async loadAllPixels(): Promise<PixelMap> {
    return new Map(this.ensureLoaded());
  }

  public async placePixel(input: PlacePixelInput): Promise<PlacedPixelRecord> {
    const map = this.ensureLoaded();
    const record: PlacedPixelRecord = {
      x: input.x,
      y: input.y,
      color: input.color,
      authorId: input.authorId,
      authorUsername: input.authorUsername,
      placedAt: Date.now(),
    };
    map.set(makePixelKey(input.x, input.y), record);
    this.persist();
    this.notify();
    return record;
  }

  public subscribePixels(callback: PixelSubscriptionCallback): () => void {
    this.listeners.add(callback);
    callback(new Map(this.ensureLoaded()));
    return () => {
      this.listeners.delete(callback);
    };
  }

  public async getPixelsByAuthor(authorId: string, limit = 15): Promise<PlacedPixelRecord[]> {
    const map = this.ensureLoaded();
    const results: PlacedPixelRecord[] = [];
    map.forEach((pixel) => {
      if (pixel.authorId === authorId) {
        results.push(pixel);
      }
    });
    results.sort((a, b) => b.placedAt - a.placedAt);
    return results.slice(0, limit);
  }

  public async clearAllPixels(): Promise<void> {
    this.cache = new Map();
    this.persist();
    this.notify();
  }
}

class LocalProfileRepository implements IProfileRepository {
  private readAll(): PlayerProfile[] {
    if (typeof window === 'undefined') return [];
    try {
      const raw = window.localStorage.getItem(PROFILES_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw) as PlayerProfile[];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  private writeAll(profiles: PlayerProfile[]): void {
    if (typeof window === 'undefined') return;
    try {
      window.localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(profiles));
    } catch {
      // Ignore storage error
    }
  }

  private createDefaultProfile(): PlayerProfile {
    const now = Date.now();
    const defaultProfile: PlayerProfile = {
      id: generateLocalId('player'),
      username: 'GezginPiksel',
      bio: 'Dünya haritasında ilk izini bırakıyor.',
      countryCode: 'TR',
      accentColor: PROFILE_ACCENT_COLORS[0],
      emblem: 'compass',
      totalPixelsPlaced: 0,
      createdAt: now,
      updatedAt: now,
    };
    this.writeAll([defaultProfile]);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(ACTIVE_PROFILE_ID_KEY, defaultProfile.id);
    }
    return defaultProfile;
  }

  public async getActiveProfile(): Promise<PlayerProfile> {
    const profiles = this.readAll();
    if (profiles.length === 0) {
      return this.createDefaultProfile();
    }
    const activeId =
      typeof window !== 'undefined' ? window.localStorage.getItem(ACTIVE_PROFILE_ID_KEY) : null;
    const found = profiles.find((p) => p.id === activeId) ?? profiles[0];
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(ACTIVE_PROFILE_ID_KEY, found.id);
    }
    return found;
  }

  public async listProfiles(): Promise<PlayerProfile[]> {
    const profiles = this.readAll();
    if (profiles.length === 0) {
      return [this.createDefaultProfile()];
    }
    return profiles;
  }

  public async createProfile(input: CreateProfileInput): Promise<PlayerProfile> {
    const profiles = this.readAll();
    const now = Date.now();
    const cleanName = input.username.trim().slice(0, 20) || 'YeniOyuncu';
    const emblem: AvatarEmblem = input.emblem ?? 'palette';
    const created: PlayerProfile = {
      id: generateLocalId('player'),
      username: cleanName,
      bio: (input.bio ?? '').trim().slice(0, 80) || 'PixNation kaşifi.',
      countryCode: (input.countryCode ?? 'TR').toUpperCase().slice(0, 3),
      accentColor: input.accentColor ?? PROFILE_ACCENT_COLORS[profiles.length % PROFILE_ACCENT_COLORS.length],
      emblem,
      totalPixelsPlaced: 0,
      createdAt: now,
      updatedAt: now,
    };
    const next = [...profiles, created];
    this.writeAll(next);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(ACTIVE_PROFILE_ID_KEY, created.id);
    }
    return created;
  }

  public async updateProfile(input: UpdateProfileInput): Promise<PlayerProfile> {
    const profiles = this.readAll();
    const idx = profiles.findIndex((p) => p.id === input.id);
    if (idx === -1) {
      return this.getActiveProfile();
    }
    const updated: PlayerProfile = {
      ...profiles[idx],
      username: input.username.trim().slice(0, 20) || profiles[idx].username,
      bio: input.bio.trim().slice(0, 80),
      countryCode: input.countryCode.trim().toUpperCase().slice(0, 3) || 'TR',
      accentColor: input.accentColor,
      emblem: input.emblem,
      updatedAt: Date.now(),
    };
    const next = [...profiles];
    next[idx] = updated;
    this.writeAll(next);
    return updated;
  }

  public async switchActiveProfile(profileId: string): Promise<PlayerProfile> {
    const profiles = this.readAll();
    const target = profiles.find((p) => p.id === profileId);
    if (!target) {
      return this.getActiveProfile();
    }
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(ACTIVE_PROFILE_ID_KEY, target.id);
    }
    return target;
  }

  public async incrementPlacedCount(profileId: string): Promise<PlayerProfile> {
    const profiles = this.readAll();
    const idx = profiles.findIndex((p) => p.id === profileId);
    if (idx === -1) {
      return this.getActiveProfile();
    }
    const updated: PlayerProfile = {
      ...profiles[idx],
      totalPixelsPlaced: profiles[idx].totalPixelsPlaced + 1,
      updatedAt: Date.now(),
    };
    const next = [...profiles];
    next[idx] = updated;
    this.writeAll(next);
    return updated;
  }
}

export function createLocalBackend(): IGameBackend {
  return {
    mode: 'local',
    pixels: new LocalPixelRepository(),
    profiles: new LocalProfileRepository(),
  };
}
