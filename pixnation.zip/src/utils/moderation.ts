import {
  BanDurationKey,
  MuteDurationKey,
  UserModerationState,
  UserRole,
} from '../types/game';

export const MUTE_DURATION_OPTIONS: {
  key: MuteDurationKey;
  label: string;
  durationMs: number | null;
}[] = [
  { key: '5m', label: '5 Dakika', durationMs: 5 * 60 * 1000 },
  { key: '1h', label: '1 Saat', durationMs: 60 * 60 * 1000 },
  { key: '24h', label: '24 Saat', durationMs: 24 * 60 * 60 * 1000 },
  { key: 'permanent', label: 'Kalıcı', durationMs: null },
];

export const BAN_DURATION_OPTIONS: {
  key: BanDurationKey;
  label: string;
  durationMs: number | null;
}[] = [
  { key: '1h', label: '1 Saat', durationMs: 60 * 60 * 1000 },
  { key: '24h', label: '24 Saat', durationMs: 24 * 60 * 60 * 1000 },
  { key: '7d', label: '7 Gün', durationMs: 7 * 24 * 60 * 60 * 1000 },
  { key: 'permanent', label: 'Kalıcı', durationMs: null },
];

export const DURATION_LABELS: Record<string, string> = {
  '5m': '5 Dakika',
  '1h': '1 Saat',
  '24h': '24 Saat',
  '7d': '7 Gün',
  permanent: 'Kalıcı',
  none: '-',
};

export function formatRemainingDuration(remainingMs: number): string {
  const totalSeconds = Math.max(1, Math.ceil(remainingMs / 1000));
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (days > 0) return `${days} gün ${hours} sa`;
  if (hours > 0) return `${hours} sa ${minutes} dk`;
  if (minutes > 0) return `${minutes} dk ${seconds} sn`;
  return `${seconds} sn`;
}

export interface ActivePenaltyInfo {
  type: 'mute' | 'ban';
  reason: string;
  durationKey: string;
  permanent: boolean;
  expiresAtMs: number | null;
  remainingMs: number | null;
  actorUsername: string;
}

export function getActiveMute(
  state: UserModerationState | null,
  serverNowMs: number
): ActivePenaltyInfo | null {
  if (!state || !state.muteActive) return null;
  if (state.mutePermanent) {
    return {
      type: 'mute',
      reason: state.muteReason,
      durationKey: state.muteDurationKey || 'permanent',
      permanent: true,
      expiresAtMs: null,
      remainingMs: null,
      actorUsername: state.muteActorUsername,
    };
  }
  if (state.muteExpiresAtMs === null || serverNowMs >= state.muteExpiresAtMs) {
    return null;
  }
  return {
    type: 'mute',
    reason: state.muteReason,
    durationKey: state.muteDurationKey,
    permanent: false,
    expiresAtMs: state.muteExpiresAtMs,
    remainingMs: Math.max(0, state.muteExpiresAtMs - serverNowMs),
    actorUsername: state.muteActorUsername,
  };
}

export function getActiveBan(
  state: UserModerationState | null,
  serverNowMs: number
): ActivePenaltyInfo | null {
  if (!state || !state.banActive) return null;
  if (state.banPermanent) {
    return {
      type: 'ban',
      reason: state.banReason,
      durationKey: state.banDurationKey || 'permanent',
      permanent: true,
      expiresAtMs: null,
      remainingMs: null,
      actorUsername: state.banActorUsername,
    };
  }
  if (state.banExpiresAtMs === null || serverNowMs >= state.banExpiresAtMs) {
    return null;
  }
  return {
    type: 'ban',
    reason: state.banReason,
    durationKey: state.banDurationKey,
    permanent: false,
    expiresAtMs: state.banExpiresAtMs,
    remainingMs: Math.max(0, state.banExpiresAtMs - serverNowMs),
    actorUsername: state.banActorUsername,
  };
}

export function canViewerModerateTarget(
  viewerRole: UserRole,
  viewerUid: string | null,
  targetRole: UserRole,
  targetUid: string
): { allowed: boolean; reason?: string } {
  if (!viewerUid) {
    return { allowed: false, reason: 'Giriş yapmalısınız.' };
  }
  if (viewerUid === targetUid) {
    return { allowed: false, reason: 'Kendi hesabınıza ceza veremezsiniz.' };
  }
  if (viewerRole !== 'owner' && viewerRole !== 'admin') {
    return { allowed: false };
  }
  if (targetRole === 'owner') {
    return { allowed: false, reason: 'Owner hesabına ceza uygulanamaz.' };
  }
  if (targetRole === 'admin') {
    return { allowed: false, reason: 'Admin rolündeki hesaplar yasaklanamaz veya susturulamaz.' };
  }
  if (viewerRole === 'admin' && targetRole !== 'player') {
    return { allowed: false, reason: 'Adminler yalnızca normal oyunculara ceza uygulayabilir.' };
  }
  return { allowed: true };
}
