export const WORLD_WIDTH = 2048;
export const WORLD_HEIGHT = 2048;

export const OCEAN_COLOR = '#CAE3FF';
export const LAND_COLOR = '#FFFFFF';

export interface WorldMapData {
  /** 0 = ocean, 1 = land */
  terrain: Uint8Array;
  baseCanvas: HTMLCanvasElement;
}

let cachedWorldMap: WorldMapData | null = null;
let loadingPromise: Promise<WorldMapData> | null = null;

export function loadWorldMap(): Promise<WorldMapData> {
  if (cachedWorldMap) {
    return Promise.resolve(cachedWorldMap);
  }
  if (loadingPromise) {
    return loadingPromise;
  }

  loadingPromise = new Promise<WorldMapData>((resolve, reject) => {
    const img = new Image();
    img.decoding = 'async';
    img.onload = () => {
      const baseCanvas = document.createElement('canvas');
      baseCanvas.width = WORLD_WIDTH;
      baseCanvas.height = WORLD_HEIGHT;
      const ctx = baseCanvas.getContext('2d', { willReadFrequently: true });

      const terrain = new Uint8Array(WORLD_WIDTH * WORLD_HEIGHT);

      if (ctx) {
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(img, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);
        const imageData = ctx.getImageData(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
        const data = imageData.data;

        for (let i = 0, p = 0; i < data.length; i += 4, p++) {
          // Land pixels are white (#FFFFFF, R = 255), ocean is #CAE3FF (R = 202)
          terrain[p] = data[i] > 230 ? 1 : 0;
        }
      }

      cachedWorldMap = { terrain, baseCanvas };
      resolve(cachedWorldMap);
    };
    img.onerror = () => {
      loadingPromise = null;
      reject(new Error('Dünya haritası görseli yüklenemedi.'));
    };
    img.src = '/assets/world-map.png';
  });

  return loadingPromise;
}

export function getLoadedWorldMap(): WorldMapData | null {
  return cachedWorldMap;
}

export function getTerrainLabel(x: number, y: number): string {
  if (!cachedWorldMap) return 'Harita';
  if (x < 0 || x >= WORLD_WIDTH || y < 0 || y >= WORLD_HEIGHT) return 'Sınır Dışı';
  const val = cachedWorldMap.terrain[y * WORLD_WIDTH + x];
  return val === 1 ? 'Kara' : 'Deniz';
}

export function getBasePixelColor(x: number, y: number): string {
  if (!cachedWorldMap) return OCEAN_COLOR;
  if (x < 0 || x >= WORLD_WIDTH || y < 0 || y >= WORLD_HEIGHT) return OCEAN_COLOR;
  const val = cachedWorldMap.terrain[y * WORLD_WIDTH + x];
  return val === 1 ? LAND_COLOR : OCEAN_COLOR;
}
